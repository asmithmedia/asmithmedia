<?php
/**
 * Plugin Name: SiteVitals Speed Optimizer Pro
 * Plugin URI:  https://asmith.media/sitevitals/speed-optimizer/
 * Description: Pro add-on for SiteVitals Speed Optimizer — Critical CSS, unused CSS removal, WebP/AVIF conversion, performance history, CDN integration, and more.
 * Version:     1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author:      A. Smith Media
 * Author URI:  https://asmith.media
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: sitevitals-speed-optimizer-pro
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SITEVITALS_SO_PRO_VERSION', '1.0.0' );
define( 'SITEVITALS_SO_PRO_FILE', __FILE__ );
define( 'SITEVITALS_SO_PRO_DIR', plugin_dir_path( __FILE__ ) );
define( 'SITEVITALS_SO_PRO_URL', plugin_dir_url( __FILE__ ) );
define( 'SITEVITALS_SO_PRO_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Main Pro plugin class.
 */
final class SiteVitals_Speed_Optimizer_Pro {

	/**
	 * Single instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Get or create the singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'check_dependencies' ), 5 );
		add_action( 'activated_plugin', array( $this, 'redirect_after_activation' ) );
	}

	/**
	 * Redirect to license activation screen after Pro is activated.
	 *
	 * @param string $plugin The plugin that was activated.
	 */
	public function redirect_after_activation( $plugin ) {
		if ( $plugin !== SITEVITALS_SO_PRO_BASENAME ) {
			return;
		}

		if ( isset( $_GET['activate-multi'] ) || wp_doing_ajax() || ( defined( 'WP_CLI' ) && WP_CLI ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- WP core activation redirect pattern, no form data processed.
			return;
		}

		update_option( 'sitevitals_so_pro_needs_onboarding', true );

		wp_safe_redirect( admin_url( 'admin.php?page=sitevitals-so-pro-activate' ) );
		exit;
	}

	/**
	 * Verify the free plugin is active before loading Pro.
	 */
	public function check_dependencies() {
		if ( ! defined( 'SITEVITALS_SO_VERSION' ) ) {
			add_action( 'admin_notices', array( $this, 'missing_free_plugin_notice' ) );
			return;
		}

		$this->load_includes();
		$this->init();
	}

	/**
	 * Load Pro class files.
	 */
	private function load_includes() {
		$includes = array(
			'class-license-manager',
			'class-critical-css',
			'class-unused-css',
			'class-image-converter',
			'class-scheduled-db',
			'class-advanced-js',
			'class-preload-manager',
			'class-cdn-helper',
			'class-performance-history',
			'class-notifications',
			'class-white-label',
		);

		foreach ( $includes as $file ) {
			require_once SITEVITALS_SO_PRO_DIR . 'includes/' . $file . '.php';
		}
	}

	/**
	 * Initialize Pro features.
	 */
	private function init() {
		$license = SiteVitals_SO_License_Manager::instance();

		// Register the Pro activation/onboarding page.
		add_action( 'admin_menu', array( $this, 'register_pro_pages' ) );

		// Only load premium features if licensed.
		if ( $license->is_valid() ) {
			SiteVitals_SO_Critical_CSS::instance();
			SiteVitals_SO_Unused_CSS::instance();
			SiteVitals_SO_Image_Converter::instance();
			SiteVitals_SO_Scheduled_DB::instance();
			SiteVitals_SO_Advanced_JS::instance();
			SiteVitals_SO_Preload_Manager::instance();
			SiteVitals_SO_CDN_Helper::instance();
			SiteVitals_SO_Performance_History::instance();
			SiteVitals_SO_Notifications::instance();
			SiteVitals_SO_White_Label::instance();

			// Hook Pro UI sections into the free plugin's dashboard and settings.
			add_action( 'sitevitals_so_pro_dashboard_sections', array( $this, 'render_pro_dashboard' ) );
			add_action( 'sitevitals_so_pro_settings_sections', array( $this, 'render_pro_settings' ) );
		}

		// License settings on free plugin's settings page.
		add_action( 'sitevitals_so_pro_license_settings', array( $license, 'render_license_settings' ) );

		// Tell the free plugin that Pro is licensed.
		add_filter( 'sitevitals_so_pro_is_licensed', array( $license, 'is_valid' ) );

		// Enqueue Pro assets on our pages.
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_pro_assets' ) );
	}

	/**
	 * Register the hidden Pro activation page.
	 */
	public function register_pro_pages() {
		add_submenu_page(
			null, // Hidden page -- no menu link.
			__( 'Activate Pro', 'sitevitals-speed-optimizer-pro' ),
			__( 'Activate Pro', 'sitevitals-speed-optimizer-pro' ),
			'manage_options',
			'sitevitals-so-pro-activate',
			array( $this, 'render_pro_activation' )
		);
	}

	/**
	 * Enqueue Pro scripts on our activation page.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 */
	public function enqueue_pro_assets( $hook_suffix ) {
		$pro_pages = array( 'admin_page_sitevitals-so-pro-activate' );
		if ( ! in_array( $hook_suffix, $pro_pages, true ) ) {
			return;
		}

		wp_enqueue_style(
			'sitevitals-so-admin',
			SITEVITALS_SO_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			SITEVITALS_SO_PRO_VERSION
		);

		wp_enqueue_script(
			'sitevitals-so-admin',
			SITEVITALS_SO_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			SITEVITALS_SO_PRO_VERSION,
			true
		);

		wp_localize_script( 'sitevitals-so-admin', 'sitevitals_so', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'sitevitals_so_pro_nonce' ),
		) );
	}

	/**
	 * Render the Pro activation / onboarding page.
	 */
	public function render_pro_activation() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'sitevitals-speed-optimizer-pro' ) );
		}

		$license = SiteVitals_SO_License_Manager::instance();

		if ( $license->is_valid() ) {
			delete_option( 'sitevitals_so_pro_needs_onboarding' );
			wp_safe_redirect( admin_url( 'admin.php?page=sitevitals-so' ) );
			exit;
		}

		include SITEVITALS_SO_PRO_DIR . 'templates/pro-activate.php';
	}

	/**
	 * Render Pro dashboard sections.
	 *
	 * @param array $report Performance report data.
	 */
	public function render_pro_dashboard( $report ) {
		include SITEVITALS_SO_PRO_DIR . 'templates/pro-dashboard-sections.php';
	}

	/**
	 * Render Pro settings sections.
	 */
	public function render_pro_settings() {
		include SITEVITALS_SO_PRO_DIR . 'templates/pro-settings-sections.php';
	}

	/**
	 * Admin notice when free plugin is missing.
	 */
	public function missing_free_plugin_notice() {
		?>
		<div class="notice notice-error">
			<p>
				<strong><?php esc_html_e( 'SiteVitals Speed Optimizer Pro', 'sitevitals-speed-optimizer-pro' ); ?></strong>:
				<?php esc_html_e( 'This add-on requires the free SiteVitals Speed Optimizer plugin to be installed and active.', 'sitevitals-speed-optimizer-pro' ); ?>
			</p>
		</div>
		<?php
	}
}

/**
 * Returns the main Pro plugin instance.
 *
 * @return SiteVitals_Speed_Optimizer_Pro
 */
function sitevitals_so_pro() {
	return SiteVitals_Speed_Optimizer_Pro::instance();
}

sitevitals_so_pro();
