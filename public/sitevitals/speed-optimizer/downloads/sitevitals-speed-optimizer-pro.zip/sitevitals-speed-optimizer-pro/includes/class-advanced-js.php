<?php
/**
 * Advanced JS - delays JavaScript execution until user interaction.
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_SO_Advanced_JS {

	/**
	 * Single instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Get or create the singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );

		if ( ! is_admin() && $this->is_enabled() ) {
			add_filter( 'script_loader_tag', array( $this, 'delay_script_tag' ), 20, 3 );
			add_action( 'wp_footer', array( $this, 'output_loader_script' ), 999 );
		}
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_delay_js_enabled', array(
			'type'              => 'boolean',
			'sanitize_callback' => 'rest_sanitize_boolean',
			'default'           => false,
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_delay_js_list', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_textarea_field',
			'default'           => '',
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_delay_js_excludes', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_textarea_field',
			'default'           => '',
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_delay_js_timeout', array(
			'type'              => 'integer',
			'sanitize_callback' => 'absint',
			'default'           => 0,
		) );
	}

	/**
	 * Check if delay JS is enabled.
	 *
	 * @return bool
	 */
	public function is_enabled() {
		return (bool) get_option( 'sitevitals_so_pro_delay_js_enabled', false );
	}

	/**
	 * Get the delay list (scripts to delay).
	 *
	 * @return array
	 */
	private function get_delay_list() {
		$list = get_option( 'sitevitals_so_pro_delay_js_list', '' );
		if ( empty( $list ) ) {
			return array();
		}
		return array_filter( array_map( 'trim', explode( "\n", $list ) ) );
	}

	/**
	 * Get the exclude list (scripts that should never be delayed).
	 *
	 * @return array
	 */
	private function get_exclude_list() {
		$list = get_option( 'sitevitals_so_pro_delay_js_excludes', '' );
		$defaults = array(
			'jquery.min.js',
			'jquery.js',
			'wp-includes/js/jquery',
		);

		$custom = array();
		if ( ! empty( $list ) ) {
			$custom = array_filter( array_map( 'trim', explode( "\n", $list ) ) );
		}

		return array_merge( $defaults, $custom );
	}

	/**
	 * Check if a script should be delayed.
	 *
	 * @param string $handle The script handle.
	 * @param string $src    The script URL.
	 * @return bool
	 */
	private function should_delay( $handle, $src ) {
		// Check excludes first.
		$excludes = $this->get_exclude_list();
		foreach ( $excludes as $exclude ) {
			if ( false !== strpos( $handle, $exclude ) || false !== strpos( $src, $exclude ) ) {
				return false;
			}
		}

		// If delay list is empty, delay all non-excluded scripts.
		$delay_list = $this->get_delay_list();
		if ( empty( $delay_list ) ) {
			return true;
		}

		// Check if script matches delay list.
		foreach ( $delay_list as $pattern ) {
			if ( false !== strpos( $handle, $pattern ) || false !== strpos( $src, $pattern ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Modify script tags to delay their execution.
	 *
	 * @param string $tag    The script HTML tag.
	 * @param string $handle The script handle.
	 * @param string $src    The script URL.
	 * @return string Modified tag.
	 */
	public function delay_script_tag( $tag, $handle, $src ) {
		if ( ! $this->should_delay( $handle, $src ) ) {
			return $tag;
		}

		// Replace type to prevent execution.
		$tag = str_replace(
			array( "type='text/javascript'", 'type="text/javascript"' ),
			array( "type='sitevitals-delayed'", 'type="sitevitals-delayed"' ),
			$tag
		);

		// If no type attribute, add one.
		if ( false === strpos( $tag, 'type=' ) ) {
			$tag = str_replace( '<script ', '<script type="sitevitals-delayed" ', $tag );
		}

		// Add data attribute for identification.
		$tag = str_replace( '<script ', '<script data-sitevitals-delay="true" ', $tag );

		return $tag;
	}

	/**
	 * Output the loader script that restores delayed scripts on user interaction.
	 */
	public function output_loader_script() {
		$timeout = (int) get_option( 'sitevitals_so_pro_delay_js_timeout', 0 );
		?>
		<script type="text/javascript" id="sitevitals-so-delay-loader">
		(function() {
			var loaded = false;
			var events = ['mousemove', 'scroll', 'click', 'touchstart', 'keydown'];

			function loadDelayed() {
				if (loaded) return;
				loaded = true;

				events.forEach(function(e) {
					document.removeEventListener(e, loadDelayed, {passive: true});
				});

				var scripts = document.querySelectorAll('script[type="sitevitals-delayed"]');
				scripts.forEach(function(oldScript) {
					var newScript = document.createElement('script');
					Array.from(oldScript.attributes).forEach(function(attr) {
						if (attr.name === 'type') {
							newScript.setAttribute('type', 'text/javascript');
						} else if (attr.name !== 'data-sitevitals-delay') {
							newScript.setAttribute(attr.name, attr.value);
						}
					});
					if (oldScript.textContent) {
						newScript.textContent = oldScript.textContent;
					}
					oldScript.parentNode.replaceChild(newScript, oldScript);
				});
			}

			events.forEach(function(e) {
				document.addEventListener(e, loadDelayed, {passive: true});
			});

			<?php if ( $timeout > 0 ) : ?>
			setTimeout(loadDelayed, <?php echo (int) $timeout; ?>);
			<?php endif; ?>
		})();
		</script>
		<?php
	}
}
