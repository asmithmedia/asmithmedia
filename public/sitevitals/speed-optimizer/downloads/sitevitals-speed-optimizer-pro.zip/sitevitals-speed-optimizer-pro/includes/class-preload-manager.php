<?php
/**
 * Preload Manager - adds preload, prefetch, and preconnect hints.
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_SO_Preload_Manager {

	/**
	 * Single instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Get or create the singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );

		if ( ! is_admin() && $this->is_enabled() ) {
			add_action( 'wp_head', array( $this, 'output_preload_hints' ), 1 );
			add_action( 'wp_head', array( $this, 'output_dns_prefetch' ), 1 );
			add_action( 'wp_head', array( $this, 'auto_preload_fonts' ), 2 );
		}
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_preload_enabled', array(
			'type'              => 'boolean',
			'sanitize_callback' => 'rest_sanitize_boolean',
			'default'           => false,
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_preload_rules', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_textarea_field',
			'default'           => '',
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_dns_prefetch_domains', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_textarea_field',
			'default'           => '',
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_preload_fonts_auto', array(
			'type'              => 'boolean',
			'sanitize_callback' => 'rest_sanitize_boolean',
			'default'           => true,
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_preconnect_domains', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_textarea_field',
			'default'           => '',
		) );
	}

	/**
	 * Check if preload is enabled.
	 *
	 * @return bool
	 */
	public function is_enabled() {
		return (bool) get_option( 'sitevitals_so_pro_preload_enabled', false );
	}

	/**
	 * Get custom preload rules.
	 * Format: one URL per line, optionally followed by |type (font, style, script, image).
	 *
	 * @return array Array of arrays with 'url' and 'as' keys.
	 */
	private function get_preload_rules() {
		$raw = get_option( 'sitevitals_so_pro_preload_rules', '' );
		if ( empty( $raw ) ) {
			return array();
		}

		$rules = array();
		$lines = array_filter( array_map( 'trim', explode( "\n", $raw ) ) );

		foreach ( $lines as $line ) {
			$parts = explode( '|', $line, 2 );
			$url   = trim( $parts[0] );
			$as    = isset( $parts[1] ) ? trim( $parts[1] ) : $this->detect_type( $url );

			if ( ! empty( $url ) ) {
				$rules[] = array(
					'url' => $url,
					'as'  => $as,
				);
			}
		}

		return $rules;
	}

	/**
	 * Detect the resource type from URL extension.
	 *
	 * @param string $url The resource URL.
	 * @return string Resource type for as attribute.
	 */
	private function detect_type( $url ) {
		$ext = strtolower( pathinfo( wp_parse_url( $url, PHP_URL_PATH ) ?: '', PATHINFO_EXTENSION ) );

		$type_map = array(
			'woff'  => 'font',
			'woff2' => 'font',
			'ttf'   => 'font',
			'eot'   => 'font',
			'otf'   => 'font',
			'css'   => 'style',
			'js'    => 'script',
			'png'   => 'image',
			'jpg'   => 'image',
			'jpeg'  => 'image',
			'gif'   => 'image',
			'webp'  => 'image',
			'avif'  => 'image',
			'svg'   => 'image',
		);

		return $type_map[ $ext ] ?? 'fetch';
	}

	/**
	 * Output preload and preconnect link tags.
	 */
	public function output_preload_hints() {
		$rules = $this->get_preload_rules();

		foreach ( $rules as $rule ) {
			$crossorigin = '';
			if ( 'font' === $rule['as'] ) {
				$crossorigin = ' crossorigin';
			}

			printf(
				'<link rel="preload" href="%s" as="%s"%s>' . "\n",
				esc_url( $rule['url'] ),
				esc_attr( $rule['as'] ),
				$crossorigin // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static string ' crossorigin' or empty.
			);
		}

		// Preconnect domains.
		$preconnect_raw = get_option( 'sitevitals_so_pro_preconnect_domains', '' );
		if ( ! empty( $preconnect_raw ) ) {
			$domains = array_filter( array_map( 'trim', explode( "\n", $preconnect_raw ) ) );
			foreach ( $domains as $domain ) {
				printf(
					'<link rel="preconnect" href="%s" crossorigin>' . "\n",
					esc_url( $domain )
				);
			}
		}
	}

	/**
	 * Output DNS prefetch link tags for external domains.
	 */
	public function output_dns_prefetch() {
		$raw = get_option( 'sitevitals_so_pro_dns_prefetch_domains', '' );
		if ( empty( $raw ) ) {
			return;
		}

		$domains = array_filter( array_map( 'trim', explode( "\n", $raw ) ) );

		foreach ( $domains as $domain ) {
			printf(
				'<link rel="dns-prefetch" href="%s">' . "\n",
				esc_url( $domain )
			);
		}
	}

	/**
	 * Auto-detect and preload Google Fonts and other font resources.
	 */
	public function auto_preload_fonts() {
		if ( ! (bool) get_option( 'sitevitals_so_pro_preload_fonts_auto', true ) ) {
			return;
		}

		// Preconnect to common font providers.
		$font_domains = array(
			'https://fonts.googleapis.com',
			'https://fonts.gstatic.com',
		);

		foreach ( $font_domains as $domain ) {
			printf(
				'<link rel="preconnect" href="%s" crossorigin>' . "\n",
				esc_url( $domain )
			);
		}

		// Auto-preload fonts from the theme.
		$theme_url = get_stylesheet_directory_uri();
		$theme_dir = get_stylesheet_directory();

		global $wp_filesystem;
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		$fonts_dir = $theme_dir . '/fonts';
		if ( $wp_filesystem->is_dir( $fonts_dir ) ) {
			$font_files = $wp_filesystem->dirlist( $fonts_dir );
			if ( is_array( $font_files ) ) {
				$preloaded = 0;
				foreach ( $font_files as $file ) {
					$ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
					if ( in_array( $ext, array( 'woff2', 'woff' ), true ) && $preloaded < 5 ) {
						printf(
							'<link rel="preload" href="%s" as="font" type="font/%s" crossorigin>' . "\n",
							esc_url( $theme_url . '/fonts/' . $file['name'] ),
							esc_attr( $ext )
						);
						$preloaded++;
					}
				}
			}
		}
	}
}
