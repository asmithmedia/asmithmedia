<?php
/**
 * Unused CSS - tracks and removes unused CSS rules per page type.
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_SO_Unused_CSS {

	/**
	 * Single instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Cache directory relative to wp-content.
	 *
	 * @var string
	 */
	const CACHE_DIR = 'cache/sitevitals-so/unused-css';

	/**
	 * Get or create the singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'wp_ajax_sitevitals_so_pro_scan_unused_css', array( $this, 'ajax_scan' ) );
		add_action( 'wp_ajax_sitevitals_so_pro_purge_unused_css', array( $this, 'ajax_purge' ) );

		// Serve optimized CSS on frontend.
		if ( ! is_admin() && $this->is_enabled() ) {
			add_filter( 'style_loader_src', array( $this, 'maybe_serve_optimized' ), 20, 2 );
		}
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_unused_css_enabled', array(
			'type'              => 'boolean',
			'sanitize_callback' => 'rest_sanitize_boolean',
			'default'           => false,
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_unused_css_exclusions', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_textarea_field',
			'default'           => '',
		) );
	}

	/**
	 * Check if unused CSS removal is enabled.
	 *
	 * @return bool
	 */
	public function is_enabled() {
		return (bool) get_option( 'sitevitals_so_pro_unused_css_enabled', false );
	}

	/**
	 * Get the cache directory path.
	 *
	 * @return string
	 */
	private function get_cache_dir() {
		return WP_CONTENT_DIR . '/' . self::CACHE_DIR;
	}

	/**
	 * Ensure the cache directory exists.
	 *
	 * @return bool
	 */
	private function ensure_cache_dir() {
		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		$cache_dir = $this->get_cache_dir();

		if ( ! $wp_filesystem->is_dir( $cache_dir ) ) {
			return wp_mkdir_p( $cache_dir );
		}

		return true;
	}

	/**
	 * Get exclusions list.
	 *
	 * @return array
	 */
	private function get_exclusions() {
		$exclusions = get_option( 'sitevitals_so_pro_unused_css_exclusions', '' );
		if ( empty( $exclusions ) ) {
			return array();
		}
		return array_filter( array_map( 'trim', explode( "\n", $exclusions ) ) );
	}

	/**
	 * Check if a stylesheet handle is excluded.
	 *
	 * @param string $handle The stylesheet handle.
	 * @param string $src    The stylesheet URL.
	 * @return bool
	 */
	private function is_excluded( $handle, $src ) {
		$exclusions = $this->get_exclusions();
		foreach ( $exclusions as $exclusion ) {
			if ( false !== strpos( $handle, $exclusion ) || false !== strpos( $src, $exclusion ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Serve optimized CSS if available.
	 *
	 * @param string $src    The stylesheet URL.
	 * @param string $handle The stylesheet handle.
	 * @return string
	 */
	public function maybe_serve_optimized( $src, $handle ) {
		if ( $this->is_excluded( $handle, $src ) ) {
			return $src;
		}

		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		$cache_file = $this->get_cache_dir() . '/' . md5( $src ) . '.css';

		if ( $wp_filesystem->exists( $cache_file ) ) {
			return content_url( self::CACHE_DIR . '/' . md5( $src ) . '.css' );
		}

		return $src;
	}

	/**
	 * Scan a URL for unused CSS and generate optimized files.
	 *
	 * @param string $url The page URL to scan.
	 * @return array|WP_Error Scan results or error.
	 */
	public function scan_page( $url ) {
		$response = wp_remote_get( $url, array(
			'timeout'   => 30,
			'sslverify' => false,
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = wp_remote_retrieve_body( $response );
		if ( empty( $body ) ) {
			return new \WP_Error( 'empty_response', __( 'Empty response from URL.', 'sitevitals-speed-optimizer-pro' ) );
		}

		// Extract all CSS selectors used in the HTML.
		$used_selectors = $this->extract_used_selectors( $body );

		// Extract stylesheet URLs.
		$stylesheet_urls = array();
		if ( preg_match_all( '/<link[^>]+rel=["\']stylesheet["\'][^>]+href=["\']([^"\']+)["\'][^>]*>/i', $body, $matches ) ) {
			$stylesheet_urls = $matches[1];
		}
		if ( preg_match_all( '/<link[^>]+href=["\']([^"\']+)["\'][^>]+rel=["\']stylesheet["\'][^>]*>/i', $body, $matches ) ) {
			$stylesheet_urls = array_merge( $stylesheet_urls, $matches[1] );
		}
		$stylesheet_urls = array_unique( $stylesheet_urls );

		$results = array(
			'total_original'  => 0,
			'total_optimized' => 0,
			'files_processed' => 0,
		);

		$exclusions = $this->get_exclusions();

		foreach ( $stylesheet_urls as $css_url ) {
			// Check exclusions.
			$excluded = false;
			foreach ( $exclusions as $exclusion ) {
				if ( false !== strpos( $css_url, $exclusion ) ) {
					$excluded = true;
					break;
				}
			}
			if ( $excluded ) {
				continue;
			}

			// Normalize URL.
			if ( 0 === strpos( $css_url, '//' ) ) {
				$css_url = 'https:' . $css_url;
			} elseif ( 0 === strpos( $css_url, '/' ) ) {
				$css_url = home_url( $css_url );
			}

			$css_response = wp_remote_get( $css_url, array(
				'timeout'   => 15,
				'sslverify' => false,
			) );

			if ( is_wp_error( $css_response ) ) {
				continue;
			}

			$original_css = wp_remote_retrieve_body( $css_response );
			if ( empty( $original_css ) ) {
				continue;
			}

			$original_size = strlen( $original_css );
			$optimized_css = $this->remove_unused_rules( $original_css, $used_selectors );
			$optimized_size = strlen( $optimized_css );

			$results['total_original']  += $original_size;
			$results['total_optimized'] += $optimized_size;
			$results['files_processed']++;

			// Save optimized version.
			$this->save_optimized_css( $css_url, $optimized_css );
		}

		$results['savings']         = $results['total_original'] - $results['total_optimized'];
		$results['savings_percent'] = $results['total_original'] > 0
			? round( ( $results['savings'] / $results['total_original'] ) * 100, 1 )
			: 0;

		// Store results.
		update_option( 'sitevitals_so_pro_unused_css_results', $results );

		return $results;
	}

	/**
	 * Extract CSS selectors that are actually used in the HTML.
	 *
	 * @param string $html The page HTML.
	 * @return array Array of used selector parts.
	 */
	private function extract_used_selectors( $html ) {
		$used = array();

		// Extract IDs.
		if ( preg_match_all( '/\bid=["\']([^"\']+)["\']/i', $html, $matches ) ) {
			foreach ( $matches[1] as $id ) {
				$used[] = '#' . $id;
			}
		}

		// Extract classes.
		if ( preg_match_all( '/\bclass=["\']([^"\']+)["\']/i', $html, $matches ) ) {
			foreach ( $matches[1] as $class_list ) {
				$classes = preg_split( '/\s+/', $class_list );
				foreach ( $classes as $class ) {
					$class = trim( $class );
					if ( ! empty( $class ) ) {
						$used[] = '.' . $class;
					}
				}
			}
		}

		// Extract tag names.
		if ( preg_match_all( '/<([a-z][a-z0-9]*)\b/i', $html, $matches ) ) {
			$used = array_merge( $used, array_unique( array_map( 'strtolower', $matches[1] ) ) );
		}

		return array_unique( $used );
	}

	/**
	 * Remove unused CSS rules based on used selectors.
	 *
	 * @param string $css            The original CSS.
	 * @param array  $used_selectors Selectors found in HTML.
	 * @return string Optimized CSS.
	 */
	private function remove_unused_rules( $css, $used_selectors ) {
		// Remove comments.
		$css = preg_replace( '/\/\*.*?\*\//s', '', $css );

		$optimized = '';
		$pattern   = '/([^{]+)\{([^}]*)\}/s';

		if ( preg_match_all( $pattern, $css, $matches, PREG_SET_ORDER ) ) {
			foreach ( $matches as $match ) {
				$selector = trim( $match[1] );
				$rules    = $match[2];

				// Always keep at-rules, keyframes, font-face.
				if ( 0 === strpos( $selector, '@' ) ) {
					$optimized .= $selector . '{' . $rules . '}' . "\n";
					continue;
				}

				// Check if any part of the selector is used.
				$is_used = false;
				foreach ( $used_selectors as $used ) {
					if ( false !== strpos( $selector, $used ) ) {
						$is_used = true;
						break;
					}
				}

				// Always keep universal and element selectors for common tags.
				$common_tags = array( 'html', 'body', '*', ':root', 'a', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'img', 'ul', 'ol', 'li', 'table', 'form', 'input', 'button', 'select', 'textarea' );
				if ( ! $is_used ) {
					$sel_lower = strtolower( trim( $selector ) );
					foreach ( $common_tags as $tag ) {
						if ( $sel_lower === $tag || 0 === strpos( $sel_lower, $tag . ' ' ) || 0 === strpos( $sel_lower, $tag . ',' ) || 0 === strpos( $sel_lower, $tag . ':' ) ) {
							$is_used = true;
							break;
						}
					}
				}

				if ( $is_used ) {
					$optimized .= $selector . '{' . $rules . '}' . "\n";
				}
			}
		}

		return $optimized;
	}

	/**
	 * Save optimized CSS to cache.
	 *
	 * @param string $original_url The original CSS URL.
	 * @param string $css          The optimized CSS.
	 * @return bool
	 */
	private function save_optimized_css( $original_url, $css ) {
		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		if ( ! $this->ensure_cache_dir() ) {
			return false;
		}

		$filepath = $this->get_cache_dir() . '/' . md5( $original_url ) . '.css';

		return $wp_filesystem->put_contents( $filepath, $css, FS_CHMOD_FILE );
	}

	/**
	 * Get scan statistics.
	 *
	 * @return array
	 */
	public function get_stats() {
		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		$results = get_option( 'sitevitals_so_pro_unused_css_results', array() );
		$stats   = array(
			'enabled'         => $this->is_enabled(),
			'files'           => 0,
			'total_size'      => 0,
			'savings'         => $results['savings'] ?? 0,
			'savings_percent' => $results['savings_percent'] ?? 0,
		);

		$cache_dir = $this->get_cache_dir();
		if ( $wp_filesystem->is_dir( $cache_dir ) ) {
			$files = $wp_filesystem->dirlist( $cache_dir );
			if ( is_array( $files ) ) {
				foreach ( $files as $file ) {
					if ( '.css' === substr( $file['name'], -4 ) ) {
						$stats['files']++;
						$stats['total_size'] += $file['size'];
					}
				}
			}
		}

		return $stats;
	}

	/**
	 * AJAX: Scan for unused CSS.
	 */
	public function ajax_scan() {
		check_ajax_referer( 'sitevitals_so_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Unauthorized.', 'sitevitals-speed-optimizer-pro' ) );
		}

		$url = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : home_url( '/' );

		$results = $this->scan_page( $url );

		if ( is_wp_error( $results ) ) {
			wp_send_json_error( $results->get_error_message() );
		}

		wp_send_json_success( array(
			'results' => $results,
			/* translators: %s: percentage of CSS savings */
			'message' => sprintf( __( 'Removed %s%% unused CSS.', 'sitevitals-speed-optimizer-pro' ), $results['savings_percent'] ),
		) );
	}

	/**
	 * AJAX: Purge all optimized CSS files.
	 */
	public function ajax_purge() {
		check_ajax_referer( 'sitevitals_so_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Unauthorized.', 'sitevitals-speed-optimizer-pro' ) );
		}

		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		$cache_dir = $this->get_cache_dir();
		$deleted   = 0;

		if ( $wp_filesystem->is_dir( $cache_dir ) ) {
			$files = $wp_filesystem->dirlist( $cache_dir );
			if ( is_array( $files ) ) {
				foreach ( $files as $file ) {
					if ( '.css' === substr( $file['name'], -4 ) ) {
						$wp_filesystem->delete( $cache_dir . '/' . $file['name'] );
						$deleted++;
					}
				}
			}
		}

		delete_option( 'sitevitals_so_pro_unused_css_results' );

		wp_send_json_success( array(
			'deleted' => $deleted,
			/* translators: %d: number of files deleted */
			'message' => sprintf( __( 'Purged %d optimized CSS files.', 'sitevitals-speed-optimizer-pro' ), $deleted ),
		) );
	}
}
