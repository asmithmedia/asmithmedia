<?php
/**
 * Scheduled DB - automated database cleanup via WP Cron.
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_SO_Scheduled_DB {

	/**
	 * Single instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Get or create the singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_init', array( $this, 'schedule_cleanup' ) );
		add_action( 'sitevitals_so_pro_scheduled_db_cleanup', array( $this, 'run_cleanup' ) );
		add_filter( 'cron_schedules', array( $this, 'add_cron_schedules' ) );
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_scheduled_db_enabled', array(
			'type'              => 'boolean',
			'sanitize_callback' => 'rest_sanitize_boolean',
			'default'           => false,
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_scheduled_db_frequency', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => 'weekly',
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_scheduled_db_email', array(
			'type'              => 'boolean',
			'sanitize_callback' => 'rest_sanitize_boolean',
			'default'           => false,
		) );
	}

	/**
	 * Add custom cron schedules.
	 *
	 * @param array $schedules Existing cron schedules.
	 * @return array
	 */
	public function add_cron_schedules( $schedules ) {
		if ( ! isset( $schedules['monthly'] ) ) {
			$schedules['monthly'] = array(
				'interval' => 30 * DAY_IN_SECONDS,
				'display'  => __( 'Once Monthly', 'sitevitals-speed-optimizer-pro' ),
			);
		}
		return $schedules;
	}

	/**
	 * Schedule or reschedule the cleanup cron based on settings.
	 */
	public function schedule_cleanup() {
		$enabled   = (bool) get_option( 'sitevitals_so_pro_scheduled_db_enabled', false );
		$frequency = get_option( 'sitevitals_so_pro_scheduled_db_frequency', 'weekly' );

		$hook = 'sitevitals_so_pro_scheduled_db_cleanup';

		if ( ! $enabled ) {
			wp_clear_scheduled_hook( $hook );
			return;
		}

		$next = wp_next_scheduled( $hook );

		if ( $next ) {
			// Check if frequency changed.
			$current_frequency = get_option( 'sitevitals_so_pro_scheduled_db_last_frequency', '' );
			if ( $current_frequency === $frequency ) {
				return;
			}
			wp_clear_scheduled_hook( $hook );
		}

		$valid_frequencies = array( 'daily', 'weekly', 'monthly' );
		if ( ! in_array( $frequency, $valid_frequencies, true ) ) {
			$frequency = 'weekly';
		}

		wp_schedule_event( time() + HOUR_IN_SECONDS, $frequency, $hook );
		update_option( 'sitevitals_so_pro_scheduled_db_last_frequency', $frequency );
	}

	/**
	 * Run the scheduled database cleanup.
	 */
	public function run_cleanup() {
		global $wpdb;

		$results = array(
			'revisions'      => 0,
			'auto_drafts'    => 0,
			'trash_posts'    => 0,
			'transients'     => 0,
			'spam_comments'  => 0,
			'trash_comments' => 0,
		);

		// Clean revisions.
		$revisions = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			"DELETE FROM {$wpdb->posts} WHERE post_type = 'revision'" // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- No user input, static query.
		);
		$results['revisions'] = (int) $revisions;

		// Clean auto-drafts.
		$auto_drafts = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			"DELETE FROM {$wpdb->posts} WHERE post_status = 'auto-draft'" // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- No user input, static query.
		);
		$results['auto_drafts'] = (int) $auto_drafts;

		// Clean trashed posts.
		$trash_posts = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			"DELETE FROM {$wpdb->posts} WHERE post_status = 'trash'" // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- No user input, static query.
		);
		$results['trash_posts'] = (int) $trash_posts;

		// Clean expired transients.
		$transients = $wpdb->query( $wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			"DELETE a, b FROM {$wpdb->options} a, {$wpdb->options} b
			WHERE a.option_name LIKE %s
			AND a.option_name NOT LIKE %s
			AND b.option_name = CONCAT('_transient_timeout_', SUBSTRING(a.option_name, 12))
			AND b.option_value < %d",
			$wpdb->esc_like( '_transient_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_' ) . '%',
			time()
		) );
		$results['transients'] = (int) $transients;

		// Clean spam comments.
		$spam_comments = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			"DELETE FROM {$wpdb->comments} WHERE comment_approved = 'spam'" // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- No user input, static query.
		);
		$results['spam_comments'] = (int) $spam_comments;

		// Clean trashed comments.
		$trash_comments = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			"DELETE FROM {$wpdb->comments} WHERE comment_approved = 'trash'" // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- No user input, static query.
		);
		$results['trash_comments'] = (int) $trash_comments;

		// Optimize tables.
		$tables = $wpdb->get_results( 'SHOW TABLES', ARRAY_N ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- SHOW TABLES does not accept parameters.
		if ( $tables ) {
			foreach ( $tables as $table ) {
				$wpdb->query( "OPTIMIZE TABLE {$table[0]}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from SHOW TABLES result, not user input.
			}
		}

		// Log results.
		$results['timestamp'] = current_time( 'mysql' );
		$log = get_option( 'sitevitals_so_pro_db_cleanup_log', array() );
		$log[] = $results;

		// Keep last 30 entries.
		if ( count( $log ) > 30 ) {
			$log = array_slice( $log, -30 );
		}
		update_option( 'sitevitals_so_pro_db_cleanup_log', $log );

		// Send email notification if enabled.
		$send_email = (bool) get_option( 'sitevitals_so_pro_scheduled_db_email', false );
		if ( $send_email ) {
			$this->send_cleanup_email( $results );
		}
	}

	/**
	 * Send cleanup completion email.
	 *
	 * @param array $results Cleanup results.
	 */
	private function send_cleanup_email( $results ) {
		$email   = get_option( 'admin_email' );
		$subject = __( '[SiteVitals] Scheduled Database Cleanup Complete', 'sitevitals-speed-optimizer-pro' );

		$total = $results['revisions'] + $results['auto_drafts'] + $results['trash_posts']
			+ $results['transients'] + $results['spam_comments'] + $results['trash_comments'];

		$body  = '<html><body style="font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;color:#1e293b;">';
		$body .= '<h2 style="color:#6366f1;">' . esc_html__( 'Database Cleanup Complete', 'sitevitals-speed-optimizer-pro' ) . '</h2>';
		$body .= '<p>' . esc_html( get_bloginfo( 'name' ) ) . ' — ' . esc_html( current_time( 'F j, Y g:i A' ) ) . '</p>';
		$body .= '<table style="width:100%;border-collapse:collapse;margin:16px 0;">';
		$body .= '<tr style="background:#f8fafc;"><th style="text-align:left;padding:8px;border-bottom:1px solid #e2e8f0;">' . esc_html__( 'Type', 'sitevitals-speed-optimizer-pro' ) . '</th>';
		$body .= '<th style="text-align:right;padding:8px;border-bottom:1px solid #e2e8f0;">' . esc_html__( 'Cleaned', 'sitevitals-speed-optimizer-pro' ) . '</th></tr>';

		$types = array(
			'revisions'      => __( 'Post Revisions', 'sitevitals-speed-optimizer-pro' ),
			'auto_drafts'    => __( 'Auto-Drafts', 'sitevitals-speed-optimizer-pro' ),
			'trash_posts'    => __( 'Trashed Posts', 'sitevitals-speed-optimizer-pro' ),
			'transients'     => __( 'Expired Transients', 'sitevitals-speed-optimizer-pro' ),
			'spam_comments'  => __( 'Spam Comments', 'sitevitals-speed-optimizer-pro' ),
			'trash_comments' => __( 'Trashed Comments', 'sitevitals-speed-optimizer-pro' ),
		);

		foreach ( $types as $key => $label ) {
			$body .= '<tr><td style="padding:8px;border-bottom:1px solid #e2e8f0;">' . esc_html( $label ) . '</td>';
			$body .= '<td style="text-align:right;padding:8px;border-bottom:1px solid #e2e8f0;">' . esc_html( $results[ $key ] ) . '</td></tr>';
		}

		$body .= '<tr style="font-weight:bold;"><td style="padding:8px;">' . esc_html__( 'Total', 'sitevitals-speed-optimizer-pro' ) . '</td>';
		$body .= '<td style="text-align:right;padding:8px;">' . esc_html( $total ) . '</td></tr>';
		$body .= '</table>';
		$body .= '<p style="color:#6b7280;font-size:13px;">' . esc_html__( 'This is an automated notification from SiteVitals Speed Optimizer Pro.', 'sitevitals-speed-optimizer-pro' ) . '</p>';
		$body .= '</body></html>';

		$headers = array( 'Content-Type: text/html; charset=UTF-8' );
		wp_mail( $email, $subject, $body, $headers );
	}

	/**
	 * Get the last cleanup log entry.
	 *
	 * @return array|null
	 */
	public function get_last_cleanup() {
		$log = get_option( 'sitevitals_so_pro_db_cleanup_log', array() );
		if ( empty( $log ) ) {
			return null;
		}
		return end( $log );
	}

	/**
	 * Get the next scheduled cleanup time.
	 *
	 * @return int|false Timestamp or false.
	 */
	public function get_next_scheduled() {
		return wp_next_scheduled( 'sitevitals_so_pro_scheduled_db_cleanup' );
	}
}
