<?php
/**
 * Image Converter - WebP and AVIF conversion for uploaded images.
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_SO_Image_Converter {

	/**
	 * Single instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Get or create the singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );

		// Convert on upload.
		if ( $this->is_enabled() ) {
			add_filter( 'wp_handle_upload', array( $this, 'convert_on_upload' ) );
			add_filter( 'wp_get_attachment_url', array( $this, 'maybe_serve_webp_url' ), 10, 2 );
		}

		// AJAX endpoints.
		add_action( 'wp_ajax_sitevitals_so_pro_bulk_convert_images', array( $this, 'ajax_bulk_convert' ) );
		add_action( 'wp_ajax_sitevitals_so_pro_image_stats', array( $this, 'ajax_get_stats' ) );

		// Rewrite rules for .htaccess based serving.
		add_action( 'wp_ajax_sitevitals_so_pro_generate_htaccess', array( $this, 'ajax_generate_htaccess' ) );
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_image_convert_enabled', array(
			'type'              => 'boolean',
			'sanitize_callback' => 'rest_sanitize_boolean',
			'default'           => false,
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_image_format', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => 'webp',
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_image_quality', array(
			'type'              => 'integer',
			'sanitize_callback' => 'absint',
			'default'           => 82,
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_image_max_width', array(
			'type'              => 'integer',
			'sanitize_callback' => 'absint',
			'default'           => 2560,
		) );
	}

	/**
	 * Check if image conversion is enabled.
	 *
	 * @return bool
	 */
	public function is_enabled() {
		return (bool) get_option( 'sitevitals_so_pro_image_convert_enabled', false );
	}

	/**
	 * Get the target format.
	 *
	 * @return string webp or avif.
	 */
	private function get_format() {
		return get_option( 'sitevitals_so_pro_image_format', 'webp' );
	}

	/**
	 * Get the quality setting.
	 *
	 * @return int Quality 1-100.
	 */
	private function get_quality() {
		return (int) get_option( 'sitevitals_so_pro_image_quality', 82 );
	}

	/**
	 * Get the max width setting.
	 *
	 * @return int Max width in pixels.
	 */
	private function get_max_width() {
		return (int) get_option( 'sitevitals_so_pro_image_max_width', 2560 );
	}

	/**
	 * Check if the server supports the target format.
	 *
	 * @param string $format The format to check (webp or avif).
	 * @return bool
	 */
	public function supports_format( $format ) {
		if ( ! function_exists( 'gd_info' ) ) {
			return false;
		}

		$gd = gd_info();

		if ( 'webp' === $format ) {
			return ! empty( $gd['WebP Support'] );
		}

		if ( 'avif' === $format ) {
			return ! empty( $gd['AVIF Support'] );
		}

		return false;
	}

	/**
	 * Convert image on upload.
	 *
	 * @param array $upload Upload data from wp_handle_upload.
	 * @return array Modified upload data.
	 */
	public function convert_on_upload( $upload ) {
		if ( ! isset( $upload['type'] ) ) {
			return $upload;
		}

		$allowed_types = array( 'image/jpeg', 'image/png', 'image/gif' );
		if ( ! in_array( $upload['type'], $allowed_types, true ) ) {
			return $upload;
		}

		$format = $this->get_format();
		if ( ! $this->supports_format( $format ) ) {
			return $upload;
		}

		$converted_path = $this->convert_image( $upload['file'], $format );

		if ( $converted_path && ! is_wp_error( $converted_path ) ) {
			// Track conversion stats.
			$this->track_conversion( $upload['file'], $converted_path );
		}

		return $upload;
	}

	/**
	 * Convert an image file to the target format.
	 *
	 * @param string $source_path The source image path.
	 * @param string $format      Target format (webp or avif).
	 * @return string|WP_Error Converted file path or error.
	 */
	public function convert_image( $source_path, $format = null ) {
		if ( null === $format ) {
			$format = $this->get_format();
		}

		if ( ! $this->supports_format( $format ) ) {
			return new \WP_Error(
				'unsupported_format',
				/* translators: %s: image format name */
				sprintf( __( 'Server does not support %s format.', 'sitevitals-speed-optimizer-pro' ), strtoupper( $format ) )
			);
		}

		$editor = wp_get_image_editor( $source_path );
		if ( is_wp_error( $editor ) ) {
			return $editor;
		}

		// Resize if needed.
		$max_width = $this->get_max_width();
		$size      = $editor->get_size();
		if ( $size['width'] > $max_width ) {
			$editor->resize( $max_width, null );
		}

		$quality = $this->get_quality();
		$editor->set_quality( $quality );

		// Generate output path.
		$info            = pathinfo( $source_path );
		$converted_path  = $info['dirname'] . '/' . $info['filename'] . '.' . $format;

		$mime = 'webp' === $format ? 'image/webp' : 'image/avif';

		$result = $editor->save( $converted_path, $mime );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $result['path'];
	}

	/**
	 * Track conversion statistics.
	 *
	 * @param string $original_path  The original file path.
	 * @param string $converted_path The converted file path.
	 */
	private function track_conversion( $original_path, $converted_path ) {
		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		$stats = get_option( 'sitevitals_so_pro_image_stats', array(
			'total_converted'  => 0,
			'total_original'   => 0,
			'total_optimized'  => 0,
		) );

		$original_size  = $wp_filesystem->size( $original_path );
		$converted_size = $wp_filesystem->size( $converted_path );

		if ( false !== $original_size && false !== $converted_size ) {
			$stats['total_converted']++;
			$stats['total_original']  += $original_size;
			$stats['total_optimized'] += $converted_size;
		}

		update_option( 'sitevitals_so_pro_image_stats', $stats );
	}

	/**
	 * Serve WebP/AVIF URL if converted version exists.
	 *
	 * @param string $url           The original attachment URL.
	 * @param int    $attachment_id The attachment ID.
	 * @return string
	 */
	public function maybe_serve_webp_url( $url, $attachment_id ) {
		// Only rewrite if the browser supports the format.
		$format   = $this->get_format();
		$accepted = isset( $_SERVER['HTTP_ACCEPT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_ACCEPT'] ) ) : '';

		if ( 'webp' === $format && false === strpos( $accepted, 'image/webp' ) ) {
			return $url;
		}
		if ( 'avif' === $format && false === strpos( $accepted, 'image/avif' ) ) {
			return $url;
		}

		// Check if converted file exists.
		$file_path = get_attached_file( $attachment_id );
		if ( ! $file_path ) {
			return $url;
		}

		$info           = pathinfo( $file_path );
		$converted_path = $info['dirname'] . '/' . $info['filename'] . '.' . $format;

		global $wp_filesystem;
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		if ( $wp_filesystem->exists( $converted_path ) ) {
			$url_info = pathinfo( $url );
			return $url_info['dirname'] . '/' . $url_info['filename'] . '.' . $format;
		}

		return $url;
	}

	/**
	 * Get conversion statistics.
	 *
	 * @return array
	 */
	public function get_stats() {
		$stats = get_option( 'sitevitals_so_pro_image_stats', array(
			'total_converted' => 0,
			'total_original'  => 0,
			'total_optimized' => 0,
		) );

		$stats['savings'] = $stats['total_original'] - $stats['total_optimized'];
		$stats['savings_percent'] = $stats['total_original'] > 0
			? round( ( $stats['savings'] / $stats['total_original'] ) * 100, 1 )
			: 0;
		$stats['enabled']    = $this->is_enabled();
		$stats['format']     = $this->get_format();
		$stats['webp_support']  = $this->supports_format( 'webp' );
		$stats['avif_support']  = $this->supports_format( 'avif' );

		return $stats;
	}

	/**
	 * AJAX: Bulk convert existing images.
	 */
	public function ajax_bulk_convert() {
		check_ajax_referer( 'sitevitals_so_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Unauthorized.', 'sitevitals-speed-optimizer-pro' ) );
		}

		$format = $this->get_format();
		if ( ! $this->supports_format( $format ) ) {
			wp_send_json_error(
				/* translators: %s: image format name */
				sprintf( __( 'Server does not support %s format.', 'sitevitals-speed-optimizer-pro' ), strtoupper( $format ) )
			);
		}

		$batch_size = isset( $_POST['batch_size'] ) ? absint( $_POST['batch_size'] ) : 10;
		$offset     = isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0;

		$args = array(
			'post_type'      => 'attachment',
			'post_mime_type' => array( 'image/jpeg', 'image/png', 'image/gif' ),
			'post_status'    => 'inherit',
			'posts_per_page' => $batch_size,
			'offset'         => $offset,
			'fields'         => 'ids',
		);

		$attachments = get_posts( $args ); // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- Batch size is admin-controlled and capped.

		$converted = 0;
		$skipped   = 0;
		$errors    = 0;

		global $wp_filesystem;
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		foreach ( $attachments as $attachment_id ) {
			$file_path = get_attached_file( $attachment_id );
			if ( ! $file_path || ! $wp_filesystem->exists( $file_path ) ) {
				$skipped++;
				continue;
			}

			$info           = pathinfo( $file_path );
			$converted_path = $info['dirname'] . '/' . $info['filename'] . '.' . $format;

			// Skip if already converted.
			if ( $wp_filesystem->exists( $converted_path ) ) {
				$skipped++;
				continue;
			}

			$result = $this->convert_image( $file_path, $format );
			if ( is_wp_error( $result ) ) {
				$errors++;
			} else {
				$this->track_conversion( $file_path, $result );
				$converted++;
			}
		}

		// Count total remaining.
		$total_args = array(
			'post_type'      => 'attachment',
			'post_mime_type' => array( 'image/jpeg', 'image/png', 'image/gif' ),
			'post_status'    => 'inherit',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		);
		$total = count( get_posts( $total_args ) ); // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- Count query for total images.

		wp_send_json_success( array(
			'converted' => $converted,
			'skipped'   => $skipped,
			'errors'    => $errors,
			'total'     => $total,
			'offset'    => $offset + $batch_size,
			'has_more'  => count( $attachments ) === $batch_size,
			/* translators: %d: number of images converted */
			'message'   => sprintf( __( 'Converted %d images.', 'sitevitals-speed-optimizer-pro' ), $converted ),
		) );
	}

	/**
	 * AJAX: Get image conversion stats.
	 */
	public function ajax_get_stats() {
		check_ajax_referer( 'sitevitals_so_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Unauthorized.', 'sitevitals-speed-optimizer-pro' ) );
		}

		wp_send_json_success( $this->get_stats() );
	}

	/**
	 * AJAX: Generate .htaccess rewrite rules for WebP/AVIF.
	 */
	public function ajax_generate_htaccess() {
		check_ajax_referer( 'sitevitals_so_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Unauthorized.', 'sitevitals-speed-optimizer-pro' ) );
		}

		$format = $this->get_format();

		$rules  = "# SiteVitals Speed Optimizer Pro - " . strtoupper( $format ) . " Rewrite\n";
		$rules .= "<IfModule mod_rewrite.c>\n";
		$rules .= "  RewriteEngine On\n";
		$rules .= "  RewriteCond %{HTTP_ACCEPT} image/" . $format . "\n";
		$rules .= "  RewriteCond %{REQUEST_FILENAME} \\.(jpe?g|png|gif)$\n";
		$rules .= "  RewriteCond %{REQUEST_FILENAME}." . $format . " -f\n";
		$rules .= "  RewriteRule ^(.+)\\.(jpe?g|png|gif)$ $1." . $format . " [T=image/" . $format . ",E=REQUEST_image,L]\n";
		$rules .= "</IfModule>\n";
		$rules .= "\n<IfModule mod_headers.c>\n";
		$rules .= "  Header append Vary Accept env=REQUEST_image\n";
		$rules .= "</IfModule>\n";
		$rules .= "# END SiteVitals Speed Optimizer Pro\n";

		wp_send_json_success( array(
			'rules' => $rules,
		) );
	}
}
