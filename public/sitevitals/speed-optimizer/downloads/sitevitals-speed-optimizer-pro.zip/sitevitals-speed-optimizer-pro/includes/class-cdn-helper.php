<?php
/**
 * CDN Helper - rewrites static asset URLs to a CDN domain.
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_SO_CDN_Helper {

	/**
	 * Single instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Get or create the singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'wp_ajax_sitevitals_so_pro_test_cdn', array( $this, 'ajax_test_cdn' ) );

		if ( ! is_admin() && $this->is_enabled() ) {
			add_filter( 'style_loader_src', array( $this, 'rewrite_url' ), 100 );
			add_filter( 'script_loader_src', array( $this, 'rewrite_url' ), 100 );
			add_filter( 'wp_get_attachment_url', array( $this, 'rewrite_url' ), 100 );
			add_filter( 'the_content', array( $this, 'rewrite_content_urls' ), 100 );
		}
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_cdn_enabled', array(
			'type'              => 'boolean',
			'sanitize_callback' => 'rest_sanitize_boolean',
			'default'           => false,
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_cdn_url', array(
			'type'              => 'string',
			'sanitize_callback' => 'esc_url_raw',
			'default'           => '',
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_cdn_directories', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_textarea_field',
			'default'           => "wp-content/uploads\nwp-content/themes\nwp-content/plugins\nwp-includes",
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_cdn_excluded_extensions', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_textarea_field',
			'default'           => "php\nxml\nxsl",
		) );
	}

	/**
	 * Check if CDN is enabled and configured.
	 *
	 * @return bool
	 */
	public function is_enabled() {
		if ( ! (bool) get_option( 'sitevitals_so_pro_cdn_enabled', false ) ) {
			return false;
		}
		$cdn_url = get_option( 'sitevitals_so_pro_cdn_url', '' );
		return ! empty( $cdn_url );
	}

	/**
	 * Get the CDN URL.
	 *
	 * @return string
	 */
	private function get_cdn_url() {
		return untrailingslashit( get_option( 'sitevitals_so_pro_cdn_url', '' ) );
	}

	/**
	 * Get the site URL for rewriting.
	 *
	 * @return string
	 */
	private function get_site_url() {
		return untrailingslashit( home_url() );
	}

	/**
	 * Get the list of directories to rewrite.
	 *
	 * @return array
	 */
	private function get_included_directories() {
		$raw = get_option( 'sitevitals_so_pro_cdn_directories', "wp-content/uploads\nwp-content/themes\nwp-content/plugins\nwp-includes" );
		return array_filter( array_map( 'trim', explode( "\n", $raw ) ) );
	}

	/**
	 * Get excluded file extensions.
	 *
	 * @return array
	 */
	private function get_excluded_extensions() {
		$raw = get_option( 'sitevitals_so_pro_cdn_excluded_extensions', "php\nxml\nxsl" );
		return array_filter( array_map( 'trim', explode( "\n", $raw ) ) );
	}

	/**
	 * Check if a URL should be rewritten to CDN.
	 *
	 * @param string $url The URL to check.
	 * @return bool
	 */
	private function should_rewrite( $url ) {
		$site_url = $this->get_site_url();

		// Only rewrite URLs from our own site.
		if ( false === strpos( $url, $site_url ) ) {
			return false;
		}

		// Check if URL is in an included directory.
		$directories = $this->get_included_directories();
		$in_directory = false;
		foreach ( $directories as $dir ) {
			if ( false !== strpos( $url, $dir ) ) {
				$in_directory = true;
				break;
			}
		}
		if ( ! $in_directory ) {
			return false;
		}

		// Check excluded extensions.
		$ext = strtolower( pathinfo( wp_parse_url( $url, PHP_URL_PATH ) ?: '', PATHINFO_EXTENSION ) );
		$excluded = $this->get_excluded_extensions();
		if ( in_array( $ext, $excluded, true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Rewrite a single URL to use CDN.
	 *
	 * @param string $url The original URL.
	 * @return string The rewritten URL.
	 */
	public function rewrite_url( $url ) {
		if ( ! $this->should_rewrite( $url ) ) {
			return $url;
		}

		return str_replace( $this->get_site_url(), $this->get_cdn_url(), $url );
	}

	/**
	 * Rewrite URLs in post content.
	 *
	 * @param string $content The post content.
	 * @return string Modified content.
	 */
	public function rewrite_content_urls( $content ) {
		$site_url = preg_quote( $this->get_site_url(), '/' );
		$cdn_url  = $this->get_cdn_url();

		$directories = $this->get_included_directories();
		$dir_pattern = implode( '|', array_map( 'preg_quote', $directories ) );

		$pattern = '/(' . $site_url . '\/(?:' . $dir_pattern . ')\/[^\s"\'<>]+)/i';

		return preg_replace_callback( $pattern, function ( $matches ) use ( $cdn_url ) {
			$url = $matches[1];

			// Check excluded extensions.
			$ext = strtolower( pathinfo( wp_parse_url( $url, PHP_URL_PATH ) ?: '', PATHINFO_EXTENSION ) );
			$excluded = $this->get_excluded_extensions();
			if ( in_array( $ext, $excluded, true ) ) {
				return $url;
			}

			return str_replace( $this->get_site_url(), $cdn_url, $url );
		}, $content );
	}

	/**
	 * AJAX: Test CDN connectivity.
	 */
	public function ajax_test_cdn() {
		check_ajax_referer( 'sitevitals_so_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Unauthorized.', 'sitevitals-speed-optimizer-pro' ) );
		}

		$cdn_url = $this->get_cdn_url();
		if ( empty( $cdn_url ) ) {
			wp_send_json_error( __( 'CDN URL is not configured.', 'sitevitals-speed-optimizer-pro' ) );
		}

		// Try to fetch a known resource through CDN.
		$test_url = $cdn_url . '/wp-includes/css/dashicons.min.css';

		$response = wp_remote_head( $test_url, array(
			'timeout'   => 10,
			'sslverify' => true,
		) );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error(
				/* translators: %s: error message */
				sprintf( __( 'CDN test failed: %s', 'sitevitals-speed-optimizer-pro' ), $response->get_error_message() )
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code >= 200 && $code < 400 ) {
			wp_send_json_success( __( 'CDN is working correctly!', 'sitevitals-speed-optimizer-pro' ) );
		}

		wp_send_json_error(
			/* translators: %d: HTTP status code */
			sprintf( __( 'CDN returned HTTP %d.', 'sitevitals-speed-optimizer-pro' ), $code )
		);
	}
}
