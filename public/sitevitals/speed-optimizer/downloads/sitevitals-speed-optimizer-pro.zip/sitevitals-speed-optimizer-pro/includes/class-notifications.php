<?php
/**
 * Notifications - Slack webhook and email alerts for performance events.
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_SO_Notifications {

	/**
	 * Single instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Get or create the singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'sitevitals_so_after_score_calculation', array( $this, 'notify_score_drop' ) );
		add_action( 'sitevitals_so_pro_optimization_complete', array( $this, 'notify_optimization_complete' ), 10, 2 );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'wp_ajax_sitevitals_so_pro_test_slack', array( $this, 'ajax_test_slack' ) );
	}

	/**
	 * Register notification settings.
	 */
	public function register_settings() {
		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_slack_webhook', array(
			'type'              => 'string',
			'sanitize_callback' => 'esc_url_raw',
			'default'           => '',
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_alert_email', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_email',
			'default'           => '',
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_alert_threshold', array(
			'type'              => 'integer',
			'sanitize_callback' => 'absint',
			'default'           => 50,
		) );
	}

	/**
	 * Send a Slack notification.
	 *
	 * @param string $message Message text.
	 * @param string $color   Attachment color (hex).
	 * @return bool
	 */
	public function send_slack( $message, $color = '#ef4444' ) {
		$webhook_url = get_option( 'sitevitals_so_pro_slack_webhook', '' );
		if ( empty( $webhook_url ) ) {
			return false;
		}

		$payload = array(
			'username'    => 'SiteVitals Speed Optimizer',
			'icon_emoji'  => ':rocket:',
			'attachments' => array(
				array(
					'color'  => $color,
					'text'   => $message,
					'footer' => get_bloginfo( 'name' ) . ' | ' . home_url(),
					'ts'     => time(),
				),
			),
		);

		$response = wp_remote_post( $webhook_url, array(
			'body'    => wp_json_encode( $payload ),
			'headers' => array( 'Content-Type' => 'application/json' ),
			'timeout' => 10,
		) );

		return ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response );
	}

	/**
	 * Send an alert email.
	 *
	 * @param string $subject Email subject.
	 * @param string $body    Pre-built HTML email body.
	 */
	public function send_alert_email( $subject, $body ) {
		$email = get_option( 'sitevitals_so_pro_alert_email', '' );
		if ( empty( $email ) ) {
			$email = get_option( 'admin_email' );
		}

		$headers = array( 'Content-Type: text/html; charset=UTF-8' );

		wp_mail( $email, '[SiteVitals SO] ' . $subject, $body, $headers );
	}

	/**
	 * Notify when performance score drops below threshold.
	 *
	 * @param array $results Score calculation results.
	 */
	public function notify_score_drop( $results ) {
		$threshold = (int) get_option( 'sitevitals_so_pro_alert_threshold', 50 );
		$score     = isset( $results['score'] ) ? (int) $results['score'] : 100;

		if ( $score >= $threshold ) {
			return;
		}

		// Prevent duplicate alerts.
		$last_alert = get_transient( 'sitevitals_so_pro_last_score_alert' );
		if ( false !== $last_alert ) {
			return;
		}
		set_transient( 'sitevitals_so_pro_last_score_alert', $score, DAY_IN_SECONDS );

		// Slack alert.
		$slack_msg = sprintf(
			/* translators: 1: performance score, 2: threshold */
			__( 'Performance score dropped to %1$d/100 (below threshold of %2$d).', 'sitevitals-speed-optimizer-pro' ),
			$score,
			$threshold
		);
		$this->send_slack( $slack_msg, '#ef4444' );

		// Email alert.
		$grade = isset( $results['grade'] ) ? $results['grade'] : '?';
		$items = array(
			array(
				'name'   => __( 'Performance Score', 'sitevitals-speed-optimizer-pro' ),
				/* translators: 1: score, 2: grade letter */
				'detail' => sprintf( __( '%1$d/100 (Grade: %2$s)', 'sitevitals-speed-optimizer-pro' ), $score, $grade ),
				'color'  => $score < 25 ? '#ef4444' : '#f59e0b',
			),
		);

		$email_body = $this->build_email_html(
			__( 'Performance Score Alert', 'sitevitals-speed-optimizer-pro' ),
			sprintf(
				/* translators: 1: score, 2: threshold */
				__( 'Your site performance score has dropped to %1$d/100, which is below your alert threshold of %2$d.', 'sitevitals-speed-optimizer-pro' ),
				$score,
				$threshold
			),
			'#ef4444',
			$items
		);

		$this->send_alert_email(
			/* translators: %d: performance score */
			sprintf( __( 'Performance Score Alert: %d/100', 'sitevitals-speed-optimizer-pro' ), $score ),
			$email_body
		);
	}

	/**
	 * Notify when an optimization task completes.
	 *
	 * @param string $type    Type of optimization (critical_css, unused_css, image_convert).
	 * @param array  $results Optimization results.
	 */
	public function notify_optimization_complete( $type, $results ) {
		$type_labels = array(
			'critical_css'  => __( 'Critical CSS Generation', 'sitevitals-speed-optimizer-pro' ),
			'unused_css'    => __( 'Unused CSS Removal', 'sitevitals-speed-optimizer-pro' ),
			'image_convert' => __( 'Image Conversion', 'sitevitals-speed-optimizer-pro' ),
			'db_cleanup'    => __( 'Database Cleanup', 'sitevitals-speed-optimizer-pro' ),
		);

		$label = $type_labels[ $type ] ?? $type;

		$slack_msg = sprintf(
			/* translators: %s: optimization type name */
			__( '%s completed successfully.', 'sitevitals-speed-optimizer-pro' ),
			$label
		);
		$this->send_slack( $slack_msg, '#22c55e' );
	}

	/**
	 * Build a styled HTML email matching the plugin's design.
	 *
	 * @param string $title   Email headline.
	 * @param string $summary Summary paragraph text.
	 * @param string $accent  Accent color hex.
	 * @param array  $items   Array of items, each with 'name', 'detail', 'color'.
	 * @return string Full HTML email body.
	 */
	private function build_email_html( $title, $summary, $accent, $items = array() ) {
		$site_name = get_bloginfo( 'name' );
		$site_url  = home_url();
		$admin_url = admin_url( 'admin.php?page=sitevitals-so' );
		$date      = current_time( 'F j, Y \a\t g:i A' );

		ob_start();
		?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;background:#f3f4f6;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
	<table width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6;padding:32px 16px;">
		<tr>
			<td align="center">
				<table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
					<!-- Header -->
					<tr>
						<td style="background:#0b0f19;padding:24px 32px;text-align:center;">
							<h1 style="color:#ffffff;margin:0;font-size:22px;">
								SiteVitals <span style="color:<?php echo esc_attr( $accent ); ?>;">Speed Optimizer Pro</span>
							</h1>
							<p style="color:#94a3b8;margin:8px 0 0;font-size:14px;">
								<?php echo esc_html( $site_name ); ?>
							</p>
						</td>
					</tr>

					<!-- Alert Badge -->
					<tr>
						<td style="padding:32px 32px 16px;text-align:center;">
							<div style="display:inline-block;width:64px;height:64px;border-radius:50%;background:<?php echo esc_attr( $accent ); ?>;line-height:64px;text-align:center;">
								<span style="color:#ffffff;font-size:28px;">&#x26A0;</span>
							</div>
							<h2 style="font-size:20px;color:#1e293b;margin:16px 0 8px;">
								<?php echo esc_html( $title ); ?>
							</h2>
							<p style="color:#6b7280;font-size:14px;margin:0;line-height:1.5;">
								<?php echo esc_html( $summary ); ?>
							</p>
							<p style="color:#9ca3af;font-size:12px;margin:8px 0 0;">
								<?php echo esc_html( $date ); ?>
							</p>
						</td>
					</tr>

					<?php if ( ! empty( $items ) ) : ?>
					<!-- Items List -->
					<tr>
						<td style="padding:0 32px 24px;">
							<h3 style="font-size:14px;color:#1e293b;margin:0 0 12px;text-transform:uppercase;letter-spacing:0.5px;">
								<?php esc_html_e( 'Details', 'sitevitals-speed-optimizer-pro' ); ?>
							</h3>
							<?php foreach ( $items as $item ) : ?>
								<div style="padding:12px 16px;margin-bottom:8px;background:#f8fafc;border-left:4px solid <?php echo esc_attr( $item['color'] ); ?>;border-radius:0 6px 6px 0;">
									<strong style="color:#1e293b;font-size:14px;">
										<?php echo esc_html( $item['name'] ); ?>
									</strong>
									<p style="color:#6b7280;font-size:13px;margin:4px 0 0;">
										<?php echo esc_html( $item['detail'] ); ?>
									</p>
								</div>
							<?php endforeach; ?>
						</td>
					</tr>
					<?php endif; ?>

					<!-- CTA -->
					<tr>
						<td style="padding:0 32px 32px;text-align:center;">
							<a href="<?php echo esc_url( $admin_url ); ?>"
								style="display:inline-block;padding:12px 32px;background:<?php echo esc_attr( $accent ); ?>;color:#ffffff;text-decoration:none;border-radius:6px;font-weight:bold;font-size:14px;">
								<?php esc_html_e( 'View Dashboard', 'sitevitals-speed-optimizer-pro' ); ?>
							</a>
						</td>
					</tr>

					<!-- Footer -->
					<tr>
						<td style="padding:16px 32px;background:#f8fafc;text-align:center;border-top:1px solid #e5e7eb;">
							<p style="color:#9ca3af;font-size:12px;margin:0;">
								<?php
								printf(
									/* translators: %s: site URL */
									esc_html__( 'Sent by SiteVitals Speed Optimizer Pro from %s', 'sitevitals-speed-optimizer-pro' ),
									esc_html( $site_url )
								);
								?>
							</p>
							<p style="color:#9ca3af;font-size:12px;margin:4px 0 0;">
								<?php esc_html_e( 'Manage alert settings in Speed Optimizer > Settings.', 'sitevitals-speed-optimizer-pro' ); ?>
							</p>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>
		<?php
		return ob_get_clean();
	}

	/**
	 * AJAX: Test Slack webhook.
	 */
	public function ajax_test_slack() {
		check_ajax_referer( 'sitevitals_so_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}

		$result = $this->send_slack(
			__( 'Test notification from SiteVitals Speed Optimizer Pro.', 'sitevitals-speed-optimizer-pro' ),
			'#22c55e'
		);

		if ( $result ) {
			wp_send_json_success( __( 'Slack notification sent!', 'sitevitals-speed-optimizer-pro' ) );
		} else {
			wp_send_json_error( __( 'Failed to send. Check your webhook URL.', 'sitevitals-speed-optimizer-pro' ) );
		}
	}
}
