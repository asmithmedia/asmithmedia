<?php
/**
 * Performance History - stores and charts performance score trends over time.
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_SO_Performance_History {

	/**
	 * Single instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Custom table name (without prefix).
	 *
	 * @var string
	 */
	const TABLE_NAME = 'sitevitals_so_perf_history';

	/**
	 * Maximum retention in days.
	 *
	 * @var int
	 */
	const MAX_RETENTION = 90;

	/**
	 * Get or create the singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		register_activation_hook( SITEVITALS_SO_PRO_FILE, array( $this, 'create_table' ) );

		// Store daily snapshot after score calculation.
		add_action( 'sitevitals_so_after_score_calculation', array( $this, 'store_snapshot' ) );

		// Daily cron to capture a snapshot.
		add_action( 'sitevitals_so_pro_daily_history', array( $this, 'daily_snapshot' ) );
		add_action( 'admin_init', array( $this, 'schedule_daily' ) );

		// Cleanup old data.
		add_action( 'sitevitals_so_pro_daily_history', array( $this, 'cleanup' ) );

		// AJAX for chart data.
		add_action( 'wp_ajax_sitevitals_so_pro_perf_history', array( $this, 'ajax_get_history' ) );

		// Settings.
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_history_retention', array(
			'type'              => 'integer',
			'sanitize_callback' => 'absint',
			'default'           => 90,
		) );
	}

	/**
	 * Schedule the daily history cron.
	 */
	public function schedule_daily() {
		if ( ! wp_next_scheduled( 'sitevitals_so_pro_daily_history' ) ) {
			wp_schedule_event( time(), 'daily', 'sitevitals_so_pro_daily_history' );
		}
	}

	/**
	 * Create the performance history table.
	 */
	public function create_table() {
		global $wpdb;

		$table           = $wpdb->prefix . self::TABLE_NAME;
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			score int(3) NOT NULL DEFAULT 0,
			grade varchar(2) NOT NULL DEFAULT '',
			details longtext NOT NULL DEFAULT '',
			created_at date NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY date_unique (created_at),
			KEY created_at (created_at)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/**
	 * Store a performance snapshot.
	 *
	 * @param array $results Score calculation results.
	 */
	public function store_snapshot( $results ) {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE_NAME;
		$today = current_time( 'Y-m-d' );

		$score = isset( $results['score'] ) ? (int) $results['score'] : 0;
		$grade = isset( $results['grade'] ) ? sanitize_text_field( $results['grade'] ) : '';

		$details = wp_json_encode( $results );

		// Check cache first.
		$cache_key = 'sitevitals_so_pro_history_' . $today;
		$cached    = wp_cache_get( $cache_key, 'sitevitals_so_pro' );

		if ( false !== $cached ) {
			return;
		}

		$wpdb->replace( $table, array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			'score'      => $score,
			'grade'      => $grade,
			'details'    => $details,
			'created_at' => $today,
		), array( '%d', '%s', '%s', '%s' ) );

		wp_cache_set( $cache_key, true, 'sitevitals_so_pro', DAY_IN_SECONDS );
	}

	/**
	 * Daily cron snapshot handler.
	 */
	public function daily_snapshot() {
		// Trigger a score calculation which will call store_snapshot via the hook.
		if ( class_exists( 'SiteVitals_SO_Performance_Score' ) ) {
			$scorer = SiteVitals_SO_Performance_Score::instance();
			if ( method_exists( $scorer, 'calculate_score' ) ) {
				$scorer->calculate_score();
			}
		}
	}

	/**
	 * Get historical data.
	 *
	 * @param int $days Number of days to look back.
	 * @return array
	 */
	public function get_history( $days = 30 ) {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE_NAME;
		$since = gmdate( 'Y-m-d', time() - $days * DAY_IN_SECONDS );

		$cache_key = 'sitevitals_so_pro_history_data_' . $days;
		$cached    = wp_cache_get( $cache_key, 'sitevitals_so_pro' );

		if ( false !== $cached ) {
			return $cached;
		}

		$results = $wpdb->get_results( $wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			"SELECT * FROM {$table} WHERE created_at >= %s ORDER BY created_at ASC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$since
		), ARRAY_A );

		wp_cache_set( $cache_key, $results, 'sitevitals_so_pro', HOUR_IN_SECONDS );

		return $results;
	}

	/**
	 * AJAX: Get chart data.
	 */
	public function ajax_get_history() {
		check_ajax_referer( 'sitevitals_so_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}

		$days = isset( $_POST['days'] ) ? absint( $_POST['days'] ) : 30;
		$days = min( $days, self::MAX_RETENTION );

		$history    = $this->get_history( $days );
		$chart_data = $this->format_for_chart( $history );

		wp_send_json_success( $chart_data );
	}

	/**
	 * Format history data for Chart.js consumption.
	 *
	 * @param array $history Raw history rows.
	 * @return array
	 */
	private function format_for_chart( $history ) {
		$labels  = array();
		$scores  = array();
		$grades  = array();

		foreach ( $history as $row ) {
			$labels[] = $row['created_at'];
			$scores[] = (int) $row['score'];
			$grades[] = $row['grade'];
		}

		$datasets = array();
		if ( ! empty( $scores ) ) {
			$datasets[] = array(
				'label'           => __( 'Performance Score', 'sitevitals-speed-optimizer-pro' ),
				'data'            => $scores,
				'borderColor'     => '#6366f1',
				'backgroundColor' => 'rgba(99, 102, 241, 0.1)',
				'fill'            => true,
				'tension'         => 0.3,
				'pointRadius'     => 4,
				'pointHoverRadius' => 6,
			);
		}

		return array(
			'labels'   => $labels,
			'datasets' => $datasets,
			'grades'   => $grades,
		);
	}

	/**
	 * Clean up old history data beyond retention period.
	 */
	public function cleanup() {
		global $wpdb;

		$retention = (int) get_option( 'sitevitals_so_pro_history_retention', self::MAX_RETENTION );
		$retention = min( $retention, self::MAX_RETENTION );

		$table  = $wpdb->prefix . self::TABLE_NAME;
		$cutoff = gmdate( 'Y-m-d', time() - $retention * DAY_IN_SECONDS );

		$wpdb->query( $wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			"DELETE FROM {$table} WHERE created_at < %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$cutoff
		) );
	}
}
