<?php
/**
 * Critical CSS - generates and inlines above-the-fold CSS.
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_SO_Critical_CSS {

	/**
	 * Single instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Cache directory relative to wp-content.
	 *
	 * @var string
	 */
	const CACHE_DIR = 'cache/sitevitals-so/critical-css';

	/**
	 * Get or create the singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'wp_ajax_sitevitals_so_pro_generate_critical_css', array( $this, 'ajax_generate' ) );
		add_action( 'wp_ajax_sitevitals_so_pro_purge_critical_css', array( $this, 'ajax_purge' ) );

		// Inline critical CSS on the frontend.
		if ( ! is_admin() && $this->is_enabled() ) {
			add_action( 'wp_head', array( $this, 'inline_critical_css' ), 1 );
			add_filter( 'style_loader_tag', array( $this, 'defer_stylesheets' ), 10, 4 );
		}

		// Queue system via WP Cron.
		add_action( 'sitevitals_so_pro_process_critical_css_queue', array( $this, 'process_queue' ) );
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_critical_css_enabled', array(
			'type'              => 'boolean',
			'sanitize_callback' => 'rest_sanitize_boolean',
			'default'           => false,
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_critical_css_auto', array(
			'type'              => 'boolean',
			'sanitize_callback' => 'rest_sanitize_boolean',
			'default'           => false,
		) );
	}

	/**
	 * Check if critical CSS is enabled.
	 *
	 * @return bool
	 */
	public function is_enabled() {
		return (bool) get_option( 'sitevitals_so_pro_critical_css_enabled', false );
	}

	/**
	 * Get the cache directory path.
	 *
	 * @return string
	 */
	private function get_cache_dir() {
		return WP_CONTENT_DIR . '/' . self::CACHE_DIR;
	}

	/**
	 * Ensure the cache directory exists using WP_Filesystem.
	 *
	 * @return bool
	 */
	private function ensure_cache_dir() {
		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		$cache_dir = $this->get_cache_dir();

		if ( ! $wp_filesystem->is_dir( $cache_dir ) ) {
			return wp_mkdir_p( $cache_dir );
		}

		return true;
	}

	/**
	 * Generate a unique filename for a URL.
	 *
	 * @param string $url The page URL.
	 * @return string
	 */
	private function get_cache_filename( $url ) {
		return md5( $url ) . '.css';
	}

	/**
	 * Get the cached critical CSS for the current page.
	 *
	 * @return string|false CSS content or false.
	 */
	private function get_cached_css() {
		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		$url      = $this->get_current_url();
		$filepath = $this->get_cache_dir() . '/' . $this->get_cache_filename( $url );

		if ( $wp_filesystem->exists( $filepath ) ) {
			return $wp_filesystem->get_contents( $filepath );
		}

		return false;
	}

	/**
	 * Save critical CSS to cache.
	 *
	 * @param string $url The page URL.
	 * @param string $css The critical CSS content.
	 * @return bool
	 */
	private function save_cached_css( $url, $css ) {
		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		if ( ! $this->ensure_cache_dir() ) {
			return false;
		}

		$filepath = $this->get_cache_dir() . '/' . $this->get_cache_filename( $url );

		return $wp_filesystem->put_contents( $filepath, $css, FS_CHMOD_FILE );
	}

	/**
	 * Get the current page URL.
	 *
	 * @return string
	 */
	private function get_current_url() {
		$protocol = is_ssl() ? 'https' : 'http';
		return $protocol . '://' . sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ?? '' ) ) . sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated -- Fallback to empty string if not set.
	}

	/**
	 * Inline critical CSS in the head.
	 */
	public function inline_critical_css() {
		$css = $this->get_cached_css();
		if ( false === $css || empty( $css ) ) {
			return;
		}

		echo '<style id="sitevitals-so-critical-css">' . wp_strip_all_tags( $css ) . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS content is stripped of tags.
	}

	/**
	 * Defer non-critical stylesheets by converting link to preload.
	 *
	 * @param string $html   The link tag HTML.
	 * @param string $handle The stylesheet handle.
	 * @param string $href   The stylesheet URL.
	 * @param string $media  The media attribute.
	 * @return string
	 */
	public function defer_stylesheets( $html, $handle, $href, $media ) {
		// Only defer if we have critical CSS for this page.
		$css = $this->get_cached_css();
		if ( false === $css || empty( $css ) ) {
			return $html;
		}

		// Don't defer admin bar styles.
		if ( 'admin-bar' === $handle || 'dashicons' === $handle ) {
			return $html;
		}

		$noscript = '<noscript>' . $html . '</noscript>';
		$preload  = str_replace(
			array( "rel='stylesheet'", 'rel="stylesheet"' ),
			array( "rel='preload' as='style' onload=\"this.onload=null;this.rel='stylesheet'\"", 'rel="preload" as="style" onload="this.onload=null;this.rel=\'stylesheet\'"' ),
			$html
		);

		return $preload . $noscript;
	}

	/**
	 * Extract critical CSS from a page's stylesheets.
	 * This is a simplified server-side extraction that collects all CSS rules
	 * and returns a subset based on common above-the-fold selectors.
	 *
	 * @param string $url The page URL to generate critical CSS for.
	 * @return string|WP_Error The critical CSS or error.
	 */
	public function generate_critical_css( $url ) {
		$response = wp_remote_get( $url, array(
			'timeout'   => 30,
			'sslverify' => false,
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = wp_remote_retrieve_body( $response );
		if ( empty( $body ) ) {
			return new \WP_Error( 'empty_response', __( 'Empty response from URL.', 'sitevitals-speed-optimizer-pro' ) );
		}

		// Extract stylesheet URLs from the HTML.
		$stylesheet_urls = array();
		if ( preg_match_all( '/<link[^>]+rel=["\']stylesheet["\'][^>]+href=["\']([^"\']+)["\'][^>]*>/i', $body, $matches ) ) {
			$stylesheet_urls = $matches[1];
		}
		// Also match href before rel.
		if ( preg_match_all( '/<link[^>]+href=["\']([^"\']+)["\'][^>]+rel=["\']stylesheet["\'][^>]*>/i', $body, $matches ) ) {
			$stylesheet_urls = array_merge( $stylesheet_urls, $matches[1] );
		}
		$stylesheet_urls = array_unique( $stylesheet_urls );

		// Collect all CSS.
		$all_css = '';
		foreach ( $stylesheet_urls as $css_url ) {
			// Make relative URLs absolute.
			if ( 0 === strpos( $css_url, '//' ) ) {
				$css_url = 'https:' . $css_url;
			} elseif ( 0 === strpos( $css_url, '/' ) ) {
				$css_url = home_url( $css_url );
			}

			$css_response = wp_remote_get( $css_url, array(
				'timeout'   => 15,
				'sslverify' => false,
			) );

			if ( ! is_wp_error( $css_response ) ) {
				$all_css .= wp_remote_retrieve_body( $css_response ) . "\n";
			}
		}

		// Also extract inline styles.
		if ( preg_match_all( '/<style[^>]*>(.*?)<\/style>/si', $body, $style_matches ) ) {
			foreach ( $style_matches[1] as $inline_style ) {
				$all_css .= $inline_style . "\n";
			}
		}

		// Extract critical selectors: anything targeting common above-the-fold elements.
		$critical_selectors = array(
			'body', 'html', ':root',
			'header', 'nav', '.header', '.nav', '.navbar', '#header', '#nav',
			'.site-header', '.main-navigation', '.site-branding',
			'.hero', '.banner', '.masthead', '.above-fold',
			'h1', 'h2', 'h3', 'p', 'a', 'img',
			'.container', '.wrapper', '.row', '.col',
			'.wp-block', '.entry-header', '.entry-title',
			'@font-face', '@charset', '@import',
			'@media',
		);

		$critical_css = $this->extract_matching_rules( $all_css, $critical_selectors );

		// Limit to reasonable size (50KB).
		if ( strlen( $critical_css ) > 51200 ) {
			$critical_css = substr( $critical_css, 0, 51200 );
			// Ensure we don't break a rule mid-way.
			$last_brace = strrpos( $critical_css, '}' );
			if ( false !== $last_brace ) {
				$critical_css = substr( $critical_css, 0, $last_brace + 1 );
			}
		}

		return $critical_css;
	}

	/**
	 * Extract CSS rules matching given selectors.
	 *
	 * @param string $css       Full CSS content.
	 * @param array  $selectors Selector patterns to match.
	 * @return string Filtered CSS.
	 */
	private function extract_matching_rules( $css, $selectors ) {
		// Remove comments.
		$css = preg_replace( '/\/\*.*?\*\//s', '', $css );

		$critical = '';
		$pattern  = '/([^{]+)\{([^}]*)\}/s';

		if ( preg_match_all( $pattern, $css, $matches, PREG_SET_ORDER ) ) {
			foreach ( $matches as $match ) {
				$selector = trim( $match[1] );
				$rules    = trim( $match[2] );

				foreach ( $selectors as $target ) {
					if ( '@' === $target[0] ) {
						// At-rules: check if selector starts with at-rule.
						if ( 0 === stripos( $selector, $target ) ) {
							$critical .= $selector . '{' . $rules . '}' . "\n";
							break;
						}
					} elseif ( false !== stripos( $selector, $target ) ) {
						$critical .= $selector . '{' . $rules . '}' . "\n";
						break;
					}
				}
			}
		}

		return $critical;
	}

	/**
	 * Add a URL to the critical CSS generation queue.
	 *
	 * @param string $url The URL to queue.
	 */
	public function add_to_queue( $url ) {
		$queue = get_option( 'sitevitals_so_pro_critical_css_queue', array() );

		if ( ! in_array( $url, $queue, true ) ) {
			$queue[] = $url;
			update_option( 'sitevitals_so_pro_critical_css_queue', $queue );
		}

		if ( ! wp_next_scheduled( 'sitevitals_so_pro_process_critical_css_queue' ) ) {
			wp_schedule_single_event( time() + 10, 'sitevitals_so_pro_process_critical_css_queue' );
		}
	}

	/**
	 * Process the critical CSS generation queue.
	 */
	public function process_queue() {
		$queue = get_option( 'sitevitals_so_pro_critical_css_queue', array() );
		if ( empty( $queue ) ) {
			return;
		}

		// Process one URL at a time.
		$url = array_shift( $queue );
		update_option( 'sitevitals_so_pro_critical_css_queue', $queue );

		$css = $this->generate_critical_css( $url );
		if ( ! is_wp_error( $css ) && ! empty( $css ) ) {
			$this->save_cached_css( $url, $css );
		}

		// Schedule next if queue not empty.
		if ( ! empty( $queue ) ) {
			wp_schedule_single_event( time() + 10, 'sitevitals_so_pro_process_critical_css_queue' );
		}
	}

	/**
	 * Get statistics about generated critical CSS files.
	 *
	 * @return array
	 */
	public function get_stats() {
		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		$cache_dir = $this->get_cache_dir();
		$stats     = array(
			'files'      => 0,
			'total_size' => 0,
			'enabled'    => $this->is_enabled(),
			'queue'      => count( get_option( 'sitevitals_so_pro_critical_css_queue', array() ) ),
		);

		if ( ! $wp_filesystem->is_dir( $cache_dir ) ) {
			return $stats;
		}

		$files = $wp_filesystem->dirlist( $cache_dir );
		if ( is_array( $files ) ) {
			foreach ( $files as $file ) {
				if ( '.css' === substr( $file['name'], -4 ) ) {
					$stats['files']++;
					$stats['total_size'] += $file['size'];
				}
			}
		}

		return $stats;
	}

	/**
	 * AJAX: Generate critical CSS for a URL.
	 */
	public function ajax_generate() {
		check_ajax_referer( 'sitevitals_so_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Unauthorized.', 'sitevitals-speed-optimizer-pro' ) );
		}

		$url = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : home_url( '/' );

		if ( empty( $url ) ) {
			$url = home_url( '/' );
		}

		$css = $this->generate_critical_css( $url );

		if ( is_wp_error( $css ) ) {
			wp_send_json_error( $css->get_error_message() );
		}

		if ( empty( $css ) ) {
			wp_send_json_error( __( 'No critical CSS could be extracted.', 'sitevitals-speed-optimizer-pro' ) );
		}

		$this->save_cached_css( $url, $css );

		wp_send_json_success( array(
			'size'  => strlen( $css ),
			'url'   => $url,
			/* translators: %s: CSS file size in kilobytes */
			'message' => sprintf( __( 'Generated %s of critical CSS.', 'sitevitals-speed-optimizer-pro' ), size_format( strlen( $css ) ) ),
		) );
	}

	/**
	 * AJAX: Purge all cached critical CSS.
	 */
	public function ajax_purge() {
		check_ajax_referer( 'sitevitals_so_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Unauthorized.', 'sitevitals-speed-optimizer-pro' ) );
		}

		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		$cache_dir = $this->get_cache_dir();
		$deleted   = 0;

		if ( $wp_filesystem->is_dir( $cache_dir ) ) {
			$files = $wp_filesystem->dirlist( $cache_dir );
			if ( is_array( $files ) ) {
				foreach ( $files as $file ) {
					if ( '.css' === substr( $file['name'], -4 ) ) {
						$wp_filesystem->delete( $cache_dir . '/' . $file['name'] );
						$deleted++;
					}
				}
			}
		}

		wp_send_json_success( array(
			'deleted' => $deleted,
			/* translators: %d: number of files deleted */
			'message' => sprintf( __( 'Purged %d critical CSS files.', 'sitevitals-speed-optimizer-pro' ), $deleted ),
		) );
	}
}
