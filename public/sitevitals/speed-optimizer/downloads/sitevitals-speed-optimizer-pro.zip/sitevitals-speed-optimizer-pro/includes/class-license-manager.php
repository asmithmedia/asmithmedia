<?php
/**
 * License Manager - Ed25519 cryptographic license key validation.
 *
 * Zero server calls. License keys are self-validating using public key cryptography.
 *
 * License format: base64(json_payload).base64(signature)
 * Payload: {"email":"user@example.com","plan":"single|unlimited","domain":"*|example.com","created":"2025-01-01","expires":"2026-01-01"}
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_SO_License_Manager {

	/**
	 * Single instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Ed25519 public key for license verification.
	 * This is safe to distribute -- only the private key (kept on your server) can create valid signatures.
	 *
	 * @var string
	 */
	const PUBLIC_KEY = '62caec9202f4cdae546d971bdcd8cd1b714ae3faa2fd549aa4d9eda51e34172d';

	/**
	 * Option key for stored license.
	 *
	 * @var string
	 */
	const OPTION_KEY = 'sitevitals_so_pro_license_key';

	/**
	 * Transient key for cached validation.
	 *
	 * @var string
	 */
	const CACHE_KEY = 'sitevitals_so_pro_license_valid';

	/**
	 * Option key for license status.
	 *
	 * @var string
	 */
	const STATUS_KEY = 'sitevitals_so_pro_license_status';

	/**
	 * Grace period in days after expiry.
	 *
	 * @var int
	 */
	const GRACE_DAYS = 7;

	/**
	 * Get or create the singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'wp_ajax_sitevitals_so_pro_activate_license', array( $this, 'ajax_activate' ) );
		add_action( 'wp_ajax_sitevitals_so_pro_deactivate_license', array( $this, 'ajax_deactivate' ) );
	}

	/**
	 * Check if the current license is valid.
	 *
	 * @return bool
	 */
	public function is_valid() {
		$cached = get_transient( self::CACHE_KEY );
		if ( false !== $cached ) {
			return (bool) $cached;
		}

		$license_key = get_option( self::OPTION_KEY, '' );
		if ( empty( $license_key ) ) {
			return false;
		}

		$result   = $this->validate_key( $license_key );
		$is_valid = ( true === $result );

		// Cache for 24 hours.
		set_transient( self::CACHE_KEY, $is_valid ? 1 : 0, DAY_IN_SECONDS );

		return $is_valid;
	}

	/**
	 * Validate a license key cryptographically.
	 *
	 * @param string $license_key The full license key string.
	 * @return true|string True if valid, error message string if invalid.
	 */
	public function validate_key( $license_key ) {
		// Check sodium is available.
		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			return __( 'PHP sodium extension is required for license validation.', 'sitevitals-speed-optimizer-pro' );
		}

		// Split key into payload and signature.
		$parts = explode( '.', $license_key, 2 );
		if ( count( $parts ) !== 2 ) {
			return __( 'Invalid license key format.', 'sitevitals-speed-optimizer-pro' );
		}

		$payload_b64   = $parts[0];
		$signature_b64 = $parts[1];

		// Decode.
		$payload_json = base64_decode( $payload_b64, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- License key decoding requires base64.
		$signature    = base64_decode( $signature_b64, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- License signature decoding requires base64.

		if ( false === $payload_json || false === $signature ) {
			return __( 'Invalid license key encoding.', 'sitevitals-speed-optimizer-pro' );
		}

		// Verify signature.
		$public_key = sodium_hex2bin( self::PUBLIC_KEY );

		try {
			$valid = sodium_crypto_sign_verify_detached( $signature, $payload_json, $public_key );
		} catch ( \SodiumException $e ) {
			return __( 'License signature verification failed.', 'sitevitals-speed-optimizer-pro' );
		}

		if ( ! $valid ) {
			return __( 'Invalid license key signature.', 'sitevitals-speed-optimizer-pro' );
		}

		// Parse payload.
		$payload = json_decode( $payload_json, true );
		if ( ! $payload ) {
			return __( 'Invalid license payload.', 'sitevitals-speed-optimizer-pro' );
		}

		// Check expiry (with grace period).
		if ( ! empty( $payload['expires'] ) ) {
			$expires   = strtotime( $payload['expires'] );
			$grace_end = $expires + ( self::GRACE_DAYS * DAY_IN_SECONDS );

			if ( time() > $grace_end ) {
				return __( 'License key has expired.', 'sitevitals-speed-optimizer-pro' );
			}
		}

		// Check domain (if not wildcard).
		if ( ! empty( $payload['domain'] ) && '*' !== $payload['domain'] ) {
			$site_domain    = wp_parse_url( home_url(), PHP_URL_HOST );
			$site_domain    = preg_replace( '/^www\./', '', $site_domain );
			$license_domain = preg_replace( '/^www\./', '', $payload['domain'] );

			if ( strtolower( $site_domain ) !== strtolower( $license_domain ) ) {
				return sprintf(
					/* translators: 1: licensed domain, 2: current site domain */
					__( 'License is for %1$s, but this site is %2$s.', 'sitevitals-speed-optimizer-pro' ),
					$license_domain,
					$site_domain
				);
			}
		}

		return true;
	}

	/**
	 * Get the decoded license payload.
	 *
	 * @return array|null
	 */
	public function get_license_data() {
		$license_key = get_option( self::OPTION_KEY, '' );
		if ( empty( $license_key ) ) {
			return null;
		}

		$parts = explode( '.', $license_key, 2 );
		if ( count( $parts ) !== 2 ) {
			return null;
		}

		$payload_json = base64_decode( $parts[0], true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- License key decoding requires base64.
		if ( false === $payload_json ) {
			return null;
		}

		return json_decode( $payload_json, true );
	}

	/**
	 * AJAX: Activate license.
	 */
	public function ajax_activate() {
		check_ajax_referer( 'sitevitals_so_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Unauthorized.', 'sitevitals-speed-optimizer-pro' ) );
		}

		$key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
		if ( empty( $key ) ) {
			wp_send_json_error( __( 'Please enter a license key.', 'sitevitals-speed-optimizer-pro' ) );
		}

		$result = $this->validate_key( $key );
		if ( true !== $result ) {
			wp_send_json_error( $result );
		}

		update_option( self::OPTION_KEY, $key );
		update_option( self::STATUS_KEY, 'active' );
		delete_transient( self::CACHE_KEY );

		wp_send_json_success( __( 'License activated successfully!', 'sitevitals-speed-optimizer-pro' ) );
	}

	/**
	 * AJAX: Deactivate license.
	 */
	public function ajax_deactivate() {
		check_ajax_referer( 'sitevitals_so_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Unauthorized.', 'sitevitals-speed-optimizer-pro' ) );
		}

		delete_option( self::OPTION_KEY );
		update_option( self::STATUS_KEY, 'inactive' );
		delete_transient( self::CACHE_KEY );

		wp_send_json_success( __( 'License deactivated.', 'sitevitals-speed-optimizer-pro' ) );
	}

	/**
	 * Render the license settings form on the free plugin's settings page.
	 */
	public function render_license_settings() {
		$license_data = $this->get_license_data();
		$is_valid     = $this->is_valid();
		?>
		<div class="sitevitals-so-settings-grid">
			<div class="sitevitals-so-setting-row">
				<div class="sitevitals-so-setting-label">
					<label><?php esc_html_e( 'License Key', 'sitevitals-speed-optimizer-pro' ); ?></label>
					<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Your Pro license key from purchase email.', 'sitevitals-speed-optimizer-pro' ); ?></span>
				</div>
				<div class="sitevitals-so-setting-input">
					<?php if ( $is_valid && $license_data ) : ?>
						<div>
							<span class="dashicons dashicons-yes-alt" style="color:#4ade80;vertical-align:middle;"></span>
							<strong style="color:#4ade80;"><?php esc_html_e( 'Active', 'sitevitals-speed-optimizer-pro' ); ?></strong>
							<span style="color:#94a3b8;font-size:13px;margin-left:8px;">
								<?php
								printf(
									/* translators: 1: plan name, 2: expiry date */
									esc_html__( '%1$s plan — expires %2$s', 'sitevitals-speed-optimizer-pro' ),
									esc_html( ucfirst( $license_data['plan'] ?? 'unknown' ) ),
									esc_html( $license_data['expires'] ?? 'never' )
								);
								?>
							</span>
							<br /><br />
							<button type="button" class="sitevitals-so-btn sitevitals-so-btn-secondary" id="sitevitals-so-pro-deactivate-license">
								<?php esc_html_e( 'Deactivate', 'sitevitals-speed-optimizer-pro' ); ?>
							</button>
						</div>
					<?php else : ?>
						<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
							<input type="text"
								id="sitevitals_so_pro_license_key_input"
								placeholder="<?php esc_attr_e( 'Paste license key...', 'sitevitals-speed-optimizer-pro' ); ?>"
								style="min-width:300px;font-family:'SF Mono','Cascadia Code',monospace;" />
							<button type="button" class="sitevitals-so-btn sitevitals-so-btn-pro" id="sitevitals-so-pro-activate-license">
								<?php esc_html_e( 'Activate', 'sitevitals-speed-optimizer-pro' ); ?>
							</button>
							<span id="sitevitals-so-pro-license-status" class="sitevitals-so-inline-status"></span>
						</div>
						<p style="color:#64748b;font-size:12px;margin-top:8px;">
							<a href="https://asmith.media/sitevitals/speed-optimizer/" target="_blank" rel="noopener" style="color:#f59e0b;">
								<?php esc_html_e( "Don't have a license?", 'sitevitals-speed-optimizer-pro' ); ?>
							</a>
						</p>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<script>
		jQuery(function($) {
			$('#sitevitals-so-pro-activate-license').on('click', function() {
				var key = $('#sitevitals_so_pro_license_key_input').val();
				var $status = $('#sitevitals-so-pro-license-status');
				$status.text('Activating...').css('color', '#94a3b8');
				$.post(sitevitals_so.ajax_url, {
					action: 'sitevitals_so_pro_activate_license',
					nonce: sitevitals_so.nonce,
					license_key: key
				}).done(function(r) {
					if (r.success) {
						$status.text(r.data).css('color', '#4ade80');
						setTimeout(function() { location.reload(); }, 500);
					} else {
						$status.text(r.data).css('color', '#f87171');
					}
				});
			});
			$('#sitevitals-so-pro-deactivate-license').on('click', function() {
				$.post(sitevitals_so.ajax_url, {
					action: 'sitevitals_so_pro_deactivate_license',
					nonce: sitevitals_so.nonce
				}).done(function(r) {
					if (r.success) location.reload();
				});
			});
		});
		</script>
		<?php
	}
}
