<?php
/**
 * White Label - custom branding for agency reports and export.
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_SO_White_Label {

	/**
	 * Single instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Get or create the singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'wp_ajax_sitevitals_so_pro_export_html', array( $this, 'ajax_export_html' ) );
		add_action( 'wp_ajax_sitevitals_so_pro_export_pdf', array( $this, 'ajax_export_pdf' ) );
	}

	/**
	 * Register white-label settings.
	 */
	public function register_settings() {
		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_agency_name', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_agency_logo', array(
			'type'              => 'string',
			'sanitize_callback' => 'esc_url_raw',
			'default'           => '',
		) );

		register_setting( 'sitevitals_so_settings', 'sitevitals_so_pro_agency_color', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_hex_color',
			'default'           => '#6366f1',
		) );
	}

	/**
	 * Get white-label branding settings.
	 *
	 * @return array
	 */
	public function get_branding() {
		return array(
			'name'  => get_option( 'sitevitals_so_pro_agency_name', '' ),
			'logo'  => get_option( 'sitevitals_so_pro_agency_logo', '' ),
			'color' => get_option( 'sitevitals_so_pro_agency_color', '#6366f1' ),
		);
	}

	/**
	 * Gather report data from all Pro features.
	 *
	 * @return array
	 */
	private function gather_report_data() {
		$data = array(
			'score'       => 0,
			'grade'       => '?',
			'optimizations' => array(),
			'stats'       => array(),
		);

		// Get latest performance score.
		$score_data = get_option( 'sitevitals_so_last_score', array() );
		if ( ! empty( $score_data ) ) {
			$data['score'] = $score_data['score'] ?? 0;
			$data['grade'] = $score_data['grade'] ?? '?';
		}

		// Critical CSS stats.
		if ( class_exists( 'SiteVitals_SO_Critical_CSS' ) ) {
			$data['stats']['critical_css'] = SiteVitals_SO_Critical_CSS::instance()->get_stats();
		}

		// Unused CSS stats.
		if ( class_exists( 'SiteVitals_SO_Unused_CSS' ) ) {
			$data['stats']['unused_css'] = SiteVitals_SO_Unused_CSS::instance()->get_stats();
		}

		// Image conversion stats.
		if ( class_exists( 'SiteVitals_SO_Image_Converter' ) ) {
			$data['stats']['images'] = SiteVitals_SO_Image_Converter::instance()->get_stats();
		}

		// DB cleanup log.
		if ( class_exists( 'SiteVitals_SO_Scheduled_DB' ) ) {
			$data['stats']['db_cleanup'] = SiteVitals_SO_Scheduled_DB::instance()->get_last_cleanup();
		}

		return $data;
	}

	/**
	 * AJAX: Export report as downloadable HTML.
	 */
	public function ajax_export_html() {
		check_ajax_referer( 'sitevitals_so_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}

		$report   = $this->gather_report_data();
		$branding = $this->get_branding();
		$html     = $this->render_report_html( $report, $branding );

		wp_send_json_success( array(
			'html'     => $html,
			'filename' => sanitize_file_name(
				'sitevitals-speed-report-' . gmdate( 'Y-m-d' ) . '.html'
			),
		) );
	}

	/**
	 * AJAX: Export report as PDF (via browser print).
	 */
	public function ajax_export_pdf() {
		check_ajax_referer( 'sitevitals_so_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}

		$report   = $this->gather_report_data();
		$branding = $this->get_branding();
		$html     = $this->render_report_html( $report, $branding );

		wp_send_json_success( array(
			'html' => $html,
		) );
	}

	/**
	 * Render a standalone HTML report with white-label branding.
	 *
	 * @param array $report   Report data.
	 * @param array $branding White-label branding settings.
	 * @return string
	 */
	private function render_report_html( $report, $branding ) {
		$agency_name  = ! empty( $branding['name'] ) ? $branding['name'] : 'SiteVitals';
		$agency_color = ! empty( $branding['color'] ) ? $branding['color'] : '#6366f1';
		$agency_logo  = ! empty( $branding['logo'] ) ? $branding['logo'] : '';
		$site_name    = get_bloginfo( 'name' );
		$site_url     = home_url();
		$score        = $report['score'];
		$grade        = $report['grade'];
		$date         = current_time( 'F j, Y' );

		$grade_colors = array(
			'A' => '#22c55e', 'B' => '#84cc16', 'C' => '#eab308',
			'D' => '#f97316', 'F' => '#ef4444',
		);
		$grade_color = $grade_colors[ $grade ] ?? '#6b7280';

		ob_start();
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="UTF-8">
			<title><?php echo esc_html( $agency_name ); ?> - <?php esc_html_e( 'Speed Report', 'sitevitals-speed-optimizer-pro' ); ?> - <?php echo esc_html( $site_name ); ?></title>
			<style>
				body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #1e293b; max-width: 800px; margin: 0 auto; padding: 40px 20px; }
				.header { text-align: center; margin-bottom: 32px; border-bottom: 3px solid <?php echo esc_attr( $agency_color ); ?>; padding-bottom: 24px; }
				.header h1 { font-size: 28px; margin: 0; color: <?php echo esc_attr( $agency_color ); ?>; }
				.header p { color: #6b7280; margin: 4px 0; }
				.site-info { background: #f8fafc; border-radius: 8px; padding: 20px; margin-bottom: 30px; }
				.site-info-row { display: flex; justify-content: space-between; padding: 6px 0; }
				.site-info-label { font-size: 13px; color: #6b7280; text-transform: uppercase; font-weight: 600; letter-spacing: 0.3px; }
				.site-info-value { font-size: 14px; color: #1e293b; font-weight: 500; }
				.site-info-value a { color: <?php echo esc_attr( $agency_color ); ?>; text-decoration: none; }
				.score-section { text-align: center; margin: 30px 0; }
				.score-circle { display: inline-block; width: 100px; height: 100px; border-radius: 50%; background: <?php echo esc_attr( $grade_color ); ?>; line-height: 100px; text-align: center; }
				.score-circle span { color: #fff; font-size: 40px; font-weight: bold; }
				.section { margin: 30px 0; }
				.section h2 { font-size: 18px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; }
				.stat-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin: 20px 0; }
				.stat-card { background: #f8fafc; border-radius: 8px; padding: 20px; text-align: center; }
				.stat-card .stat-number { font-size: 28px; font-weight: bold; color: <?php echo esc_attr( $agency_color ); ?>; }
				.stat-card .stat-label { font-size: 12px; color: #6b7280; text-transform: uppercase; margin-top: 4px; }
				.rec-item { padding: 12px; margin-bottom: 8px; background: #f8fafc; border-left: 3px solid <?php echo esc_attr( $agency_color ); ?>; border-radius: 0 4px 4px 0; }
				.rec-item strong { color: #1e293b; font-size: 14px; }
				.rec-item p { color: #6b7280; font-size: 13px; margin: 4px 0 0; }
				.footer { text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #e2e8f0; color: #9ca3af; font-size: 12px; }
				@media print { body { padding: 0; } .header { break-after: avoid; } }
			</style>
		</head>
		<body>
			<div class="header">
				<?php if ( $agency_logo ) : ?>
					<img src="<?php echo esc_url( $agency_logo ); ?>" alt="<?php echo esc_attr( $agency_name ); ?>" style="max-height:60px;margin-bottom:16px;" />
				<?php endif; ?>
				<h1><?php echo esc_html( $agency_name ); ?></h1>
				<p style="font-size:16px;color:#475569;margin:8px 0 4px;">
					<?php esc_html_e( 'Site Speed Performance Report', 'sitevitals-speed-optimizer-pro' ); ?>
				</p>
				<p><?php echo esc_html( $date ); ?></p>
			</div>

			<!-- Site Info -->
			<div class="site-info">
				<div class="site-info-row">
					<span class="site-info-label"><?php esc_html_e( 'Site', 'sitevitals-speed-optimizer-pro' ); ?></span>
					<span class="site-info-value"><?php echo esc_html( $site_name ); ?></span>
				</div>
				<div class="site-info-row">
					<span class="site-info-label"><?php esc_html_e( 'URL', 'sitevitals-speed-optimizer-pro' ); ?></span>
					<span class="site-info-value"><a href="<?php echo esc_url( $site_url ); ?>"><?php echo esc_html( $site_url ); ?></a></span>
				</div>
				<div class="site-info-row">
					<span class="site-info-label"><?php esc_html_e( 'Report Date', 'sitevitals-speed-optimizer-pro' ); ?></span>
					<span class="site-info-value"><?php echo esc_html( $date ); ?></span>
				</div>
				<?php if ( $agency_name !== 'SiteVitals' ) : ?>
					<div class="site-info-row">
						<span class="site-info-label"><?php esc_html_e( 'Prepared By', 'sitevitals-speed-optimizer-pro' ); ?></span>
						<span class="site-info-value"><?php echo esc_html( $agency_name ); ?></span>
					</div>
				<?php endif; ?>
			</div>

			<!-- Score -->
			<div class="score-section">
				<div class="score-circle"><span><?php echo esc_html( $grade ); ?></span></div>
				<p style="font-size:24px;font-weight:bold;margin:12px 0 4px;"><?php echo esc_html( $score ); ?>/100</p>
				<p style="color:#6b7280;font-size:14px;margin:0;"><?php esc_html_e( 'Overall Performance Score', 'sitevitals-speed-optimizer-pro' ); ?></p>
			</div>

			<!-- Optimization Stats -->
			<div class="section">
				<h2><?php esc_html_e( 'Optimization Summary', 'sitevitals-speed-optimizer-pro' ); ?></h2>
				<div class="stat-grid">
					<?php if ( ! empty( $report['stats']['critical_css'] ) ) : ?>
						<div class="stat-card">
							<div class="stat-number"><?php echo esc_html( $report['stats']['critical_css']['files'] ); ?></div>
							<div class="stat-label"><?php esc_html_e( 'Critical CSS Files', 'sitevitals-speed-optimizer-pro' ); ?></div>
						</div>
					<?php endif; ?>

					<?php if ( ! empty( $report['stats']['unused_css'] ) ) : ?>
						<div class="stat-card">
							<div class="stat-number"><?php echo esc_html( $report['stats']['unused_css']['savings_percent'] ); ?>%</div>
							<div class="stat-label"><?php esc_html_e( 'CSS Reduction', 'sitevitals-speed-optimizer-pro' ); ?></div>
						</div>
					<?php endif; ?>

					<?php if ( ! empty( $report['stats']['images'] ) ) : ?>
						<div class="stat-card">
							<div class="stat-number"><?php echo esc_html( $report['stats']['images']['total_converted'] ); ?></div>
							<div class="stat-label"><?php esc_html_e( 'Images Converted', 'sitevitals-speed-optimizer-pro' ); ?></div>
						</div>
						<div class="stat-card">
							<div class="stat-number"><?php echo esc_html( $report['stats']['images']['savings_percent'] ); ?>%</div>
							<div class="stat-label"><?php esc_html_e( 'Image Size Savings', 'sitevitals-speed-optimizer-pro' ); ?></div>
						</div>
					<?php endif; ?>
				</div>
			</div>

			<!-- Recommendations -->
			<div class="section">
				<h2><?php esc_html_e( 'Recommendations', 'sitevitals-speed-optimizer-pro' ); ?></h2>
				<?php
				$sitevitals_so_pro_recommendations = array();

				if ( ! empty( $report['stats']['critical_css'] ) && ! $report['stats']['critical_css']['enabled'] ) {
					$sitevitals_so_pro_recommendations[] = array(
						'title'   => __( 'Enable Critical CSS', 'sitevitals-speed-optimizer-pro' ),
						'message' => __( 'Generating and inlining critical CSS reduces render-blocking resources.', 'sitevitals-speed-optimizer-pro' ),
					);
				}

				if ( ! empty( $report['stats']['unused_css'] ) && ! $report['stats']['unused_css']['enabled'] ) {
					$sitevitals_so_pro_recommendations[] = array(
						'title'   => __( 'Enable Unused CSS Removal', 'sitevitals-speed-optimizer-pro' ),
						'message' => __( 'Removing unused CSS rules reduces file sizes and improves load time.', 'sitevitals-speed-optimizer-pro' ),
					);
				}

				if ( ! empty( $report['stats']['images'] ) && ! $report['stats']['images']['enabled'] ) {
					$sitevitals_so_pro_recommendations[] = array(
						'title'   => __( 'Enable WebP/AVIF Conversion', 'sitevitals-speed-optimizer-pro' ),
						'message' => __( 'Modern image formats provide better compression with similar quality.', 'sitevitals-speed-optimizer-pro' ),
					);
				}

				if ( empty( $sitevitals_so_pro_recommendations ) ) {
					$sitevitals_so_pro_recommendations[] = array(
						'title'   => __( 'Great job!', 'sitevitals-speed-optimizer-pro' ),
						'message' => __( 'All Pro optimization features are active.', 'sitevitals-speed-optimizer-pro' ),
					);
				}

				foreach ( $sitevitals_so_pro_recommendations as $sitevitals_so_pro_rec ) :
					?>
					<div class="rec-item">
						<strong><?php echo esc_html( $sitevitals_so_pro_rec['title'] ); ?></strong>
						<p><?php echo esc_html( $sitevitals_so_pro_rec['message'] ); ?></p>
					</div>
				<?php endforeach; ?>
			</div>

			<div class="footer">
				<p><?php echo esc_html( $agency_name ); ?> | <?php echo esc_html( $site_url ); ?> | <?php echo esc_html( $date ); ?></p>
			</div>
		</body>
		</html>
		<?php
		return ob_get_clean();
	}
}
