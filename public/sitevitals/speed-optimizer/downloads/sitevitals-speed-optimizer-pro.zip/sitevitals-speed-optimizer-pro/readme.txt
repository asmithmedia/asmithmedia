=== SiteVitals Speed Optimizer Pro ===
Contributors: asmithmedia
Tags: speed, performance, critical css, webp, avif, cdn, optimization
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Pro add-on for SiteVitals Speed Optimizer. Critical CSS, unused CSS removal, WebP/AVIF conversion, performance history, CDN integration, and more.

== Description ==

**SiteVitals Speed Optimizer Pro** is the premium add-on for the free [SiteVitals Speed Optimizer](https://wordpress.org/plugins/sitevitals-speed-optimizer/) plugin. It unlocks advanced speed optimization features that go beyond the basics.

= Requirements =

* SiteVitals Speed Optimizer (free plugin) must be installed and active.
* WordPress 6.0 or higher.
* PHP 7.4 or higher.
* PHP sodium extension (for license key validation).

= Pro Features =

**Critical CSS Generation**
Generate and inline above-the-fold critical CSS for your pages. Full stylesheets are automatically deferred, eliminating render-blocking CSS and dramatically improving First Contentful Paint (FCP).

**Unused CSS Removal**
Scan your pages and remove CSS rules that are never used. Reduce your total CSS payload by up to 90%, resulting in faster load times and better Core Web Vitals scores.

**WebP/AVIF Image Conversion**
Automatically convert uploaded images to modern WebP or AVIF formats. Bulk convert existing images with a single click. Serve the smallest possible images without sacrificing quality.

**Scheduled Database Cleanup**
Set it and forget it. Automatically clean post revisions, auto-drafts, spam comments, expired transients, and trashed items on a daily, weekly, or monthly schedule.

**Advanced JavaScript Delay**
Delay non-critical JavaScript execution until the user interacts with the page (scroll, click, mousemove, touch, keydown). Dramatically improve Time to Interactive (TTI) and Total Blocking Time (TBT).

**Preload & Prefetch Manager**
Add preload hints for critical fonts, CSS, and images. DNS prefetch external domains. Preconnect to CDN and API endpoints. Auto-detect and preload Google Fonts and theme fonts.

**CDN Integration**
Rewrite static asset URLs to your CDN domain. Configure which directories and file types are served via CDN. Test CDN connectivity from the settings page.

**Performance History**
Track your performance score over time with interactive Chart.js graphs. View 7, 30, 60, or 90 days of history. Identify trends and measure the impact of your optimizations.

**Slack & Email Notifications**
Get alerted when your performance score drops below a configurable threshold. Receive Slack webhook notifications and/or email alerts. Batched alerts to avoid notification fatigue.

**White-Label Reports**
Generate branded performance reports for your clients. Customize with your agency name, logo, and brand color. Export as HTML or PDF (via browser print).

== Installation ==

1. Ensure the free SiteVitals Speed Optimizer plugin is installed and active.
2. Upload the `sitevitals-speed-optimizer-pro` folder to the `/wp-content/plugins/` directory.
3. Activate the plugin through the 'Plugins' menu in WordPress.
4. Enter your license key when prompted (or go to Speed Optimizer > Settings > License Key).
5. Configure Pro features in Speed Optimizer > Settings.

== Frequently Asked Questions ==

= Do I need the free plugin? =

Yes. SiteVitals Speed Optimizer Pro is an add-on that extends the free SiteVitals Speed Optimizer plugin. The free plugin must be installed and active.

= How do I get a license key? =

Purchase a license at [asmith.media/sitevitals/speed-optimizer/](https://asmith.media/sitevitals/speed-optimizer/). Your license key will be emailed to you after purchase.

= Does image conversion require special server support? =

WebP conversion requires PHP GD with WebP support (available on most modern hosts). AVIF support requires PHP 8.1+ with GD AVIF support, which is less widely available.

= Is Critical CSS generated automatically? =

You can enable auto-generation for new pages, or manually generate critical CSS from the dashboard. A queue system processes pages in the background via WP Cron.

= Can I use this with a CDN? =

Yes! The CDN Helper rewrites your static asset URLs to your CDN domain. It works with any pull-zone CDN (Cloudflare, BunnyCDN, KeyCDN, StackPath, etc.).

== Changelog ==

= 1.0.0 =
* Initial release.
* Critical CSS generation and inlining.
* Unused CSS detection and removal.
* WebP/AVIF image conversion (on-upload and bulk).
* Scheduled database cleanup (daily/weekly/monthly).
* Advanced JavaScript delay until user interaction.
* Preload, prefetch, and preconnect manager.
* CDN URL rewriting for static assets.
* Performance score history with Chart.js graphs.
* Slack webhook and email alert notifications.
* White-label agency reports (HTML/PDF export).
* Ed25519 cryptographic license key validation.
