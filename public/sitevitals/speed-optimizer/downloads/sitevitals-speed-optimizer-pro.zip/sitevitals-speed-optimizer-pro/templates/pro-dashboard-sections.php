<?php
/**
 * Pro Dashboard Sections - renders Pro feature panels on the free plugin's dashboard.
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 * @var array $report Performance report data passed via do_action.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$sitevitals_so_pro_critical_stats = SiteVitals_SO_Critical_CSS::instance()->get_stats();
$sitevitals_so_pro_unused_stats   = SiteVitals_SO_Unused_CSS::instance()->get_stats();
$sitevitals_so_pro_image_stats    = SiteVitals_SO_Image_Converter::instance()->get_stats();
$sitevitals_so_pro_branding       = SiteVitals_SO_White_Label::instance()->get_branding();
?>

<!-- Pro Feature Grid: Row 1 -->
<div class="sitevitals-so-pro-panels">

	<!-- Critical CSS Status -->
	<div class="sitevitals-so-section sitevitals-so-pro-panel">
		<div class="sitevitals-so-section-header">
			<h2 class="sitevitals-so-section-title">
				<span class="dashicons dashicons-art"></span>
				<?php esc_html_e( 'Critical CSS', 'sitevitals-speed-optimizer-pro' ); ?>
			</h2>
			<span class="sv-so-pro-status-badge <?php echo $sitevitals_so_pro_critical_stats['enabled'] ? 'sv-so-pro-status--active' : 'sv-so-pro-status--inactive'; ?>">
				<?php echo $sitevitals_so_pro_critical_stats['enabled'] ? esc_html__( 'Active', 'sitevitals-speed-optimizer-pro' ) : esc_html__( 'Inactive', 'sitevitals-speed-optimizer-pro' ); ?>
			</span>
		</div>
		<div class="sv-so-pro-stat-row">
			<div class="sv-so-pro-stat">
				<span class="sv-so-pro-stat-number"><?php echo esc_html( $sitevitals_so_pro_critical_stats['files'] ); ?></span>
				<span class="sv-so-pro-stat-label"><?php esc_html_e( 'Pages', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sv-so-pro-stat">
				<span class="sv-so-pro-stat-number"><?php echo esc_html( size_format( $sitevitals_so_pro_critical_stats['total_size'] ) ); ?></span>
				<span class="sv-so-pro-stat-label"><?php esc_html_e( 'CSS Size', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sv-so-pro-stat">
				<span class="sv-so-pro-stat-number"><?php echo esc_html( $sitevitals_so_pro_critical_stats['queue'] ); ?></span>
				<span class="sv-so-pro-stat-label"><?php esc_html_e( 'In Queue', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
		</div>
		<div class="sv-so-pro-actions">
			<button type="button" class="sitevitals-so-btn sitevitals-so-btn-secondary" id="sv-so-pro-generate-critical">
				<span class="dashicons dashicons-update"></span>
				<?php esc_html_e( 'Generate', 'sitevitals-speed-optimizer-pro' ); ?>
			</button>
			<button type="button" class="sitevitals-so-btn sitevitals-so-btn-secondary" id="sv-so-pro-purge-critical">
				<?php esc_html_e( 'Purge', 'sitevitals-speed-optimizer-pro' ); ?>
			</button>
		</div>
	</div>

	<!-- Unused CSS Status -->
	<div class="sitevitals-so-section sitevitals-so-pro-panel">
		<div class="sitevitals-so-section-header">
			<h2 class="sitevitals-so-section-title">
				<span class="dashicons dashicons-editor-strikethrough"></span>
				<?php esc_html_e( 'Unused CSS', 'sitevitals-speed-optimizer-pro' ); ?>
			</h2>
			<span class="sv-so-pro-status-badge <?php echo $sitevitals_so_pro_unused_stats['enabled'] ? 'sv-so-pro-status--active' : 'sv-so-pro-status--inactive'; ?>">
				<?php echo $sitevitals_so_pro_unused_stats['enabled'] ? esc_html__( 'Active', 'sitevitals-speed-optimizer-pro' ) : esc_html__( 'Inactive', 'sitevitals-speed-optimizer-pro' ); ?>
			</span>
		</div>
		<div class="sv-so-pro-stat-row">
			<div class="sv-so-pro-stat">
				<span class="sv-so-pro-stat-number"><?php echo esc_html( $sitevitals_so_pro_unused_stats['files'] ); ?></span>
				<span class="sv-so-pro-stat-label"><?php esc_html_e( 'Files', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sv-so-pro-stat">
				<span class="sv-so-pro-stat-number"><?php echo esc_html( $sitevitals_so_pro_unused_stats['savings_percent'] ); ?>%</span>
				<span class="sv-so-pro-stat-label"><?php esc_html_e( 'Reduction', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sv-so-pro-stat">
				<span class="sv-so-pro-stat-number"><?php echo esc_html( size_format( $sitevitals_so_pro_unused_stats['savings'] ) ); ?></span>
				<span class="sv-so-pro-stat-label"><?php esc_html_e( 'Saved', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
		</div>
		<div class="sv-so-pro-actions">
			<button type="button" class="sitevitals-so-btn sitevitals-so-btn-secondary" id="sv-so-pro-scan-unused">
				<span class="dashicons dashicons-search"></span>
				<?php esc_html_e( 'Scan', 'sitevitals-speed-optimizer-pro' ); ?>
			</button>
			<button type="button" class="sitevitals-so-btn sitevitals-so-btn-secondary" id="sv-so-pro-purge-unused">
				<?php esc_html_e( 'Purge', 'sitevitals-speed-optimizer-pro' ); ?>
			</button>
		</div>
	</div>
</div>

<!-- Pro Feature Grid: Row 2 -->
<div class="sitevitals-so-pro-panels">

	<!-- Image Conversion Stats -->
	<div class="sitevitals-so-section sitevitals-so-pro-panel">
		<div class="sitevitals-so-section-header">
			<h2 class="sitevitals-so-section-title">
				<span class="dashicons dashicons-format-image"></span>
				<?php esc_html_e( 'Image Conversion', 'sitevitals-speed-optimizer-pro' ); ?>
			</h2>
			<span class="sv-so-pro-status-badge <?php echo $sitevitals_so_pro_image_stats['enabled'] ? 'sv-so-pro-status--active' : 'sv-so-pro-status--inactive'; ?>">
				<?php echo esc_html( strtoupper( $sitevitals_so_pro_image_stats['format'] ) ); ?>
			</span>
		</div>
		<div class="sv-so-pro-stat-row">
			<div class="sv-so-pro-stat">
				<span class="sv-so-pro-stat-number"><?php echo esc_html( $sitevitals_so_pro_image_stats['total_converted'] ); ?></span>
				<span class="sv-so-pro-stat-label"><?php esc_html_e( 'Converted', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sv-so-pro-stat">
				<span class="sv-so-pro-stat-number"><?php echo esc_html( $sitevitals_so_pro_image_stats['savings_percent'] ); ?>%</span>
				<span class="sv-so-pro-stat-label"><?php esc_html_e( 'Savings', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sv-so-pro-stat">
				<span class="sv-so-pro-stat-number"><?php echo esc_html( size_format( $sitevitals_so_pro_image_stats['savings'] ) ); ?></span>
				<span class="sv-so-pro-stat-label"><?php esc_html_e( 'Saved', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
		</div>
		<div class="sv-so-pro-actions">
			<button type="button" class="sitevitals-so-btn sitevitals-so-btn-secondary" id="sv-so-pro-bulk-convert">
				<span class="dashicons dashicons-images-alt2"></span>
				<?php esc_html_e( 'Bulk Convert', 'sitevitals-speed-optimizer-pro' ); ?>
			</button>
			<span id="sv-so-pro-convert-status" class="sitevitals-so-inline-status"></span>
		</div>
	</div>

	<!-- Export & Reports -->
	<div class="sitevitals-so-section sitevitals-so-pro-panel">
		<div class="sitevitals-so-section-header">
			<h2 class="sitevitals-so-section-title">
				<span class="dashicons dashicons-media-document"></span>
				<?php esc_html_e( 'Export Reports', 'sitevitals-speed-optimizer-pro' ); ?>
			</h2>
		</div>
		<div class="sv-so-pro-export-options">
			<button type="button" class="sitevitals-so-btn sitevitals-so-btn-secondary sv-so-pro-export-btn" id="sv-so-pro-export-html">
				<span class="dashicons dashicons-media-code"></span>
				<?php esc_html_e( 'Export HTML', 'sitevitals-speed-optimizer-pro' ); ?>
			</button>
			<button type="button" class="sitevitals-so-btn sitevitals-so-btn-secondary sv-so-pro-export-btn" id="sv-so-pro-export-pdf">
				<span class="dashicons dashicons-pdf"></span>
				<?php esc_html_e( 'Export PDF', 'sitevitals-speed-optimizer-pro' ); ?>
			</button>
		</div>
		<?php if ( ! empty( $sitevitals_so_pro_branding['name'] ) ) : ?>
			<p class="sv-so-pro-brand-note">
				<?php
				printf(
					/* translators: %s: agency name */
					esc_html__( 'Branded as: %s', 'sitevitals-speed-optimizer-pro' ),
					'<strong>' . esc_html( $sitevitals_so_pro_branding['name'] ) . '</strong>'
				);
				?>
			</p>
		<?php else : ?>
			<p class="sv-so-pro-brand-note">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=sitevitals-so-settings' ) ); ?>" style="color:#8b5cf6;text-decoration:underline;">
					<?php esc_html_e( 'Set your agency name in Settings to white-label reports.', 'sitevitals-speed-optimizer-pro' ); ?>
				</a>
			</p>
		<?php endif; ?>
	</div>
</div>

<!-- Performance History Chart -->
<div class="sitevitals-so-section sitevitals-so-pro-panel" style="margin-bottom:16px;">
	<div class="sitevitals-so-section-header">
		<h2 class="sitevitals-so-section-title">
			<span class="dashicons dashicons-chart-line"></span>
			<?php esc_html_e( 'Performance History', 'sitevitals-speed-optimizer-pro' ); ?>
		</h2>
		<select id="sv-so-pro-history-range" class="sv-so-pro-select">
			<option value="7"><?php esc_html_e( '7 days', 'sitevitals-speed-optimizer-pro' ); ?></option>
			<option value="30" selected><?php esc_html_e( '30 days', 'sitevitals-speed-optimizer-pro' ); ?></option>
			<option value="60"><?php esc_html_e( '60 days', 'sitevitals-speed-optimizer-pro' ); ?></option>
			<option value="90"><?php esc_html_e( '90 days', 'sitevitals-speed-optimizer-pro' ); ?></option>
		</select>
	</div>
	<div class="sv-so-pro-chart-wrap">
		<canvas id="sv-so-pro-history-chart" height="220"></canvas>
		<p class="sv-so-pro-chart-empty" id="sv-so-pro-history-empty" style="display:none;">
			<?php esc_html_e( 'History data will appear after a few daily scans.', 'sitevitals-speed-optimizer-pro' ); ?>
		</p>
	</div>
</div>

<!-- Pro-specific CSS -->
<style>
.sitevitals-so-pro-panels {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 16px;
	margin-bottom: 16px;
}
.sitevitals-so-pro-panel { margin-bottom: 0; }

.sv-so-pro-select {
	background: rgba(255,255,255,0.04);
	border: 1px solid rgba(255,255,255,0.1);
	color: #e2e8f0;
	border-radius: 6px;
	padding: 4px 8px;
	font-size: 12px;
}

.sv-so-pro-chart-wrap {
	min-height: 220px;
	display: flex;
	align-items: center;
	justify-content: center;
}
.sv-so-pro-chart-empty {
	color: #64748b;
	font-size: 13px;
	text-align: center;
}

/* Status badge */
.sv-so-pro-status-badge {
	padding: 3px 10px;
	border-radius: 10px;
	font-size: 11px;
	font-weight: 700;
	text-transform: uppercase;
	letter-spacing: 0.5px;
}
.sv-so-pro-status--active {
	background: rgba(34,197,94,0.12);
	color: #4ade80;
}
.sv-so-pro-status--inactive {
	background: rgba(148,163,184,0.12);
	color: #94a3b8;
}

/* Stat row */
.sv-so-pro-stat-row {
	display: flex;
	gap: 16px;
	margin-bottom: 16px;
}
.sv-so-pro-stat {
	flex: 1;
	text-align: center;
	padding: 12px 8px;
	background: rgba(255,255,255,0.02);
	border-radius: 8px;
}
.sv-so-pro-stat-number {
	display: block;
	font-size: 20px;
	font-weight: 700;
	color: #e2e8f0;
}
.sv-so-pro-stat-label {
	display: block;
	font-size: 11px;
	color: #64748b;
	text-transform: uppercase;
	letter-spacing: 0.3px;
	margin-top: 2px;
}

/* Actions */
.sv-so-pro-actions {
	display: flex;
	gap: 8px;
	align-items: center;
}

/* Export buttons */
.sv-so-pro-export-options {
	display: flex;
	gap: 10px;
	margin-bottom: 16px;
}
.sv-so-pro-export-btn { flex: 1; justify-content: center; }
.sv-so-pro-brand-note {
	color: #64748b;
	font-size: 12px;
	margin: 0;
}

@media (max-width: 768px) {
	.sitevitals-so-pro-panels { grid-template-columns: 1fr; }
}
</style>

<!-- Pro Dashboard JS -->
<script>
jQuery(function($) {
	'use strict';

	// Load Chart.js from CDN for performance history.
	var sitevitals_so_pro_chart_script = document.createElement('script');
	sitevitals_so_pro_chart_script.src = 'https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js';
	sitevitals_so_pro_chart_script.onload = function() { sitevitals_so_pro_load_chart(); };
	document.head.appendChild(sitevitals_so_pro_chart_script);

	function sitevitals_so_pro_load_chart(days) {
		days = days || 30;
		$.post(sitevitals_so.ajax_url, {
			action: 'sitevitals_so_pro_perf_history',
			nonce: sitevitals_so.nonce,
			days: days
		}).done(function(r) {
			if (!r.success || !r.data.datasets || r.data.datasets.length === 0) {
				$('#sv-so-pro-history-chart').hide();
				$('#sv-so-pro-history-empty').show();
				return;
			}
			$('#sv-so-pro-history-chart').show();
			$('#sv-so-pro-history-empty').hide();

			var ctx = document.getElementById('sv-so-pro-history-chart').getContext('2d');
			if (window.svSOProHistoryChart) window.svSOProHistoryChart.destroy();

			window.svSOProHistoryChart = new Chart(ctx, {
				type: 'line',
				data: r.data,
				options: {
					responsive: true,
					maintainAspectRatio: false,
					plugins: { legend: { labels: { color: '#94a3b8', font: { size: 11 } } } },
					scales: {
						x: { ticks: { color: '#475569', font: { size: 10 } }, grid: { color: 'rgba(255,255,255,0.04)' } },
						y: { min: 0, max: 100, ticks: { color: '#475569' }, grid: { color: 'rgba(255,255,255,0.04)' } }
					}
				}
			});
		});
	}

	$('#sv-so-pro-history-range').on('change', function() {
		sitevitals_so_pro_load_chart($(this).val());
	});

	// Critical CSS: Generate.
	$('#sv-so-pro-generate-critical').on('click', function() {
		var $btn = $(this);
		$btn.prop('disabled', true).text('Generating...');
		$.post(sitevitals_so.ajax_url, {
			action: 'sitevitals_so_pro_generate_critical_css',
			nonce: sitevitals_so.nonce,
			url: window.location.origin + '/'
		}).done(function(r) {
			if (r.success) {
				$btn.text(r.data.message);
				setTimeout(function() { location.reload(); }, 1500);
			} else {
				$btn.text(r.data || 'Failed');
			}
		}).always(function() {
			setTimeout(function() {
				$btn.prop('disabled', false).html('<span class="dashicons dashicons-update"></span> Generate');
			}, 3000);
		});
	});

	// Critical CSS: Purge.
	$('#sv-so-pro-purge-critical').on('click', function() {
		var $btn = $(this);
		$btn.prop('disabled', true).text('Purging...');
		$.post(sitevitals_so.ajax_url, {
			action: 'sitevitals_so_pro_purge_critical_css',
			nonce: sitevitals_so.nonce
		}).done(function(r) {
			if (r.success) {
				setTimeout(function() { location.reload(); }, 500);
			}
		});
	});

	// Unused CSS: Scan.
	$('#sv-so-pro-scan-unused').on('click', function() {
		var $btn = $(this);
		$btn.prop('disabled', true).text('Scanning...');
		$.post(sitevitals_so.ajax_url, {
			action: 'sitevitals_so_pro_scan_unused_css',
			nonce: sitevitals_so.nonce,
			url: window.location.origin + '/'
		}).done(function(r) {
			if (r.success) {
				$btn.text(r.data.message);
				setTimeout(function() { location.reload(); }, 1500);
			} else {
				$btn.text(r.data || 'Failed');
			}
		}).always(function() {
			setTimeout(function() {
				$btn.prop('disabled', false).html('<span class="dashicons dashicons-search"></span> Scan');
			}, 3000);
		});
	});

	// Unused CSS: Purge.
	$('#sv-so-pro-purge-unused').on('click', function() {
		var $btn = $(this);
		$btn.prop('disabled', true).text('Purging...');
		$.post(sitevitals_so.ajax_url, {
			action: 'sitevitals_so_pro_purge_unused_css',
			nonce: sitevitals_so.nonce
		}).done(function(r) {
			if (r.success) {
				setTimeout(function() { location.reload(); }, 500);
			}
		});
	});

	// Bulk Convert Images.
	$('#sv-so-pro-bulk-convert').on('click', function() {
		var $btn = $(this);
		var $status = $('#sv-so-pro-convert-status');
		$btn.prop('disabled', true);

		function sitevitals_so_pro_convert_batch(offset) {
			$status.text('Converting batch from ' + offset + '...').css('color', '#94a3b8');
			$.post(sitevitals_so.ajax_url, {
				action: 'sitevitals_so_pro_bulk_convert_images',
				nonce: sitevitals_so.nonce,
				offset: offset,
				batch_size: 10
			}).done(function(r) {
				if (r.success) {
					if (r.data.has_more) {
						sitevitals_so_pro_convert_batch(r.data.offset);
					} else {
						$status.text('Complete! ' + r.data.converted + ' converted.').css('color', '#4ade80');
						$btn.prop('disabled', false).html('<span class="dashicons dashicons-images-alt2"></span> Bulk Convert');
						setTimeout(function() { location.reload(); }, 2000);
					}
				} else {
					$status.text(r.data || 'Failed').css('color', '#f87171');
					$btn.prop('disabled', false);
				}
			}).fail(function() {
				$status.text('Error occurred').css('color', '#f87171');
				$btn.prop('disabled', false);
			});
		}

		sitevitals_so_pro_convert_batch(0);
	});

	// Export HTML.
	$('#sv-so-pro-export-html').on('click', function() {
		var $btn = $(this);
		$btn.prop('disabled', true).text('Exporting...');
		$.post(sitevitals_so.ajax_url, {
			action: 'sitevitals_so_pro_export_html',
			nonce: sitevitals_so.nonce
		}).done(function(r) {
			if (!r.success) { return; }
			var blob = new Blob([r.data.html], { type: 'text/html' });
			var a = document.createElement('a');
			a.href = URL.createObjectURL(blob);
			a.download = r.data.filename || 'sitevitals-speed-report.html';
			a.click();
		}).always(function() {
			$btn.prop('disabled', false).html('<span class="dashicons dashicons-media-code"></span> Export HTML');
		});
	});

	// Export PDF.
	$('#sv-so-pro-export-pdf').on('click', function() {
		var $btn = $(this);
		$btn.prop('disabled', true).text('Generating...');
		$.post(sitevitals_so.ajax_url, {
			action: 'sitevitals_so_pro_export_pdf',
			nonce: sitevitals_so.nonce
		}).done(function(r) {
			if (!r.success) { return; }
			var win = window.open('', '_blank');
			win.document.write(r.data.html);
			win.document.close();
			setTimeout(function() { win.print(); }, 500);
		}).always(function() {
			$btn.prop('disabled', false).html('<span class="dashicons dashicons-pdf"></span> Export PDF');
		});
	});
});
</script>
