<?php
/**
 * Pro Activation / Onboarding template.
 *
 * Flow: Welcome -> Enter License -> Validate -> Enable -> Dashboard
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<style>
	/* Dark background for this page */
	.admin_page_sitevitals-so-pro-activate #wpcontent { background: #0b0f19; }
	.admin_page_sitevitals-so-pro-activate #wpbody-content { padding-bottom: 40px; }
</style>

<div class="wrap sitevitals-so-wrap">
	<div class="sitevitals-so-firstrun" id="sv-so-pro-onboard">

		<!-- Phase 1: Welcome + License Key Entry -->
		<div id="sv-so-pro-phase-license">
			<div class="sitevitals-so-firstrun-header">
				<div class="sitevitals-so-firstrun-logo">
					<div class="sitevitals-so-firstrun-logo-ring" style="background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);"></div>
					<span class="dashicons dashicons-performance"></span>
				</div>
				<h1>Site<span>Vitals</span> Speed Optimizer Pro</h1>
				<p class="sitevitals-so-firstrun-subtitle"><?php esc_html_e( 'Welcome to the Pro experience', 'sitevitals-speed-optimizer-pro' ); ?></p>
			</div>

			<!-- Features unlocked -->
			<div class="sv-so-pro-unlock-grid">
				<div class="sv-so-pro-unlock-item">
					<span class="sv-so-pro-unlock-icon">&#x1f3a8;</span>
					<span><?php esc_html_e( 'Critical CSS', 'sitevitals-speed-optimizer-pro' ); ?></span>
				</div>
				<div class="sv-so-pro-unlock-item">
					<span class="sv-so-pro-unlock-icon">&#x2702;</span>
					<span><?php esc_html_e( 'Unused CSS Removal', 'sitevitals-speed-optimizer-pro' ); ?></span>
				</div>
				<div class="sv-so-pro-unlock-item">
					<span class="sv-so-pro-unlock-icon">&#x1f5bc;</span>
					<span><?php esc_html_e( 'WebP/AVIF Conversion', 'sitevitals-speed-optimizer-pro' ); ?></span>
				</div>
				<div class="sv-so-pro-unlock-item">
					<span class="sv-so-pro-unlock-icon">&#x1f4ca;</span>
					<span><?php esc_html_e( 'Performance History', 'sitevitals-speed-optimizer-pro' ); ?></span>
				</div>
				<div class="sv-so-pro-unlock-item">
					<span class="sv-so-pro-unlock-icon">&#x1f310;</span>
					<span><?php esc_html_e( 'CDN Integration', 'sitevitals-speed-optimizer-pro' ); ?></span>
				</div>
				<div class="sv-so-pro-unlock-item">
					<span class="sv-so-pro-unlock-icon">&#x1f514;</span>
					<span><?php esc_html_e( 'Slack & Email Alerts', 'sitevitals-speed-optimizer-pro' ); ?></span>
				</div>
				<div class="sv-so-pro-unlock-item">
					<span class="sv-so-pro-unlock-icon">&#x1f3f7;</span>
					<span><?php esc_html_e( 'White-Label Reports', 'sitevitals-speed-optimizer-pro' ); ?></span>
				</div>
				<div class="sv-so-pro-unlock-item">
					<span class="sv-so-pro-unlock-icon">&#x26a1;</span>
					<span><?php esc_html_e( 'Advanced JS Delay', 'sitevitals-speed-optimizer-pro' ); ?></span>
				</div>
				<div class="sv-so-pro-unlock-item">
					<span class="sv-so-pro-unlock-icon">&#x1f517;</span>
					<span><?php esc_html_e( 'Preload & Prefetch', 'sitevitals-speed-optimizer-pro' ); ?></span>
				</div>
			</div>

			<!-- License input -->
			<div class="sv-so-pro-license-box">
				<label for="sv-so-pro-license-input"><?php esc_html_e( 'Enter your license key to activate Pro features', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<div class="sv-so-pro-license-input-wrap">
					<input type="text"
						id="sv-so-pro-license-input"
						placeholder="<?php esc_attr_e( 'Paste your license key here...', 'sitevitals-speed-optimizer-pro' ); ?>"
						autocomplete="off"
						spellcheck="false" />
					<button type="button" class="sitevitals-so-btn sitevitals-so-btn-pro" id="sv-so-pro-activate-btn">
						<span class="dashicons dashicons-unlock"></span>
						<?php esc_html_e( 'Activate', 'sitevitals-speed-optimizer-pro' ); ?>
					</button>
				</div>
				<div class="sv-so-pro-license-status" id="sv-so-pro-license-status"></div>
				<p class="sv-so-pro-license-help">
					<?php esc_html_e( 'Your license key was emailed to you after purchase.', 'sitevitals-speed-optimizer-pro' ); ?>
					<a href="https://asmith.media/sitevitals/speed-optimizer/" target="_blank" rel="noopener"><?php esc_html_e( "Don't have a license?", 'sitevitals-speed-optimizer-pro' ); ?></a>
				</p>
			</div>
		</div>

		<!-- Phase 2: Activating (shown after valid license) -->
		<div id="sv-so-pro-phase-scanning" style="display:none;">
			<div class="sitevitals-so-firstrun-header">
				<div class="sitevitals-so-firstrun-logo">
					<div class="sitevitals-so-firstrun-logo-ring" style="background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);"></div>
					<span class="dashicons dashicons-yes"></span>
				</div>
				<h1><?php esc_html_e( 'License Activated!', 'sitevitals-speed-optimizer-pro' ); ?></h1>
				<p class="sitevitals-so-firstrun-subtitle"><?php esc_html_e( 'Setting up Pro features...', 'sitevitals-speed-optimizer-pro' ); ?></p>
			</div>

			<div class="sitevitals-so-firstrun-steps" id="sv-so-pro-steps">
				<div class="sitevitals-so-firstrun-step sitevitals-so-step--active" data-step="license" id="sv-so-pro-step-license">
					<div class="sitevitals-so-step-icon">
						<span class="sitevitals-so-step-spinner"></span>
						<span class="sitevitals-so-step-check dashicons dashicons-yes"></span>
					</div>
					<div class="sitevitals-so-step-content">
						<div class="sitevitals-so-step-title"><?php esc_html_e( 'Validating license', 'sitevitals-speed-optimizer-pro' ); ?></div>
						<div class="sitevitals-so-step-detail" id="sv-so-pro-detail-license">&mdash;</div>
					</div>
				</div>

				<div class="sitevitals-so-firstrun-step" data-step="features" id="sv-so-pro-step-features">
					<div class="sitevitals-so-step-icon">
						<span class="sitevitals-so-step-spinner"></span>
						<span class="sitevitals-so-step-check dashicons dashicons-yes"></span>
					</div>
					<div class="sitevitals-so-step-content">
						<div class="sitevitals-so-step-title"><?php esc_html_e( 'Enabling Pro features', 'sitevitals-speed-optimizer-pro' ); ?></div>
						<div class="sitevitals-so-step-detail" id="sv-so-pro-detail-features">&mdash;</div>
					</div>
				</div>

				<div class="sitevitals-so-firstrun-step" data-step="done" id="sv-so-pro-step-done">
					<div class="sitevitals-so-step-icon">
						<span class="sitevitals-so-step-spinner"></span>
						<span class="sitevitals-so-step-check dashicons dashicons-yes"></span>
					</div>
					<div class="sitevitals-so-step-content">
						<div class="sitevitals-so-step-title"><?php esc_html_e( 'Preparing your Pro dashboard', 'sitevitals-speed-optimizer-pro' ); ?></div>
						<div class="sitevitals-so-step-detail" id="sv-so-pro-detail-done">&mdash;</div>
					</div>
				</div>
			</div>

			<div class="sitevitals-so-firstrun-progress">
				<div class="sitevitals-so-firstrun-progress-bar" id="sv-so-pro-progress-bar"></div>
			</div>
			<div class="sitevitals-so-firstrun-progress-text" id="sv-so-pro-progress-text">
				<?php esc_html_e( 'Activating Pro...', 'sitevitals-speed-optimizer-pro' ); ?>
			</div>
		</div>

	</div>
</div>

<style>
	/* Pro unlock feature grid */
	.sv-so-pro-unlock-grid {
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		gap: 10px;
		margin: 0 0 36px;
	}
	.sv-so-pro-unlock-item {
		display: flex;
		align-items: center;
		gap: 8px;
		padding: 12px 16px;
		background: rgba(255, 255, 255, 0.03);
		border: 1px solid rgba(255, 255, 255, 0.06);
		border-radius: 10px;
		font-size: 13px;
		color: #cbd5e1;
	}
	.sv-so-pro-unlock-icon {
		font-size: 18px;
	}

	/* License input box */
	.sv-so-pro-license-box {
		background: rgba(255, 255, 255, 0.03);
		border: 1px solid rgba(255, 255, 255, 0.08);
		border-radius: 14px;
		padding: 28px;
		text-align: center;
	}
	.sv-so-pro-license-box label {
		display: block;
		font-size: 15px;
		font-weight: 600;
		color: #e2e8f0;
		margin-bottom: 16px;
	}
	.sv-so-pro-license-input-wrap {
		display: flex;
		gap: 10px;
		margin-bottom: 12px;
	}
	.sv-so-pro-license-input-wrap input {
		flex: 1;
		background: rgba(255, 255, 255, 0.04);
		border: 1px solid rgba(255, 255, 255, 0.1);
		border-radius: 8px;
		padding: 12px 16px;
		color: #e2e8f0;
		font-size: 14px;
		font-family: 'SF Mono', 'Cascadia Code', monospace;
	}
	.sv-so-pro-license-input-wrap input:focus {
		border-color: #6366f1;
		box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.2);
		outline: none;
	}
	.sv-so-pro-license-input-wrap input::placeholder {
		color: #475569;
	}
	.sv-so-pro-license-status {
		min-height: 20px;
		font-size: 13px;
		margin-bottom: 8px;
	}
	.sv-so-pro-license-status.sv-so-status-error {
		color: #f87171;
	}
	.sv-so-pro-license-status.sv-so-status-success {
		color: #4ade80;
	}
	.sv-so-pro-license-help {
		font-size: 13px;
		color: #64748b;
		margin: 0;
	}
	.sv-so-pro-license-help a {
		color: #6366f1;
		text-decoration: none;
	}
	.sv-so-pro-license-help a:hover {
		text-decoration: underline;
	}

	/* Shake animation for invalid key */
	@keyframes sv-so-shake {
		0%, 100% { transform: translateX(0); }
		20%, 60% { transform: translateX(-6px); }
		40%, 80% { transform: translateX(6px); }
	}
	.sv-so-shake {
		animation: sv-so-shake 0.4s ease;
	}

	@media (max-width: 600px) {
		.sv-so-pro-unlock-grid { grid-template-columns: 1fr 1fr; }
		.sv-so-pro-license-input-wrap { flex-direction: column; }
	}
</style>

<script>
jQuery(function($) {
	'use strict';

	var sitevitals_so_pro_dashboard_url = '<?php echo esc_url( admin_url( 'admin.php?page=sitevitals-so' ) ); ?>';

	// Activate button click.
	$('#sv-so-pro-activate-btn').on('click', function() {
		var key = $('#sv-so-pro-license-input').val().trim();
		var $status = $('#sv-so-pro-license-status');
		var $btn = $(this);

		if (!key) {
			$status.text('<?php echo esc_js( __( 'Please enter your license key.', 'sitevitals-speed-optimizer-pro' ) ); ?>').attr('class', 'sv-so-pro-license-status sv-so-status-error');
			$('#sv-so-pro-license-input').addClass('sv-so-shake');
			setTimeout(function() { $('#sv-so-pro-license-input').removeClass('sv-so-shake'); }, 500);
			return;
		}

		$btn.prop('disabled', true).text('<?php echo esc_js( __( 'Validating...', 'sitevitals-speed-optimizer-pro' ) ); ?>');
		$status.text('').attr('class', 'sv-so-pro-license-status');

		$.post(sitevitals_so.ajax_url, {
			action: 'sitevitals_so_pro_activate_license',
			nonce: sitevitals_so.nonce,
			license_key: key
		}).done(function(response) {
			if (response.success) {
				$status.text('<?php echo esc_js( __( 'License valid!', 'sitevitals-speed-optimizer-pro' ) ); ?>').attr('class', 'sv-so-pro-license-status sv-so-status-success');
				setTimeout(function() {
					sitevitals_so_pro_start_setup();
				}, 800);
			} else {
				$status.text(response.data).attr('class', 'sv-so-pro-license-status sv-so-status-error');
				$('#sv-so-pro-license-input').addClass('sv-so-shake');
				setTimeout(function() { $('#sv-so-pro-license-input').removeClass('sv-so-shake'); }, 500);
				$btn.prop('disabled', false).html('<span class="dashicons dashicons-unlock"></span> <?php echo esc_js( __( 'Activate', 'sitevitals-speed-optimizer-pro' ) ); ?>');
			}
		}).fail(function() {
			$status.text('<?php echo esc_js( __( 'Connection error. Please try again.', 'sitevitals-speed-optimizer-pro' ) ); ?>').attr('class', 'sv-so-pro-license-status sv-so-status-error');
			$btn.prop('disabled', false).html('<span class="dashicons dashicons-unlock"></span> <?php echo esc_js( __( 'Activate', 'sitevitals-speed-optimizer-pro' ) ); ?>');
		});
	});

	// Enter key triggers activate.
	$('#sv-so-pro-license-input').on('keydown', function(e) {
		if (e.key === 'Enter') {
			e.preventDefault();
			$('#sv-so-pro-activate-btn').click();
		}
	});

	function sitevitals_so_pro_update_progress(percent, text) {
		$('#sv-so-pro-progress-bar').css('width', percent + '%');
		if (text) $('#sv-so-pro-progress-text').text(text);
	}

	function sitevitals_so_pro_complete_step(step, detail) {
		$('#sv-so-pro-step-' + step).removeClass('sitevitals-so-step--active').addClass('sitevitals-so-step--done');
		$('#sv-so-pro-detail-' + step).text(detail);
	}

	function sitevitals_so_pro_activate_step(step) {
		$('#sv-so-pro-step-' + step).addClass('sitevitals-so-step--active');
	}

	function sitevitals_so_pro_start_setup() {
		$('#sv-so-pro-phase-license').fadeOut(400, function() {
			$('#sv-so-pro-phase-scanning').fadeIn(400);
		});

		// Step 1: License (already done).
		setTimeout(function() {
			sitevitals_so_pro_update_progress(30, '<?php echo esc_js( __( 'License validated...', 'sitevitals-speed-optimizer-pro' ) ); ?>');
			sitevitals_so_pro_complete_step('license', '<?php echo esc_js( __( 'License activated', 'sitevitals-speed-optimizer-pro' ) ); ?>');
			sitevitals_so_pro_activate_step('features');
		}, 1000);

		// Step 2: Enable features.
		setTimeout(function() {
			sitevitals_so_pro_update_progress(60, '<?php echo esc_js( __( 'Enabling Critical CSS, CDN, image conversion...', 'sitevitals-speed-optimizer-pro' ) ); ?>');
			sitevitals_so_pro_complete_step('features', '<?php echo esc_js( __( '11 Pro features enabled', 'sitevitals-speed-optimizer-pro' ) ); ?>');
			sitevitals_so_pro_activate_step('done');
		}, 2500);

		// Step 3: Done.
		setTimeout(function() {
			sitevitals_so_pro_update_progress(100, '<?php echo esc_js( __( 'All set! Redirecting to your dashboard...', 'sitevitals-speed-optimizer-pro' ) ); ?>');
			sitevitals_so_pro_complete_step('done', '<?php echo esc_js( __( 'Dashboard ready', 'sitevitals-speed-optimizer-pro' ) ); ?>');

			setTimeout(function() {
				window.location.href = sitevitals_so_pro_dashboard_url;
			}, 1500);
		}, 4000);
	}
});
</script>
