<?php
/**
 * Pro Settings Sections - renders inside the free plugin's settings form.
 *
 * @package SiteVitals_Speed_Optimizer_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<!-- Critical CSS Settings -->
<div class="sitevitals-so-section">
	<div class="sitevitals-so-section-header">
		<h2 class="sitevitals-so-section-title">
			<span class="dashicons dashicons-art"></span>
			<?php esc_html_e( 'Critical CSS', 'sitevitals-speed-optimizer-pro' ); ?>
		</h2>
	</div>

	<div class="sitevitals-so-settings-grid">
		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_critical_css_enabled"><?php esc_html_e( 'Enable Critical CSS', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Inline above-the-fold CSS and defer full stylesheets.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<label class="sitevitals-so-toggle">
					<input type="checkbox" name="sitevitals_so_pro_critical_css_enabled" id="sitevitals_so_pro_critical_css_enabled" value="1" <?php checked( get_option( 'sitevitals_so_pro_critical_css_enabled', false ) ); ?> />
					<span class="sitevitals-so-toggle-slider"></span>
				</label>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_critical_css_auto"><?php esc_html_e( 'Auto-Generate', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Automatically generate critical CSS for new pages.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<label class="sitevitals-so-toggle">
					<input type="checkbox" name="sitevitals_so_pro_critical_css_auto" id="sitevitals_so_pro_critical_css_auto" value="1" <?php checked( get_option( 'sitevitals_so_pro_critical_css_auto', false ) ); ?> />
					<span class="sitevitals-so-toggle-slider"></span>
				</label>
			</div>
		</div>
	</div>
</div>

<!-- Unused CSS Settings -->
<div class="sitevitals-so-section">
	<div class="sitevitals-so-section-header">
		<h2 class="sitevitals-so-section-title">
			<span class="dashicons dashicons-editor-strikethrough"></span>
			<?php esc_html_e( 'Unused CSS Removal', 'sitevitals-speed-optimizer-pro' ); ?>
		</h2>
	</div>

	<div class="sitevitals-so-settings-grid">
		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_unused_css_enabled"><?php esc_html_e( 'Enable Unused CSS Removal', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Remove unused CSS rules to reduce file sizes.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<label class="sitevitals-so-toggle">
					<input type="checkbox" name="sitevitals_so_pro_unused_css_enabled" id="sitevitals_so_pro_unused_css_enabled" value="1" <?php checked( get_option( 'sitevitals_so_pro_unused_css_enabled', false ) ); ?> />
					<span class="sitevitals-so-toggle-slider"></span>
				</label>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_unused_css_exclusions"><?php esc_html_e( 'Exclusions', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Stylesheet handles or URL fragments to exclude (one per line).', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<textarea name="sitevitals_so_pro_unused_css_exclusions" id="sitevitals_so_pro_unused_css_exclusions" rows="4" style="min-width:320px;"><?php echo esc_textarea( get_option( 'sitevitals_so_pro_unused_css_exclusions', '' ) ); ?></textarea>
			</div>
		</div>
	</div>
</div>

<!-- Image Converter Settings -->
<div class="sitevitals-so-section">
	<div class="sitevitals-so-section-header">
		<h2 class="sitevitals-so-section-title">
			<span class="dashicons dashicons-format-image"></span>
			<?php esc_html_e( 'Image Conversion', 'sitevitals-speed-optimizer-pro' ); ?>
		</h2>
	</div>

	<div class="sitevitals-so-settings-grid">
		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_image_convert_enabled"><?php esc_html_e( 'Enable Image Conversion', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Convert uploaded images to modern formats.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<label class="sitevitals-so-toggle">
					<input type="checkbox" name="sitevitals_so_pro_image_convert_enabled" id="sitevitals_so_pro_image_convert_enabled" value="1" <?php checked( get_option( 'sitevitals_so_pro_image_convert_enabled', false ) ); ?> />
					<span class="sitevitals-so-toggle-slider"></span>
				</label>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_image_format"><?php esc_html_e( 'Format', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Target image format for conversion.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<select name="sitevitals_so_pro_image_format" id="sitevitals_so_pro_image_format">
					<option value="webp" <?php selected( get_option( 'sitevitals_so_pro_image_format', 'webp' ), 'webp' ); ?>>WebP</option>
					<option value="avif" <?php selected( get_option( 'sitevitals_so_pro_image_format', 'webp' ), 'avif' ); ?>>AVIF</option>
				</select>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_image_quality"><?php esc_html_e( 'Quality', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Image quality level (1-100). Lower means smaller files.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<input type="number" name="sitevitals_so_pro_image_quality" id="sitevitals_so_pro_image_quality" value="<?php echo esc_attr( get_option( 'sitevitals_so_pro_image_quality', 82 ) ); ?>" min="1" max="100" style="min-width:100px;" />
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_image_max_width"><?php esc_html_e( 'Max Width', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Maximum image width in pixels. Larger images are resized.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<input type="number" name="sitevitals_so_pro_image_max_width" id="sitevitals_so_pro_image_max_width" value="<?php echo esc_attr( get_option( 'sitevitals_so_pro_image_max_width', 2560 ) ); ?>" min="100" max="10000" style="min-width:100px;" />
				<span style="color:#64748b;font-size:13px;">px</span>
			</div>
		</div>
	</div>
</div>

<!-- Scheduled DB Cleanup Settings -->
<div class="sitevitals-so-section">
	<div class="sitevitals-so-section-header">
		<h2 class="sitevitals-so-section-title">
			<span class="dashicons dashicons-database"></span>
			<?php esc_html_e( 'Scheduled Database Cleanup', 'sitevitals-speed-optimizer-pro' ); ?>
		</h2>
	</div>

	<div class="sitevitals-so-settings-grid">
		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_scheduled_db_enabled"><?php esc_html_e( 'Enable Scheduled Cleanup', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Automatically clean database on a schedule.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<label class="sitevitals-so-toggle">
					<input type="checkbox" name="sitevitals_so_pro_scheduled_db_enabled" id="sitevitals_so_pro_scheduled_db_enabled" value="1" <?php checked( get_option( 'sitevitals_so_pro_scheduled_db_enabled', false ) ); ?> />
					<span class="sitevitals-so-toggle-slider"></span>
				</label>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_scheduled_db_frequency"><?php esc_html_e( 'Frequency', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'How often to run the database cleanup.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<select name="sitevitals_so_pro_scheduled_db_frequency" id="sitevitals_so_pro_scheduled_db_frequency">
					<option value="daily" <?php selected( get_option( 'sitevitals_so_pro_scheduled_db_frequency', 'weekly' ), 'daily' ); ?>><?php esc_html_e( 'Daily', 'sitevitals-speed-optimizer-pro' ); ?></option>
					<option value="weekly" <?php selected( get_option( 'sitevitals_so_pro_scheduled_db_frequency', 'weekly' ), 'weekly' ); ?>><?php esc_html_e( 'Weekly', 'sitevitals-speed-optimizer-pro' ); ?></option>
					<option value="monthly" <?php selected( get_option( 'sitevitals_so_pro_scheduled_db_frequency', 'weekly' ), 'monthly' ); ?>><?php esc_html_e( 'Monthly', 'sitevitals-speed-optimizer-pro' ); ?></option>
				</select>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_scheduled_db_email"><?php esc_html_e( 'Email Notification', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Send an email summary after each cleanup.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<label class="sitevitals-so-toggle">
					<input type="checkbox" name="sitevitals_so_pro_scheduled_db_email" id="sitevitals_so_pro_scheduled_db_email" value="1" <?php checked( get_option( 'sitevitals_so_pro_scheduled_db_email', false ) ); ?> />
					<span class="sitevitals-so-toggle-slider"></span>
				</label>
			</div>
		</div>
	</div>
</div>

<!-- Advanced JS Delay Settings -->
<div class="sitevitals-so-section">
	<div class="sitevitals-so-section-header">
		<h2 class="sitevitals-so-section-title">
			<span class="dashicons dashicons-editor-code"></span>
			<?php esc_html_e( 'Advanced JavaScript Delay', 'sitevitals-speed-optimizer-pro' ); ?>
		</h2>
	</div>

	<div class="sitevitals-so-settings-grid">
		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_delay_js_enabled"><?php esc_html_e( 'Enable JS Delay', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Delay JavaScript execution until user interaction.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<label class="sitevitals-so-toggle">
					<input type="checkbox" name="sitevitals_so_pro_delay_js_enabled" id="sitevitals_so_pro_delay_js_enabled" value="1" <?php checked( get_option( 'sitevitals_so_pro_delay_js_enabled', false ) ); ?> />
					<span class="sitevitals-so-toggle-slider"></span>
				</label>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_delay_js_list"><?php esc_html_e( 'Delay List', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Scripts to delay (one per line). Leave empty to delay all non-excluded scripts.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<textarea name="sitevitals_so_pro_delay_js_list" id="sitevitals_so_pro_delay_js_list" rows="4" style="min-width:320px;" placeholder="<?php esc_attr_e( "google-analytics\nfacebook\ngtag", 'sitevitals-speed-optimizer-pro' ); ?>"><?php echo esc_textarea( get_option( 'sitevitals_so_pro_delay_js_list', '' ) ); ?></textarea>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_delay_js_excludes"><?php esc_html_e( 'Exclude List', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Scripts that should never be delayed (one per line). jQuery is always excluded.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<textarea name="sitevitals_so_pro_delay_js_excludes" id="sitevitals_so_pro_delay_js_excludes" rows="4" style="min-width:320px;"><?php echo esc_textarea( get_option( 'sitevitals_so_pro_delay_js_excludes', '' ) ); ?></textarea>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_delay_js_timeout"><?php esc_html_e( 'Timeout (ms)', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Auto-load delayed scripts after this time (0 = wait for interaction only).', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<input type="number" name="sitevitals_so_pro_delay_js_timeout" id="sitevitals_so_pro_delay_js_timeout" value="<?php echo esc_attr( get_option( 'sitevitals_so_pro_delay_js_timeout', 0 ) ); ?>" min="0" max="30000" style="min-width:100px;" />
				<span style="color:#64748b;font-size:13px;">ms</span>
			</div>
		</div>
	</div>
</div>

<!-- Preload & Prefetch Settings -->
<div class="sitevitals-so-section">
	<div class="sitevitals-so-section-header">
		<h2 class="sitevitals-so-section-title">
			<span class="dashicons dashicons-performance"></span>
			<?php esc_html_e( 'Preload & Prefetch', 'sitevitals-speed-optimizer-pro' ); ?>
		</h2>
	</div>

	<div class="sitevitals-so-settings-grid">
		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_preload_enabled"><?php esc_html_e( 'Enable Preloading', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Add preload, prefetch, and preconnect hints.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<label class="sitevitals-so-toggle">
					<input type="checkbox" name="sitevitals_so_pro_preload_enabled" id="sitevitals_so_pro_preload_enabled" value="1" <?php checked( get_option( 'sitevitals_so_pro_preload_enabled', false ) ); ?> />
					<span class="sitevitals-so-toggle-slider"></span>
				</label>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_preload_fonts_auto"><?php esc_html_e( 'Auto-Preload Fonts', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Auto-detect and preload Google Fonts and theme fonts.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<label class="sitevitals-so-toggle">
					<input type="checkbox" name="sitevitals_so_pro_preload_fonts_auto" id="sitevitals_so_pro_preload_fonts_auto" value="1" <?php checked( get_option( 'sitevitals_so_pro_preload_fonts_auto', true ) ); ?> />
					<span class="sitevitals-so-toggle-slider"></span>
				</label>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_preload_rules"><?php esc_html_e( 'Preload Rules', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'URLs to preload (one per line). Optionally add |type (font, style, script, image).', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<textarea name="sitevitals_so_pro_preload_rules" id="sitevitals_so_pro_preload_rules" rows="4" style="min-width:320px;" placeholder="<?php esc_attr_e( "/wp-content/themes/my-theme/fonts/main.woff2|font\n/wp-content/themes/my-theme/style.css|style", 'sitevitals-speed-optimizer-pro' ); ?>"><?php echo esc_textarea( get_option( 'sitevitals_so_pro_preload_rules', '' ) ); ?></textarea>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_dns_prefetch_domains"><?php esc_html_e( 'DNS Prefetch Domains', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'External domains for DNS prefetching (one per line).', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<textarea name="sitevitals_so_pro_dns_prefetch_domains" id="sitevitals_so_pro_dns_prefetch_domains" rows="3" style="min-width:320px;" placeholder="<?php esc_attr_e( "//cdn.example.com\n//www.google-analytics.com", 'sitevitals-speed-optimizer-pro' ); ?>"><?php echo esc_textarea( get_option( 'sitevitals_so_pro_dns_prefetch_domains', '' ) ); ?></textarea>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_preconnect_domains"><?php esc_html_e( 'Preconnect Domains', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Domains for early connection (one per line).', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<textarea name="sitevitals_so_pro_preconnect_domains" id="sitevitals_so_pro_preconnect_domains" rows="3" style="min-width:320px;"><?php echo esc_textarea( get_option( 'sitevitals_so_pro_preconnect_domains', '' ) ); ?></textarea>
			</div>
		</div>
	</div>
</div>

<!-- CDN Configuration -->
<div class="sitevitals-so-section">
	<div class="sitevitals-so-section-header">
		<h2 class="sitevitals-so-section-title">
			<span class="dashicons dashicons-cloud"></span>
			<?php esc_html_e( 'CDN Configuration', 'sitevitals-speed-optimizer-pro' ); ?>
		</h2>
	</div>

	<div class="sitevitals-so-settings-grid">
		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_cdn_enabled"><?php esc_html_e( 'Enable CDN', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Rewrite static asset URLs to use your CDN.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<label class="sitevitals-so-toggle">
					<input type="checkbox" name="sitevitals_so_pro_cdn_enabled" id="sitevitals_so_pro_cdn_enabled" value="1" <?php checked( get_option( 'sitevitals_so_pro_cdn_enabled', false ) ); ?> />
					<span class="sitevitals-so-toggle-slider"></span>
				</label>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_cdn_url"><?php esc_html_e( 'CDN URL', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Your CDN domain (e.g., https://cdn.example.com).', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<input type="text" name="sitevitals_so_pro_cdn_url" id="sitevitals_so_pro_cdn_url" value="<?php echo esc_attr( get_option( 'sitevitals_so_pro_cdn_url', '' ) ); ?>" placeholder="https://cdn.example.com" style="min-width:320px;" />
				<button type="button" class="sitevitals-so-btn sitevitals-so-btn-secondary" id="sv-so-pro-test-cdn">
					<?php esc_html_e( 'Test', 'sitevitals-speed-optimizer-pro' ); ?>
				</button>
				<span id="sv-so-pro-cdn-status" class="sitevitals-so-inline-status"></span>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_cdn_directories"><?php esc_html_e( 'Included Directories', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Directories to serve via CDN (one per line).', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<textarea name="sitevitals_so_pro_cdn_directories" id="sitevitals_so_pro_cdn_directories" rows="4" style="min-width:320px;"><?php echo esc_textarea( get_option( 'sitevitals_so_pro_cdn_directories', "wp-content/uploads\nwp-content/themes\nwp-content/plugins\nwp-includes" ) ); ?></textarea>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_cdn_excluded_extensions"><?php esc_html_e( 'Excluded File Types', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'File extensions to exclude from CDN (one per line).', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<textarea name="sitevitals_so_pro_cdn_excluded_extensions" id="sitevitals_so_pro_cdn_excluded_extensions" rows="3" style="min-width:320px;"><?php echo esc_textarea( get_option( 'sitevitals_so_pro_cdn_excluded_extensions', "php\nxml\nxsl" ) ); ?></textarea>
			</div>
		</div>
	</div>
</div>

<!-- Notifications Settings -->
<div class="sitevitals-so-section">
	<div class="sitevitals-so-section-header">
		<h2 class="sitevitals-so-section-title">
			<span class="dashicons dashicons-bell"></span>
			<?php esc_html_e( 'Notifications & Alerts', 'sitevitals-speed-optimizer-pro' ); ?>
		</h2>
	</div>

	<div class="sitevitals-so-settings-grid">
		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_slack_webhook"><?php esc_html_e( 'Slack Webhook URL', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Receive alerts in your Slack channel.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<input type="text" name="sitevitals_so_pro_slack_webhook" id="sitevitals_so_pro_slack_webhook" value="<?php echo esc_attr( get_option( 'sitevitals_so_pro_slack_webhook', '' ) ); ?>" placeholder="https://hooks.slack.com/services/..." style="min-width:320px;" />
				<button type="button" class="sitevitals-so-btn sitevitals-so-btn-secondary" id="sv-so-pro-test-slack">
					<?php esc_html_e( 'Test', 'sitevitals-speed-optimizer-pro' ); ?>
				</button>
				<span id="sv-so-pro-slack-status" class="sitevitals-so-inline-status"></span>
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_alert_email"><?php esc_html_e( 'Alert Email', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Receives critical performance alerts.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<input type="email" name="sitevitals_so_pro_alert_email" id="sitevitals_so_pro_alert_email" value="<?php echo esc_attr( get_option( 'sitevitals_so_pro_alert_email', '' ) ); ?>" placeholder="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>" />
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_alert_threshold"><?php esc_html_e( 'Alert Threshold', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Send alerts when score drops below this.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<input type="number" name="sitevitals_so_pro_alert_threshold" id="sitevitals_so_pro_alert_threshold" value="<?php echo esc_attr( get_option( 'sitevitals_so_pro_alert_threshold', 50 ) ); ?>" min="0" max="100" style="min-width:100px;" />
				<span style="color:#64748b;font-size:13px;">/100</span>
			</div>
		</div>
	</div>
</div>

<!-- White-Label Settings -->
<div class="sitevitals-so-section">
	<div class="sitevitals-so-section-header">
		<h2 class="sitevitals-so-section-title">
			<span class="dashicons dashicons-art"></span>
			<?php esc_html_e( 'White-Label / Agency Branding', 'sitevitals-speed-optimizer-pro' ); ?>
		</h2>
	</div>

	<div class="sitevitals-so-settings-grid">
		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_agency_name"><?php esc_html_e( 'Agency Name', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Replaces "SiteVitals" in exported reports.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<input type="text" name="sitevitals_so_pro_agency_name" id="sitevitals_so_pro_agency_name" value="<?php echo esc_attr( get_option( 'sitevitals_so_pro_agency_name', '' ) ); ?>" placeholder="<?php esc_attr_e( 'Your Agency Name', 'sitevitals-speed-optimizer-pro' ); ?>" />
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_agency_logo"><?php esc_html_e( 'Agency Logo URL', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Full URL to your logo image.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<input type="text" name="sitevitals_so_pro_agency_logo" id="sitevitals_so_pro_agency_logo" value="<?php echo esc_attr( get_option( 'sitevitals_so_pro_agency_logo', '' ) ); ?>" placeholder="https://yoursite.com/logo.png" style="min-width:320px;" />
			</div>
		</div>

		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_agency_color"><?php esc_html_e( 'Brand Color', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'Primary color in exported reports.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<input type="color" name="sitevitals_so_pro_agency_color" id="sitevitals_so_pro_agency_color" value="<?php echo esc_attr( get_option( 'sitevitals_so_pro_agency_color', '#6366f1' ) ); ?>" style="width:50px;height:36px;padding:2px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:6px;cursor:pointer;" />
				<span style="color:#94a3b8;font-size:13px;">
					<?php echo esc_html( get_option( 'sitevitals_so_pro_agency_color', '#6366f1' ) ); ?>
				</span>
			</div>
		</div>
	</div>
</div>

<!-- Performance History Retention -->
<div class="sitevitals-so-section">
	<div class="sitevitals-so-section-header">
		<h2 class="sitevitals-so-section-title">
			<span class="dashicons dashicons-chart-line"></span>
			<?php esc_html_e( 'Performance History', 'sitevitals-speed-optimizer-pro' ); ?>
		</h2>
	</div>

	<div class="sitevitals-so-settings-grid">
		<div class="sitevitals-so-setting-row">
			<div class="sitevitals-so-setting-label">
				<label for="sitevitals_so_pro_history_retention"><?php esc_html_e( 'Retention Period', 'sitevitals-speed-optimizer-pro' ); ?></label>
				<span class="sitevitals-so-setting-desc"><?php esc_html_e( 'How many days of history to keep.', 'sitevitals-speed-optimizer-pro' ); ?></span>
			</div>
			<div class="sitevitals-so-setting-input">
				<select name="sitevitals_so_pro_history_retention" id="sitevitals_so_pro_history_retention">
					<option value="30" <?php selected( get_option( 'sitevitals_so_pro_history_retention', 90 ), 30 ); ?>><?php esc_html_e( '30 days', 'sitevitals-speed-optimizer-pro' ); ?></option>
					<option value="60" <?php selected( get_option( 'sitevitals_so_pro_history_retention', 90 ), 60 ); ?>><?php esc_html_e( '60 days', 'sitevitals-speed-optimizer-pro' ); ?></option>
					<option value="90" <?php selected( get_option( 'sitevitals_so_pro_history_retention', 90 ), 90 ); ?>><?php esc_html_e( '90 days', 'sitevitals-speed-optimizer-pro' ); ?></option>
				</select>
			</div>
		</div>
	</div>
</div>

<script>
jQuery(function($) {
	// Test Slack.
	$('#sv-so-pro-test-slack').on('click', function() {
		var $status = $('#sv-so-pro-slack-status');
		var sitevitals_so_pro_webhook_url = $('#sitevitals_so_pro_slack_webhook').val();
		if (!sitevitals_so_pro_webhook_url) {
			$status.text('Enter a webhook URL first').css('color', '#f87171');
			return;
		}
		$status.text('Sending...').css('color', '#94a3b8');
		$.post(sitevitals_so.ajax_url, {
			action: 'sitevitals_so_pro_test_slack',
			nonce: sitevitals_so.nonce
		}).done(function(r) {
			$status.text(r.success ? r.data : r.data).css('color', r.success ? '#4ade80' : '#f87171');
		});
	});

	// Test CDN.
	$('#sv-so-pro-test-cdn').on('click', function() {
		var $status = $('#sv-so-pro-cdn-status');
		var sitevitals_so_pro_cdn_url = $('#sitevitals_so_pro_cdn_url').val();
		if (!sitevitals_so_pro_cdn_url) {
			$status.text('Enter a CDN URL first').css('color', '#f87171');
			return;
		}
		$status.text('Testing...').css('color', '#94a3b8');
		$.post(sitevitals_so.ajax_url, {
			action: 'sitevitals_so_pro_test_cdn',
			nonce: sitevitals_so.nonce
		}).done(function(r) {
			$status.text(r.success ? r.data : r.data).css('color', r.success ? '#4ade80' : '#f87171');
		});
	});
});
</script>
