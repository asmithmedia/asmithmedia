<?php
/**
 * Pro Activation / Onboarding template.
 *
 * Flow: Welcome → Enter License → Validate → Scan → Dashboard
 *
 * @package SiteVitals_Health_Monitor_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<style>
	/* Dark background for this page */
	.admin_page_sitevitals-pro-activate #wpcontent { background: #0b0f19; }
	.admin_page_sitevitals-pro-activate #wpbody-content { padding-bottom: 40px; }
</style>

<div class="wrap sitevitals-wrap">
	<div class="sitevitals-firstrun" id="sv-pro-onboard">

		<!-- Phase 1: Welcome + License Key Entry -->
		<div id="sv-pro-phase-license">
			<div class="sitevitals-firstrun-header">
				<div class="sitevitals-firstrun-logo">
					<div class="sitevitals-firstrun-logo-ring" style="background: linear-gradient(135deg, #f59e0b 0%, #f97316 100%);"></div>
					<span class="dashicons dashicons-star-filled"></span>
				</div>
				<h1>Site<span>Vitals</span> Pro</h1>
				<p class="sitevitals-firstrun-subtitle"><?php esc_html_e( 'Welcome to the Pro experience', 'sitevitals-health-monitor-pro' ); ?></p>
			</div>

			<!-- Features unlocked -->
			<div class="sv-pro-unlock-grid">
				<div class="sv-pro-unlock-item">
					<span class="sv-pro-unlock-icon">&#x1f504;</span>
					<span><?php esc_html_e( 'Auto-Rollback', 'sitevitals-health-monitor-pro' ); ?></span>
				</div>
				<div class="sv-pro-unlock-item">
					<span class="sv-pro-unlock-icon">&#x1f4ca;</span>
					<span><?php esc_html_e( 'Performance History', 'sitevitals-health-monitor-pro' ); ?></span>
				</div>
				<div class="sv-pro-unlock-item">
					<span class="sv-pro-unlock-icon">&#x1f50d;</span>
					<span><?php esc_html_e( 'Real-Time Monitor', 'sitevitals-health-monitor-pro' ); ?></span>
				</div>
				<div class="sv-pro-unlock-item">
					<span class="sv-pro-unlock-icon">&#x1f514;</span>
					<span><?php esc_html_e( 'Slack & Email Alerts', 'sitevitals-health-monitor-pro' ); ?></span>
				</div>
				<div class="sv-pro-unlock-item">
					<span class="sv-pro-unlock-icon">&#x1f3f7;</span>
					<span><?php esc_html_e( 'White-Label Reports', 'sitevitals-health-monitor-pro' ); ?></span>
				</div>
				<div class="sv-pro-unlock-item">
					<span class="sv-pro-unlock-icon">&#x1f4c4;</span>
					<span><?php esc_html_e( 'PDF Export', 'sitevitals-health-monitor-pro' ); ?></span>
				</div>
			</div>

			<!-- License input -->
			<div class="sv-pro-license-box">
				<label for="sv-pro-license-input"><?php esc_html_e( 'Enter your license key to activate Pro features', 'sitevitals-health-monitor-pro' ); ?></label>
				<div class="sv-pro-license-input-wrap">
					<input type="text"
						id="sv-pro-license-input"
						placeholder="<?php esc_attr_e( 'Paste your license key here...', 'sitevitals-health-monitor-pro' ); ?>"
						autocomplete="off"
						spellcheck="false" />
					<button type="button" class="sitevitals-btn sitevitals-btn-pro" id="sv-pro-activate-btn">
						<span class="dashicons dashicons-unlock"></span>
						<?php esc_html_e( 'Activate', 'sitevitals-health-monitor-pro' ); ?>
					</button>
				</div>
				<div class="sv-pro-license-status" id="sv-pro-license-status"></div>
				<p class="sv-pro-license-help">
					<?php esc_html_e( 'Your license key was emailed to you after purchase.', 'sitevitals-health-monitor-pro' ); ?>
					<a href="https://asmith.media/sitevitals/" target="_blank" rel="noopener"><?php esc_html_e( "Don't have a license?", 'sitevitals-health-monitor-pro' ); ?></a>
				</p>
			</div>
		</div>

		<!-- Phase 2: Activating + Scanning (shown after valid license) -->
		<div id="sv-pro-phase-scanning" style="display:none;">
			<div class="sitevitals-firstrun-header">
				<div class="sitevitals-firstrun-logo">
					<div class="sitevitals-firstrun-logo-ring" style="background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);"></div>
					<span class="dashicons dashicons-yes"></span>
				</div>
				<h1><?php esc_html_e( 'License Activated!', 'sitevitals-health-monitor-pro' ); ?></h1>
				<p class="sitevitals-firstrun-subtitle"><?php esc_html_e( 'Setting up Pro features...', 'sitevitals-health-monitor-pro' ); ?></p>
			</div>

			<div class="sitevitals-firstrun-steps" id="sv-pro-steps">
				<div class="sitevitals-firstrun-step sitevitals-step--active" data-step="license" id="sv-pro-step-license">
					<div class="sitevitals-step-icon">
						<span class="sitevitals-step-spinner"></span>
						<span class="sitevitals-step-check dashicons dashicons-yes"></span>
					</div>
					<div class="sitevitals-step-content">
						<div class="sitevitals-step-title"><?php esc_html_e( 'Validating license', 'sitevitals-health-monitor-pro' ); ?></div>
						<div class="sitevitals-step-detail" id="sv-pro-detail-license">—</div>
					</div>
				</div>

				<div class="sitevitals-firstrun-step" data-step="features" id="sv-pro-step-features">
					<div class="sitevitals-step-icon">
						<span class="sitevitals-step-spinner"></span>
						<span class="sitevitals-step-check dashicons dashicons-yes"></span>
					</div>
					<div class="sitevitals-step-content">
						<div class="sitevitals-step-title"><?php esc_html_e( 'Enabling Pro features', 'sitevitals-health-monitor-pro' ); ?></div>
						<div class="sitevitals-step-detail" id="sv-pro-detail-features">—</div>
					</div>
				</div>

				<div class="sitevitals-firstrun-step" data-step="scan" id="sv-pro-step-scan">
					<div class="sitevitals-step-icon">
						<span class="sitevitals-step-spinner"></span>
						<span class="sitevitals-step-check dashicons dashicons-yes"></span>
					</div>
					<div class="sitevitals-step-content">
						<div class="sitevitals-step-title"><?php esc_html_e( 'Running health scan', 'sitevitals-health-monitor-pro' ); ?></div>
						<div class="sitevitals-step-detail" id="sv-pro-detail-scan">—</div>
					</div>
				</div>

				<div class="sitevitals-firstrun-step" data-step="done" id="sv-pro-step-done">
					<div class="sitevitals-step-icon">
						<span class="sitevitals-step-spinner"></span>
						<span class="sitevitals-step-check dashicons dashicons-yes"></span>
					</div>
					<div class="sitevitals-step-content">
						<div class="sitevitals-step-title"><?php esc_html_e( 'Preparing your Pro dashboard', 'sitevitals-health-monitor-pro' ); ?></div>
						<div class="sitevitals-step-detail" id="sv-pro-detail-done">—</div>
					</div>
				</div>
			</div>

			<div class="sitevitals-firstrun-progress">
				<div class="sitevitals-firstrun-progress-bar" id="sv-pro-progress-bar"></div>
			</div>
			<div class="sitevitals-firstrun-progress-text" id="sv-pro-progress-text">
				<?php esc_html_e( 'Activating Pro...', 'sitevitals-health-monitor-pro' ); ?>
			</div>
		</div>

	</div>
</div>

<style>
	/* Pro unlock feature grid */
	.sv-pro-unlock-grid {
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		gap: 10px;
		margin: 0 0 36px;
	}
	.sv-pro-unlock-item {
		display: flex;
		align-items: center;
		gap: 8px;
		padding: 12px 16px;
		background: rgba(255, 255, 255, 0.03);
		border: 1px solid rgba(255, 255, 255, 0.06);
		border-radius: 10px;
		font-size: 13px;
		color: #cbd5e1;
	}
	.sv-pro-unlock-icon {
		font-size: 18px;
	}

	/* License input box */
	.sv-pro-license-box {
		background: rgba(255, 255, 255, 0.03);
		border: 1px solid rgba(255, 255, 255, 0.08);
		border-radius: 14px;
		padding: 28px;
		text-align: center;
	}
	.sv-pro-license-box label {
		display: block;
		font-size: 15px;
		font-weight: 600;
		color: #e2e8f0;
		margin-bottom: 16px;
	}
	.sv-pro-license-input-wrap {
		display: flex;
		gap: 10px;
		margin-bottom: 12px;
	}
	.sv-pro-license-input-wrap input {
		flex: 1;
		background: rgba(255, 255, 255, 0.04);
		border: 1px solid rgba(255, 255, 255, 0.1);
		border-radius: 8px;
		padding: 12px 16px;
		color: #e2e8f0;
		font-size: 14px;
		font-family: 'SF Mono', 'Cascadia Code', monospace;
	}
	.sv-pro-license-input-wrap input:focus {
		border-color: #f59e0b;
		box-shadow: 0 0 0 2px rgba(245, 158, 11, 0.2);
		outline: none;
	}
	.sv-pro-license-input-wrap input::placeholder {
		color: #475569;
	}
	.sv-pro-license-status {
		min-height: 20px;
		font-size: 13px;
		margin-bottom: 8px;
	}
	.sv-pro-license-status.sv-status-error {
		color: #f87171;
	}
	.sv-pro-license-status.sv-status-success {
		color: #4ade80;
	}
	.sv-pro-license-help {
		font-size: 13px;
		color: #64748b;
		margin: 0;
	}
	.sv-pro-license-help a {
		color: #f59e0b;
		text-decoration: none;
	}
	.sv-pro-license-help a:hover {
		text-decoration: underline;
	}

	/* Shake animation for invalid key */
	@keyframes sv-shake {
		0%, 100% { transform: translateX(0); }
		20%, 60% { transform: translateX(-6px); }
		40%, 80% { transform: translateX(6px); }
	}
	.sv-shake {
		animation: sv-shake 0.4s ease;
	}

	@media (max-width: 600px) {
		.sv-pro-unlock-grid { grid-template-columns: 1fr 1fr; }
		.sv-pro-license-input-wrap { flex-direction: column; }
	}
</style>

<script>
(function($) {
	'use strict';

	var dashboardUrl = '<?php echo esc_url( admin_url( 'admin.php?page=sitevitals' ) ); ?>';

	// Activate button click.
	$('#sv-pro-activate-btn').on('click', function() {
		var key = $('#sv-pro-license-input').val().trim();
		var $status = $('#sv-pro-license-status');
		var $btn = $(this);

		if (!key) {
			$status.text('<?php echo esc_js( __( 'Please enter your license key.', 'sitevitals-health-monitor-pro' ) ); ?>').attr('class', 'sv-pro-license-status sv-status-error');
			$('#sv-pro-license-input').addClass('sv-shake');
			setTimeout(function() { $('#sv-pro-license-input').removeClass('sv-shake'); }, 500);
			return;
		}

		$btn.prop('disabled', true).text('<?php echo esc_js( __( 'Validating...', 'sitevitals-health-monitor-pro' ) ); ?>');
		$status.text('').attr('class', 'sv-pro-license-status');

		$.post(sitevitals.ajax_url, {
			action: 'sitevitals_activate_license',
			nonce: sitevitals.nonce,
			license_key: key
		}).done(function(response) {
			if (response.success) {
				$status.text('<?php echo esc_js( __( 'License valid!', 'sitevitals-health-monitor-pro' ) ); ?>').attr('class', 'sv-pro-license-status sv-status-success');
				setTimeout(function() {
					startProSetup();
				}, 800);
			} else {
				$status.text(response.data).attr('class', 'sv-pro-license-status sv-status-error');
				$('#sv-pro-license-input').addClass('sv-shake');
				setTimeout(function() { $('#sv-pro-license-input').removeClass('sv-shake'); }, 500);
				$btn.prop('disabled', false).html('<span class="dashicons dashicons-unlock"></span> <?php echo esc_js( __( 'Activate', 'sitevitals-health-monitor-pro' ) ); ?>');
			}
		}).fail(function() {
			$status.text('<?php echo esc_js( __( 'Connection error. Please try again.', 'sitevitals-health-monitor-pro' ) ); ?>').attr('class', 'sv-pro-license-status sv-status-error');
			$btn.prop('disabled', false).html('<span class="dashicons dashicons-unlock"></span> <?php echo esc_js( __( 'Activate', 'sitevitals-health-monitor-pro' ) ); ?>');
		});
	});

	// Enter key triggers activate.
	$('#sv-pro-license-input').on('keydown', function(e) {
		if (e.key === 'Enter') {
			e.preventDefault();
			$('#sv-pro-activate-btn').click();
		}
	});

	function updateProgress(percent, text) {
		$('#sv-pro-progress-bar').css('width', percent + '%');
		if (text) $('#sv-pro-progress-text').text(text);
	}

	function completeStep(step, detail) {
		$('#sv-pro-step-' + step).removeClass('sitevitals-step--active').addClass('sitevitals-step--done');
		$('#sv-pro-detail-' + step).text(detail);
	}

	function activateStep(step) {
		$('#sv-pro-step-' + step).addClass('sitevitals-step--active');
	}

	function startProSetup() {
		// Transition to scanning phase.
		$('#sv-pro-phase-license').fadeOut(400, function() {
			$('#sv-pro-phase-scanning').fadeIn(400);
		});

		// Step 1: License (already done).
		setTimeout(function() {
			updateProgress(20, '<?php echo esc_js( __( 'License validated...', 'sitevitals-health-monitor-pro' ) ); ?>');
			completeStep('license', '<?php echo esc_js( __( 'License activated', 'sitevitals-health-monitor-pro' ) ); ?>');
			activateStep('features');
		}, 1000);

		// Step 2: Enable features.
		setTimeout(function() {
			updateProgress(40, '<?php echo esc_js( __( 'Enabling auto-rollback, monitoring, alerts...', 'sitevitals-health-monitor-pro' ) ); ?>');
			completeStep('features', '<?php echo esc_js( __( '6 Pro features enabled', 'sitevitals-health-monitor-pro' ) ); ?>');
			activateStep('scan');
		}, 2500);

		// Step 3: Run scan.
		setTimeout(function() {
			updateProgress(50, '<?php echo esc_js( __( 'Running health scan with Pro engine...', 'sitevitals-health-monitor-pro' ) ); ?>');

			$.post(sitevitals.ajax_url, {
				action: 'sitevitals_run_scan',
				nonce: sitevitals.nonce
			}).done(function(response) {
				var count = response.data ? Object.keys(response.data).length : 0;
				updateProgress(75);
				completeStep('scan', count + ' <?php echo esc_js( __( 'plugins scanned', 'sitevitals-health-monitor-pro' ) ); ?>');
				activateStep('done');

				// Step 4: Generate report.
				updateProgress(80, '<?php echo esc_js( __( 'Building your Pro dashboard...', 'sitevitals-health-monitor-pro' ) ); ?>');

				$.post(sitevitals.ajax_url, {
					action: 'sitevitals_get_report',
					nonce: sitevitals.nonce
				}).done(function() {
					updateProgress(100, '<?php echo esc_js( __( 'All set! Redirecting to your dashboard...', 'sitevitals-health-monitor-pro' ) ); ?>');
					completeStep('done', '<?php echo esc_js( __( 'Dashboard ready', 'sitevitals-health-monitor-pro' ) ); ?>');

					setTimeout(function() {
						window.location.href = dashboardUrl;
					}, 1500);
				});
			}).fail(function() {
				updateProgress(100, '<?php echo esc_js( __( 'Setup complete. Redirecting...', 'sitevitals-health-monitor-pro' ) ); ?>');
				setTimeout(function() {
					window.location.href = dashboardUrl;
				}, 1500);
			});
		}, 3500);
	}

})(jQuery);
</script>
