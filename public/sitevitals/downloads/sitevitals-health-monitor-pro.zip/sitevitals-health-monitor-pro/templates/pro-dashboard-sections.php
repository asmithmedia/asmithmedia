<?php
/**
 * Pro Dashboard Sections - renders actual Pro feature panels.
 *
 * @package SiteVitals_Health_Monitor_Pro
 * @var array $report Health report data passed via do_action.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<!-- Pro Feature Grid: 3 panels side by side -->
<div class="sitevitals-pro-panels">

	<!-- Performance History Chart -->
	<div class="sitevitals-section sitevitals-pro-panel">
		<div class="sitevitals-section-header">
			<h2 class="sitevitals-section-title">
				<span class="dashicons dashicons-chart-line"></span>
				<?php esc_html_e( 'Performance History', 'sitevitals-health-monitor-pro' ); ?>
			</h2>
			<select id="sv-history-range" class="sv-pro-select">
				<option value="7"><?php esc_html_e( '7 days', 'sitevitals-health-monitor-pro' ); ?></option>
				<option value="30" selected><?php esc_html_e( '30 days', 'sitevitals-health-monitor-pro' ); ?></option>
				<option value="90"><?php esc_html_e( '90 days', 'sitevitals-health-monitor-pro' ); ?></option>
			</select>
		</div>
		<div class="sv-pro-chart-wrap">
			<canvas id="sv-history-chart" height="200"></canvas>
			<p class="sv-pro-chart-empty" id="sv-history-empty" style="display:none;">
				<?php esc_html_e( 'History data will appear after a few daily scans.', 'sitevitals-health-monitor-pro' ); ?>
			</p>
		</div>
	</div>

	<!-- Real-Time Monitor -->
	<div class="sitevitals-section sitevitals-pro-panel">
		<div class="sitevitals-section-header">
			<h2 class="sitevitals-section-title">
				<span class="dashicons dashicons-visibility"></span>
				<?php esc_html_e( 'Real-Time Monitor', 'sitevitals-health-monitor-pro' ); ?>
			</h2>
			<span class="sv-pro-live-dot"></span>
		</div>
		<div class="sv-pro-events" id="sv-realtime-events">
			<div class="sv-pro-event-empty">
				<span class="dashicons dashicons-yes-alt" style="color:#4ade80;"></span>
				<?php esc_html_e( 'All clear. No recent events.', 'sitevitals-health-monitor-pro' ); ?>
			</div>
		</div>
	</div>
</div>

<!-- Auto-Rollback Status + Export in a row -->
<div class="sitevitals-pro-panels">
	<!-- Auto-Rollback -->
	<div class="sitevitals-section sitevitals-pro-panel">
		<div class="sitevitals-section-header">
			<h2 class="sitevitals-section-title">
				<span class="dashicons dashicons-backup"></span>
				<?php esc_html_e( 'Auto-Rollback', 'sitevitals-health-monitor-pro' ); ?>
			</h2>
			<span class="sv-pro-status-badge sv-pro-status--active">
				<?php esc_html_e( 'Active', 'sitevitals-health-monitor-pro' ); ?>
			</span>
		</div>
		<?php
		$sitevitals_rollback_notices = get_option( 'sitevitals_pro_rollback_notices', array() );
		$sitevitals_recent_rollbacks = array_slice( array_reverse( $sitevitals_rollback_notices ), 0, 3 );
		?>
		<?php if ( ! empty( $sitevitals_recent_rollbacks ) ) : ?>
			<div class="sv-pro-rollback-log">
				<?php foreach ( $sitevitals_recent_rollbacks as $sitevitals_notice ) : ?>
					<div class="sv-pro-rollback-entry">
						<span class="dashicons dashicons-undo" style="color:#f59e0b;"></span>
						<div>
							<strong><?php echo esc_html( $sitevitals_notice['plugin'] ); ?></strong>
							<span class="sv-pro-rollback-time">
								<?php echo esc_html( human_time_diff( $sitevitals_notice['time'], current_time( 'timestamp' ) ) ); ?> <?php esc_html_e( 'ago', 'sitevitals-health-monitor-pro' ); ?>
							</span>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		<?php else : ?>
			<div class="sv-pro-rollback-clean">
				<span class="dashicons dashicons-shield-alt" style="color:#4ade80;font-size:32px;width:32px;height:32px;"></span>
				<p><?php esc_html_e( 'No rollbacks needed. All updates are safe.', 'sitevitals-health-monitor-pro' ); ?></p>
				<span style="color:#64748b;font-size:12px;"><?php esc_html_e( 'Plugin updates are monitored automatically.', 'sitevitals-health-monitor-pro' ); ?></span>
			</div>
		<?php endif; ?>
	</div>

	<!-- Export & Reports -->
	<div class="sitevitals-section sitevitals-pro-panel">
		<div class="sitevitals-section-header">
			<h2 class="sitevitals-section-title">
				<span class="dashicons dashicons-media-document"></span>
				<?php esc_html_e( 'Export Reports', 'sitevitals-health-monitor-pro' ); ?>
			</h2>
		</div>
		<div class="sv-pro-export-options">
			<button type="button" class="sitevitals-btn sitevitals-btn-secondary sv-pro-export-btn" id="sv-export-html">
				<span class="dashicons dashicons-media-code"></span>
				<?php esc_html_e( 'Export HTML', 'sitevitals-health-monitor-pro' ); ?>
			</button>
			<button type="button" class="sitevitals-btn sitevitals-btn-secondary sv-pro-export-btn" id="sv-export-pdf">
				<span class="dashicons dashicons-pdf"></span>
				<?php esc_html_e( 'Export PDF', 'sitevitals-health-monitor-pro' ); ?>
			</button>
		</div>
		<?php
		$sitevitals_branding = SiteVitals_White_Label::instance()->get_branding();
		if ( ! empty( $sitevitals_branding['name'] ) ) :
			?>
			<p class="sv-pro-brand-note">
				<?php
				printf(
					/* translators: %s: agency name */
					esc_html__( 'Branded as: %s', 'sitevitals-health-monitor-pro' ),
					'<strong>' . esc_html( $sitevitals_branding['name'] ) . '</strong>'
				);
				?>
			</p>
		<?php else : ?>
			<p class="sv-pro-brand-note">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=sitevitals-settings' ) ); ?>" style="color:#8b5cf6;text-decoration:underline;">
					<?php esc_html_e( 'Set your agency name in Settings to white-label reports.', 'sitevitals-health-monitor-pro' ); ?>
				</a>
			</p>
		<?php endif; ?>
	</div>
</div>

<!-- Pro-specific CSS -->
<style>
.sitevitals-pro-panels {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 16px;
	margin-bottom: 16px;
}
.sitevitals-pro-panel { margin-bottom: 0; }

.sv-pro-select {
	background: rgba(255,255,255,0.04);
	border: 1px solid rgba(255,255,255,0.1);
	color: #e2e8f0;
	border-radius: 6px;
	padding: 4px 8px;
	font-size: 12px;
}

.sv-pro-chart-wrap {
	min-height: 200px;
	display: flex;
	align-items: center;
	justify-content: center;
}
.sv-pro-chart-empty {
	color: #64748b;
	font-size: 13px;
	text-align: center;
}

/* Live dot */
.sv-pro-live-dot {
	width: 8px; height: 8px;
	background: #4ade80;
	border-radius: 50%;
	display: inline-block;
	animation: sv-blink 2s ease infinite;
}
@keyframes sv-blink {
	0%, 100% { opacity: 1; }
	50% { opacity: 0.3; }
}

/* Events list */
.sv-pro-events {
	max-height: 220px;
	overflow-y: auto;
}
.sv-pro-event-empty {
	display: flex;
	align-items: center;
	gap: 8px;
	padding: 24px;
	justify-content: center;
	color: #94a3b8;
	font-size: 14px;
}
.sv-pro-event-row {
	display: flex;
	align-items: flex-start;
	gap: 10px;
	padding: 10px 0;
	border-bottom: 1px solid rgba(255,255,255,0.04);
	font-size: 13px;
}
.sv-pro-event-row:last-child { border-bottom: none; }
.sv-pro-event-time {
	color: #475569;
	font-size: 11px;
	white-space: nowrap;
	flex-shrink: 0;
}
.sv-pro-event-msg { color: #cbd5e1; }
.sv-pro-event-critical { color: #f87171; }
.sv-pro-event-warning { color: #fbbf24; }

/* Status badge */
.sv-pro-status-badge {
	padding: 3px 10px;
	border-radius: 10px;
	font-size: 11px;
	font-weight: 700;
	text-transform: uppercase;
	letter-spacing: 0.5px;
}
.sv-pro-status--active {
	background: rgba(34,197,94,0.12);
	color: #4ade80;
}

/* Rollback log */
.sv-pro-rollback-log { }
.sv-pro-rollback-entry {
	display: flex;
	align-items: center;
	gap: 10px;
	padding: 10px 0;
	border-bottom: 1px solid rgba(255,255,255,0.04);
	font-size: 13px;
	color: #cbd5e1;
}
.sv-pro-rollback-entry:last-child { border-bottom: none; }
.sv-pro-rollback-time { color: #64748b; font-size: 11px; margin-left: 8px; }
.sv-pro-rollback-clean {
	text-align: center;
	padding: 20px;
}
.sv-pro-rollback-clean p { color: #cbd5e1; font-size: 14px; margin: 8px 0 4px; }

/* Export buttons */
.sv-pro-export-options {
	display: flex;
	gap: 10px;
	margin-bottom: 16px;
}
.sv-pro-export-btn { flex: 1; justify-content: center; }
.sv-pro-brand-note {
	color: #64748b;
	font-size: 12px;
	margin: 0;
}

@media (max-width: 768px) {
	.sitevitals-pro-panels { grid-template-columns: 1fr; }
}
</style>

<!-- Pro Dashboard JS -->
<script>
jQuery(function($) {
	'use strict';

	// Load Chart.js from CDN for performance history.
	var chartScript = document.createElement('script');
	chartScript.src = 'https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js';
	chartScript.onload = function() { loadHistoryChart(); };
	document.head.appendChild(chartScript);

	function loadHistoryChart(days) {
		days = days || 30;
		$.post(sitevitals.ajax_url, {
			action: 'sitevitals_perf_history',
			nonce: sitevitals.nonce,
			days: days
		}).done(function(r) {
			if (!r.success || !r.data.datasets || r.data.datasets.length === 0) {
				$('#sv-history-chart').hide();
				$('#sv-history-empty').show();
				return;
			}
			$('#sv-history-chart').show();
			$('#sv-history-empty').hide();

			var ctx = document.getElementById('sv-history-chart').getContext('2d');
			if (window.svHistoryChart) window.svHistoryChart.destroy();

			window.svHistoryChart = new Chart(ctx, {
				type: 'line',
				data: r.data,
				options: {
					responsive: true,
					maintainAspectRatio: false,
					plugins: { legend: { labels: { color: '#94a3b8', font: { size: 11 } } } },
					scales: {
						x: { ticks: { color: '#475569', font: { size: 10 } }, grid: { color: 'rgba(255,255,255,0.04)' } },
						y: { min: 0, max: 100, ticks: { color: '#475569' }, grid: { color: 'rgba(255,255,255,0.04)' } }
					}
				}
			});
		});
	}

	$('#sv-history-range').on('change', function() {
		loadHistoryChart($(this).val());
	});

	// Real-time event polling.
	function pollEvents() {
		$.post(sitevitals.ajax_url, {
			action: 'sitevitals_realtime_poll',
			nonce: sitevitals.nonce
		}).done(function(r) {
			if (!r.success || !r.data.events || r.data.events.length === 0) return;
			var $container = $('#sv-realtime-events');
			$container.empty();
			r.data.events.slice(0, 8).forEach(function(e) {
				var cls = e.severity === 'critical' ? 'sv-pro-event-critical' : (e.severity === 'warning' ? 'sv-pro-event-warning' : '');
				$container.append(
					'<div class="sv-pro-event-row">' +
					'<span class="sv-pro-event-time">' + (e.created_at || '').substr(11, 5) + '</span>' +
					'<span class="sv-pro-event-msg ' + cls + '">' + $('<span>').text(e.message).html() + '</span>' +
					'</div>'
				);
			});
		});
	}
	pollEvents();
	setInterval(pollEvents, 30000);

	// Export handlers.
	$('#sv-export-html').on('click', function() {
		var $btn = $(this);
		$btn.prop('disabled', true).text('Exporting...');
		$.post(sitevitals.ajax_url, {
			action: 'sitevitals_export_html',
			nonce: sitevitals.nonce
		}).done(function(r) {
			if (!r.success) { alert(r.data || 'Export failed.'); return; }
			var blob = new Blob([r.data.html], { type: 'text/html' });
			var a = document.createElement('a');
			a.href = URL.createObjectURL(blob);
			a.download = r.data.filename || 'sitevitals-report.html';
			a.click();
		}).always(function() {
			$btn.prop('disabled', false).html('<span class="dashicons dashicons-media-code"></span> Export HTML');
		});
	});

	$('#sv-export-pdf').on('click', function() {
		var $btn = $(this);
		$btn.prop('disabled', true).text('Generating...');
		$.post(sitevitals.ajax_url, {
			action: 'sitevitals_export_pdf',
			nonce: sitevitals.nonce
		}).done(function(r) {
			if (!r.success) { alert(r.data || 'Export failed.'); return; }
			var win = window.open('', '_blank');
			win.document.write(r.data.html);
			win.document.close();
			setTimeout(function() { win.print(); }, 500);
		}).always(function() {
			$btn.prop('disabled', false).html('<span class="dashicons dashicons-pdf"></span> Export PDF');
		});
	});

});
</script>
