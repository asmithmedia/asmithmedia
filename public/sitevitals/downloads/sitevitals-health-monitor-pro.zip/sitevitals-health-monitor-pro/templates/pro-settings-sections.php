<?php
/**
 * Pro Settings Sections - Slack, Alerts, White-Label.
 *
 * @package SiteVitals_Health_Monitor_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<!-- Notifications Settings -->
<div class="sitevitals-section">
	<div class="sitevitals-section-header">
		<h2 class="sitevitals-section-title">
			<span class="dashicons dashicons-bell"></span>
			<?php esc_html_e( 'Notifications & Alerts', 'sitevitals-health-monitor-pro' ); ?>
		</h2>
	</div>

	<div class="sitevitals-settings-grid">
		<div class="sitevitals-setting-row">
			<div class="sitevitals-setting-label">
				<label for="sitevitals_pro_slack_webhook"><?php esc_html_e( 'Slack Webhook URL', 'sitevitals-health-monitor-pro' ); ?></label>
				<span class="sitevitals-setting-desc"><?php esc_html_e( 'Receive alerts in your Slack channel. Create an Incoming Webhook in Slack.', 'sitevitals-health-monitor-pro' ); ?></span>
			</div>
			<div class="sitevitals-setting-input">
				<input type="text"
					name="sitevitals_pro_slack_webhook"
					id="sitevitals_pro_slack_webhook"
					value="<?php echo esc_attr( get_option( 'sitevitals_pro_slack_webhook', '' ) ); ?>"
					placeholder="https://hooks.slack.com/services/..." style="min-width:320px;" />
				<button type="button" class="sitevitals-btn sitevitals-btn-secondary" id="sv-test-slack">
					<?php esc_html_e( 'Test', 'sitevitals-health-monitor-pro' ); ?>
				</button>
				<span id="sv-slack-status" class="sitevitals-inline-status"></span>
			</div>
		</div>

		<div class="sitevitals-setting-row">
			<div class="sitevitals-setting-label">
				<label for="sitevitals_pro_alert_email"><?php esc_html_e( 'Alert Email', 'sitevitals-health-monitor-pro' ); ?></label>
				<span class="sitevitals-setting-desc"><?php esc_html_e( 'Separate from report emails. Gets critical alerts only.', 'sitevitals-health-monitor-pro' ); ?></span>
			</div>
			<div class="sitevitals-setting-input">
				<input type="email"
					name="sitevitals_pro_alert_email"
					id="sitevitals_pro_alert_email"
					value="<?php echo esc_attr( get_option( 'sitevitals_pro_alert_email', '' ) ); ?>"
					placeholder="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>" />
			</div>
		</div>

		<div class="sitevitals-setting-row">
			<div class="sitevitals-setting-label">
				<label for="sitevitals_pro_alert_threshold"><?php esc_html_e( 'Alert Threshold', 'sitevitals-health-monitor-pro' ); ?></label>
				<span class="sitevitals-setting-desc"><?php esc_html_e( 'Send alerts when a plugin scores below this.', 'sitevitals-health-monitor-pro' ); ?></span>
			</div>
			<div class="sitevitals-setting-input">
				<input type="number"
					name="sitevitals_pro_alert_threshold"
					id="sitevitals_pro_alert_threshold"
					value="<?php echo esc_attr( get_option( 'sitevitals_pro_alert_threshold', 50 ) ); ?>"
					min="0" max="100" style="min-width:100px;" />
				<span style="color:#64748b;font-size:13px;">/100</span>
			</div>
		</div>
	</div>
</div>

<!-- White-Label Settings -->
<div class="sitevitals-section">
	<div class="sitevitals-section-header">
		<h2 class="sitevitals-section-title">
			<span class="dashicons dashicons-art"></span>
			<?php esc_html_e( 'White-Label / Agency Branding', 'sitevitals-health-monitor-pro' ); ?>
		</h2>
	</div>

	<div class="sitevitals-settings-grid">
		<div class="sitevitals-setting-row">
			<div class="sitevitals-setting-label">
				<label for="sitevitals_pro_agency_name"><?php esc_html_e( 'Agency Name', 'sitevitals-health-monitor-pro' ); ?></label>
				<span class="sitevitals-setting-desc"><?php esc_html_e( 'Replaces "SiteVitals" in exported reports.', 'sitevitals-health-monitor-pro' ); ?></span>
			</div>
			<div class="sitevitals-setting-input">
				<input type="text"
					name="sitevitals_pro_agency_name"
					id="sitevitals_pro_agency_name"
					value="<?php echo esc_attr( get_option( 'sitevitals_pro_agency_name', '' ) ); ?>"
					placeholder="<?php esc_attr_e( 'Your Agency Name', 'sitevitals-health-monitor-pro' ); ?>" />
			</div>
		</div>

		<div class="sitevitals-setting-row">
			<div class="sitevitals-setting-label">
				<label for="sitevitals_pro_agency_logo"><?php esc_html_e( 'Agency Logo URL', 'sitevitals-health-monitor-pro' ); ?></label>
				<span class="sitevitals-setting-desc"><?php esc_html_e( 'Full URL to your logo image. Used in exported reports.', 'sitevitals-health-monitor-pro' ); ?></span>
			</div>
			<div class="sitevitals-setting-input">
				<input type="text"
					name="sitevitals_pro_agency_logo"
					id="sitevitals_pro_agency_logo"
					value="<?php echo esc_attr( get_option( 'sitevitals_pro_agency_logo', '' ) ); ?>"
					placeholder="https://yoursite.com/logo.png" style="min-width:320px;" />
			</div>
		</div>

		<div class="sitevitals-setting-row">
			<div class="sitevitals-setting-label">
				<label for="sitevitals_pro_agency_color"><?php esc_html_e( 'Brand Color', 'sitevitals-health-monitor-pro' ); ?></label>
				<span class="sitevitals-setting-desc"><?php esc_html_e( 'Primary color used in exported report headers.', 'sitevitals-health-monitor-pro' ); ?></span>
			</div>
			<div class="sitevitals-setting-input">
				<input type="color"
					name="sitevitals_pro_agency_color"
					id="sitevitals_pro_agency_color"
					value="<?php echo esc_attr( get_option( 'sitevitals_pro_agency_color', '#3b82f6' ) ); ?>"
					style="width:50px;height:36px;padding:2px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:6px;cursor:pointer;" />
				<span style="color:#94a3b8;font-size:13px;">
					<?php echo esc_html( get_option( 'sitevitals_pro_agency_color', '#3b82f6' ) ); ?>
				</span>
			</div>
		</div>
	</div>
</div>

<script>
jQuery(function($) {
	// Test Slack.
	$('#sv-test-slack').on('click', function() {
		var $status = $('#sv-slack-status');

		// Save the webhook URL first.
		var webhookUrl = $('#sitevitals_pro_slack_webhook').val();
		if (!webhookUrl) {
			$status.text('Enter a webhook URL first').css('color', '#f87171');
			return;
		}

		$status.text('Sending...').css('color', '#94a3b8');
		$.post(sitevitals.ajax_url, {
			action: 'sitevitals_test_slack',
			nonce: sitevitals.nonce
		}).done(function(r) {
			$status.text(r.success ? r.data : r.data).css('color', r.success ? '#4ade80' : '#f87171');
		});
	});
});
</script>
