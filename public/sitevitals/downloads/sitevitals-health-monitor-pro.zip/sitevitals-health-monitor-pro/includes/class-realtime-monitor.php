<?php
/**
 * Real-Time Monitor - live conflict and error monitoring dashboard.
 *
 * @package SiteVitals_Health_Monitor_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_Realtime_Monitor {

	private static $instance = null;

	const TABLE_NAME = 'sitevitals_events';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		register_activation_hook( SITEVITALS_PRO_FILE, array( $this, 'create_table' ) );
		add_action( 'wp_ajax_sitevitals_realtime_poll', array( $this, 'ajax_poll' ) );
		add_action( 'admin_bar_menu', array( $this, 'admin_bar_alerts' ), 100 );

		// Capture errors in real-time.
		add_action( 'shutdown', array( $this, 'capture_fatal_errors' ) );

		// Hook into the free plugin's scan completion.
		add_action( 'sitevitals_after_scan', array( $this, 'log_scan_event' ) );

		// Add real-time tab to dashboard.
		add_filter( 'sitevitals_dashboard_tabs', array( $this, 'add_realtime_tab' ) );
	}

	/**
	 * Create the events table.
	 */
	public function create_table() {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE_NAME;
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			event_type varchar(50) NOT NULL,
			severity varchar(20) NOT NULL DEFAULT 'info',
			plugin_slug varchar(200) DEFAULT NULL,
			message text NOT NULL,
			context longtext DEFAULT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY event_type (event_type),
			KEY severity (severity),
			KEY created_at (created_at)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/**
	 * Log an event.
	 *
	 * @param string $type    Event type.
	 * @param string $severity Severity (critical, warning, info).
	 * @param string $message Event message.
	 * @param string $plugin  Plugin slug (optional).
	 * @param array  $context Additional context (optional).
	 */
	public function log_event( $type, $severity, $message, $plugin = null, $context = array() ) {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE_NAME;

		$wpdb->insert( $table, array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			'event_type'  => sanitize_text_field( $type ),
			'severity'    => sanitize_text_field( $severity ),
			'plugin_slug' => $plugin ? sanitize_text_field( $plugin ) : null,
			'message'     => sanitize_text_field( $message ),
			'context'     => ! empty( $context ) ? wp_json_encode( $context ) : null,
			'created_at'  => current_time( 'mysql' ),
		), array( '%s', '%s', '%s', '%s', '%s', '%s' ) );

		// Prune old events (keep 30 days).
		$wpdb->query( $wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			"DELETE FROM {$table} WHERE created_at < %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS )
		) );
	}

	/**
	 * Capture fatal errors on shutdown.
	 */
	public function capture_fatal_errors() {
		$error = error_get_last();
		if ( ! $error || ! in_array( $error['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR ), true ) ) {
			return;
		}

		$plugin = null;
		if ( preg_match( '/wp-content\/plugins\/([^\/]+)/', $error['file'], $matches ) ) {
			$plugin = $matches[1];
		}

		$this->log_event(
			'php_fatal',
			'critical',
			$error['message'],
			$plugin,
			array(
				'file' => $error['file'],
				'line' => $error['line'],
				'type' => $error['type'],
			)
		);
	}

	/**
	 * Log a scan completion event.
	 *
	 * @param array $results Scan results.
	 */
	public function log_scan_event( $results ) {
		$critical = 0;
		foreach ( $results as $plugin ) {
			if ( isset( $plugin['health_score'] ) && $plugin['health_score'] < 50 ) {
				$critical++;
			}
		}

		$this->log_event(
			'scan_complete',
			$critical > 0 ? 'warning' : 'info',
			sprintf(
				/* translators: 1: total plugins, 2: critical count */
				__( 'Health scan completed: %1$d plugins scanned, %2$d critical issues.', 'sitevitals-health-monitor-pro' ),
				count( $results ),
				$critical
			)
		);
	}

	/**
	 * AJAX: Poll for recent events.
	 */
	public function ajax_poll() {
		check_ajax_referer( 'sitevitals_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}

		global $wpdb;
		$table = $wpdb->prefix . self::TABLE_NAME;

		$since = isset( $_POST['since'] ) ? sanitize_text_field( wp_unslash( $_POST['since'] ) ) : '';
		if ( empty( $since ) ) {
			$since = gmdate( 'Y-m-d H:i:s', time() - HOUR_IN_SECONDS );
		}

		$events = $wpdb->get_results( $wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			"SELECT * FROM {$table} WHERE created_at > %s ORDER BY created_at DESC LIMIT 50", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$since
		), ARRAY_A );

		wp_send_json_success( array(
			'events'    => $events,
			'timestamp' => current_time( 'mysql' ),
		) );
	}

	/**
	 * Show alert count in admin bar.
	 *
	 * @param WP_Admin_Bar $wp_admin_bar Admin bar instance.
	 */
	public function admin_bar_alerts( $wp_admin_bar ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		global $wpdb;
		$table = $wpdb->prefix . self::TABLE_NAME;

		$critical_count = $wpdb->get_var( $wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			"SELECT COUNT(*) FROM {$table} WHERE severity = 'critical' AND created_at > %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS )
		) );

		if ( $critical_count > 0 ) {
			$wp_admin_bar->add_node( array(
				'id'    => 'sitevitals-alerts',
				'title' => '<span style="color:#ef4444;">' .
					sprintf(
						/* translators: %d: number of alerts */
						esc_html__( 'SiteVitals: %d alerts', 'sitevitals-health-monitor-pro' ),
						(int) $critical_count
					) .
					'</span>',
				'href'  => admin_url( 'admin.php?page=sitevitals' ),
			) );
		}
	}

	/**
	 * Add real-time tab to dashboard.
	 *
	 * @param array $tabs Existing tabs.
	 * @return array
	 */
	public function add_realtime_tab( $tabs ) {
		// Remove the placeholder Pro tab and add the real one.
		unset( $tabs['realtime'] );
		$tabs['realtime'] = array(
			'label'    => __( 'Real-Time Monitor', 'sitevitals-health-monitor-pro' ),
			'icon'     => 'dashicons-visibility',
			'pro_only' => false,
		);
		return $tabs;
	}
}
