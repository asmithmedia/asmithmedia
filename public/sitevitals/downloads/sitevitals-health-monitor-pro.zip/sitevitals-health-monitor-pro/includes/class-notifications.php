<?php
/**
 * Notifications - Slack webhook and advanced email alerts.
 *
 * @package SiteVitals_Health_Monitor_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_Notifications {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Listen for events that should trigger notifications.
		add_action( 'sitevitals_plugin_rolled_back', array( $this, 'notify_rollback' ), 10, 2 );
		add_action( 'sitevitals_after_scan', array( $this, 'notify_critical_issues' ) );

		// Settings.
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'wp_ajax_sitevitals_test_slack', array( $this, 'ajax_test_slack' ) );
	}

	/**
	 * Register notification settings.
	 */
	public function register_settings() {
		register_setting( 'sitevitals_settings', 'sitevitals_pro_slack_webhook', array(
			'type'              => 'string',
			'sanitize_callback' => 'esc_url_raw',
			'default'           => '',
		) );

		register_setting( 'sitevitals_settings', 'sitevitals_pro_alert_email', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_email',
			'default'           => '',
		) );

		register_setting( 'sitevitals_settings', 'sitevitals_pro_alert_threshold', array(
			'type'              => 'integer',
			'sanitize_callback' => 'absint',
			'default'           => 50,
		) );
	}

	/**
	 * Send a Slack notification.
	 *
	 * @param string $message Message text.
	 * @param string $color   Attachment color (hex).
	 * @return bool
	 */
	public function send_slack( $message, $color = '#ef4444' ) {
		$webhook_url = get_option( 'sitevitals_pro_slack_webhook', '' );
		if ( empty( $webhook_url ) ) {
			return false;
		}

		$payload = array(
			'username'    => 'SiteVitals',
			'icon_emoji'  => ':heart:',
			'attachments' => array(
				array(
					'color'  => $color,
					'text'   => $message,
					'footer' => get_bloginfo( 'name' ) . ' | ' . home_url(),
					'ts'     => time(),
				),
			),
		);

		$response = wp_remote_post( $webhook_url, array(
			'body'    => wp_json_encode( $payload ),
			'headers' => array( 'Content-Type' => 'application/json' ),
			'timeout' => 10,
		) );

		return ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response );
	}

	/**
	 * Send an alert email.
	 *
	 * @param string $subject Email subject.
	 * @param string $body    Pre-built HTML email body.
	 */
	public function send_alert_email( $subject, $body ) {
		$email = get_option( 'sitevitals_pro_alert_email', '' );
		if ( empty( $email ) ) {
			$email = get_option( 'admin_email' );
		}

		$headers = array( 'Content-Type: text/html; charset=UTF-8' );

		wp_mail( $email, '[SiteVitals] ' . $subject, $body, $headers );
	}

	/**
	 * Notify when a plugin is auto-rolled back.
	 *
	 * @param string $plugin_file Plugin that was rolled back.
	 * @param array  $conflicts   Detected conflicts.
	 */
	public function notify_rollback( $plugin_file, $conflicts ) {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$all_plugins = get_plugins();
		$name = isset( $all_plugins[ $plugin_file ] ) ? $all_plugins[ $plugin_file ]['Name'] : $plugin_file;

		$slack_msg = sprintf(
			/* translators: %s: plugin name */
			__( 'Plugin "%s" was automatically rolled back due to conflicts detected after update.', 'sitevitals-health-monitor-pro' ),
			$name
		);

		$this->send_slack( $slack_msg, '#f97316' );

		$body = $this->build_email_html(
			__( 'Auto-Rollback Alert', 'sitevitals-health-monitor-pro' ),
			sprintf(
				/* translators: %s: plugin name */
				__( '"%s" was automatically rolled back because conflicts were detected after updating.', 'sitevitals-health-monitor-pro' ),
				$name
			),
			'#f97316',
			array(
				array(
					'name'   => $name,
					'detail' => __( 'Rolled back to previous version', 'sitevitals-health-monitor-pro' ),
					'color'  => '#f97316',
				),
			)
		);

		$this->send_alert_email(
			/* translators: %s: plugin name */
			sprintf( __( 'Auto-Rollback: %s', 'sitevitals-health-monitor-pro' ), $name ),
			$body
		);
	}

	/**
	 * Notify when critical issues are found after a scan.
	 *
	 * @param array $results Scan results.
	 */
	public function notify_critical_issues( $results ) {
		$threshold = get_option( 'sitevitals_pro_alert_threshold', 50 );
		$critical  = array();

		foreach ( $results as $plugin ) {
			if ( isset( $plugin['health_score'] ) && $plugin['health_score'] < $threshold ) {
				$critical[] = array(
					'name'  => $plugin['name'] ?? __( 'Unknown', 'sitevitals-health-monitor-pro' ),
					'score' => $plugin['health_score'],
				);
			}
		}

		if ( empty( $critical ) ) {
			return;
		}

		// Slack: one batched message.
		$names = wp_list_pluck( $critical, 'name' );
		$slack_msg = sprintf(
			/* translators: 1: count, 2: comma-separated plugin names */
			__( '%1$d plugin(s) scored below %3$d: %2$s', 'sitevitals-health-monitor-pro' ),
			count( $critical ),
			implode( ', ', $names ),
			$threshold
		);
		$this->send_slack( $slack_msg, '#ef4444' );

		// Email: one beautiful batched email.
		$items = array();
		foreach ( $critical as $p ) {
			$items[] = array(
				'name'   => $p['name'],
				/* translators: %d: health score */
				'detail' => sprintf( __( 'Score: %d/100', 'sitevitals-health-monitor-pro' ), $p['score'] ),
				'color'  => $p['score'] < 25 ? '#ef4444' : '#f59e0b',
			);
		}

		$body = $this->build_email_html(
			__( 'Critical Health Alert', 'sitevitals-health-monitor-pro' ),
			sprintf(
				/* translators: 1: count, 2: threshold */
				_n(
					'%1$d plugin scored below your alert threshold of %2$d.',
					'%1$d plugins scored below your alert threshold of %2$d.',
					count( $critical ),
					'sitevitals-health-monitor-pro'
				),
				count( $critical ),
				$threshold
			),
			'#ef4444',
			$items
		);

		$this->send_alert_email(
			__( 'Critical Plugin Health Alert', 'sitevitals-health-monitor-pro' ),
			$body
		);
	}

	/**
	 * Build a styled HTML email matching the free version's report template.
	 *
	 * @param string $title       Email headline.
	 * @param string $summary     Summary paragraph text.
	 * @param string $accent      Accent color hex.
	 * @param array  $items       Array of items, each with 'name', 'detail', 'color'.
	 * @return string Full HTML email body.
	 */
	private function build_email_html( $title, $summary, $accent, $items = array() ) {
		$site_name = get_bloginfo( 'name' );
		$site_url  = home_url();
		$admin_url = admin_url( 'admin.php?page=sitevitals' );
		$date      = current_time( 'F j, Y \a\t g:i A' );

		ob_start();
		?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;background:#f3f4f6;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
	<table width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6;padding:32px 16px;">
		<tr>
			<td align="center">
				<table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
					<!-- Header -->
					<tr>
						<td style="background:#1e293b;padding:24px 32px;text-align:center;">
							<h1 style="color:#ffffff;margin:0;font-size:22px;">
								SiteVitals <span style="color:<?php echo esc_attr( $accent ); ?>;">Pro</span>
							</h1>
							<p style="color:#94a3b8;margin:8px 0 0;font-size:14px;">
								<?php echo esc_html( $site_name ); ?>
							</p>
						</td>
					</tr>

					<!-- Alert Badge -->
					<tr>
						<td style="padding:32px 32px 16px;text-align:center;">
							<div style="display:inline-block;width:64px;height:64px;border-radius:50%;background:<?php echo esc_attr( $accent ); ?>;line-height:64px;text-align:center;">
								<span style="color:#ffffff;font-size:28px;">&#x26A0;</span>
							</div>
							<h2 style="font-size:20px;color:#1e293b;margin:16px 0 8px;">
								<?php echo esc_html( $title ); ?>
							</h2>
							<p style="color:#6b7280;font-size:14px;margin:0;line-height:1.5;">
								<?php echo esc_html( $summary ); ?>
							</p>
							<p style="color:#9ca3af;font-size:12px;margin:8px 0 0;">
								<?php echo esc_html( $date ); ?>
							</p>
						</td>
					</tr>

					<?php if ( ! empty( $items ) ) : ?>
					<!-- Plugin List -->
					<tr>
						<td style="padding:0 32px 24px;">
							<h3 style="font-size:14px;color:#1e293b;margin:0 0 12px;text-transform:uppercase;letter-spacing:0.5px;">
								<?php esc_html_e( 'Affected Plugins', 'sitevitals-health-monitor-pro' ); ?>
							</h3>
							<?php foreach ( $items as $item ) : ?>
								<div style="padding:12px 16px;margin-bottom:8px;background:#f8fafc;border-left:4px solid <?php echo esc_attr( $item['color'] ); ?>;border-radius:0 6px 6px 0;">
									<strong style="color:#1e293b;font-size:14px;">
										<?php echo esc_html( $item['name'] ); ?>
									</strong>
									<p style="color:#6b7280;font-size:13px;margin:4px 0 0;">
										<?php echo esc_html( $item['detail'] ); ?>
									</p>
								</div>
							<?php endforeach; ?>
						</td>
					</tr>
					<?php endif; ?>

					<!-- CTA -->
					<tr>
						<td style="padding:0 32px 32px;text-align:center;">
							<a href="<?php echo esc_url( $admin_url ); ?>"
								style="display:inline-block;padding:12px 32px;background:<?php echo esc_attr( $accent ); ?>;color:#ffffff;text-decoration:none;border-radius:6px;font-weight:bold;font-size:14px;">
								<?php esc_html_e( 'View Dashboard', 'sitevitals-health-monitor-pro' ); ?>
							</a>
						</td>
					</tr>

					<!-- Footer -->
					<tr>
						<td style="padding:16px 32px;background:#f8fafc;text-align:center;border-top:1px solid #e5e7eb;">
							<p style="color:#9ca3af;font-size:12px;margin:0;">
								<?php
								printf(
									/* translators: %s: site URL */
									esc_html__( 'Sent by SiteVitals Health Monitor Pro from %s', 'sitevitals-health-monitor-pro' ),
									esc_html( $site_url )
								);
								?>
							</p>
							<p style="color:#9ca3af;font-size:12px;margin:4px 0 0;">
								<?php esc_html_e( 'Manage alert settings in SiteVitals > Settings.', 'sitevitals-health-monitor-pro' ); ?>
							</p>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>
		<?php
		return ob_get_clean();
	}

	/**
	 * AJAX: Test Slack webhook.
	 */
	public function ajax_test_slack() {
		check_ajax_referer( 'sitevitals_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}

		$result = $this->send_slack(
			__( 'Test notification from SiteVitals Health Monitor Pro.', 'sitevitals-health-monitor-pro' ),
			'#22c55e'
		);

		if ( $result ) {
			wp_send_json_success( __( 'Slack notification sent!', 'sitevitals-health-monitor-pro' ) );
		} else {
			wp_send_json_error( __( 'Failed to send. Check your webhook URL.', 'sitevitals-health-monitor-pro' ) );
		}
	}
}
