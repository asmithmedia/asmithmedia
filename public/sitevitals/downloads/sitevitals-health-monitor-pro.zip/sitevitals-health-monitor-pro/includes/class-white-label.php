<?php
/**
 * White Label - custom branding for agency reports and PDF export.
 *
 * @package SiteVitals_Health_Monitor_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_White_Label {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'wp_ajax_sitevitals_export_pdf', array( $this, 'ajax_export_pdf' ) );
		add_action( 'wp_ajax_sitevitals_export_html', array( $this, 'ajax_export_html' ) );
	}

	/**
	 * Register white-label settings.
	 */
	public function register_settings() {
		register_setting( 'sitevitals_settings', 'sitevitals_pro_agency_name', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		) );

		register_setting( 'sitevitals_settings', 'sitevitals_pro_agency_logo', array(
			'type'              => 'string',
			'sanitize_callback' => 'esc_url_raw',
			'default'           => '',
		) );

		register_setting( 'sitevitals_settings', 'sitevitals_pro_agency_color', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_hex_color',
			'default'           => '#3b82f6',
		) );
	}

	/**
	 * Get white-label branding settings.
	 *
	 * @return array
	 */
	public function get_branding() {
		return array(
			'name'  => get_option( 'sitevitals_pro_agency_name', '' ),
			'logo'  => get_option( 'sitevitals_pro_agency_logo', '' ),
			'color' => get_option( 'sitevitals_pro_agency_color', '#3b82f6' ),
		);
	}

	/**
	 * AJAX: Export report as downloadable HTML.
	 */
	public function ajax_export_html() {
		check_ajax_referer( 'sitevitals_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}

		$report   = SiteVitals_Health_Report::instance()->generate();
		$branding = $this->get_branding();
		$html     = $this->render_report_html( $report, $branding );

		wp_send_json_success( array(
			'html'     => $html,
			'filename' => sanitize_file_name(
				'sitevitals-report-' . gmdate( 'Y-m-d' ) . '.html'
			),
		) );
	}

	/**
	 * AJAX: Export report as PDF (via browser print).
	 */
	public function ajax_export_pdf() {
		check_ajax_referer( 'sitevitals_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}

		$report   = SiteVitals_Health_Report::instance()->generate();
		$branding = $this->get_branding();
		$html     = $this->render_report_html( $report, $branding );

		// Return HTML that can be opened in a new window and printed to PDF.
		wp_send_json_success( array(
			'html' => $html,
		) );
	}

	/**
	 * Render a standalone HTML report with white-label branding.
	 *
	 * @param array $report   Health report data.
	 * @param array $branding White-label branding settings.
	 * @return string
	 */
	private function render_report_html( $report, $branding ) {
		$agency_name  = ! empty( $branding['name'] ) ? $branding['name'] : 'SiteVitals';
		$agency_color = ! empty( $branding['color'] ) ? $branding['color'] : '#3b82f6';
		$agency_logo  = ! empty( $branding['logo'] ) ? $branding['logo'] : '';
		$site_name    = get_bloginfo( 'name' );
		$site_url     = home_url();
		$summary      = $report['summary'];
		$date         = current_time( 'F j, Y' );

		$grade_colors = array(
			'A' => '#22c55e', 'B' => '#84cc16', 'C' => '#eab308',
			'D' => '#f97316', 'F' => '#ef4444',
		);
		$grade_color = $grade_colors[ $summary['grade'] ] ?? '#6b7280';

		ob_start();
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="UTF-8">
			<title><?php echo esc_html( $agency_name ); ?> - <?php esc_html_e( 'Health Report', 'sitevitals-health-monitor-pro' ); ?> - <?php echo esc_html( $site_name ); ?></title>
			<style>
				body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #1e293b; max-width: 800px; margin: 0 auto; padding: 40px 20px; }
				.header { text-align: center; margin-bottom: 32px; border-bottom: 3px solid <?php echo esc_attr( $agency_color ); ?>; padding-bottom: 24px; }
				.header h1 { font-size: 28px; margin: 0; color: <?php echo esc_attr( $agency_color ); ?>; }
				.header p { color: #6b7280; margin: 4px 0; }
				.site-info { background: #f8fafc; border-radius: 8px; padding: 20px; margin-bottom: 30px; }
				.site-info-row { display: flex; justify-content: space-between; padding: 6px 0; }
				.site-info-label { font-size: 13px; color: #6b7280; text-transform: uppercase; font-weight: 600; letter-spacing: 0.3px; }
				.site-info-value { font-size: 14px; color: #1e293b; font-weight: 500; }
				.site-info-value a { color: <?php echo esc_attr( $agency_color ); ?>; text-decoration: none; }
				.score-section { text-align: center; margin: 30px 0; }
				.score-circle { display: inline-block; width: 100px; height: 100px; border-radius: 50%; background: <?php echo esc_attr( $grade_color ); ?>; line-height: 100px; text-align: center; }
				.score-circle span { color: #fff; font-size: 40px; font-weight: bold; }
				.stats { display: flex; justify-content: center; gap: 40px; margin: 20px 0; }
				.stat { text-align: center; }
				.stat-number { font-size: 28px; font-weight: bold; }
				.stat-label { font-size: 12px; color: #6b7280; text-transform: uppercase; }
				.critical .stat-number { color: #ef4444; }
				.warning .stat-number { color: #f59e0b; }
				.healthy .stat-number { color: #22c55e; }
				.section { margin: 30px 0; }
				.section h2 { font-size: 18px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; }
				table { width: 100%; border-collapse: collapse; margin: 16px 0; }
				th, td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #e2e8f0; }
				th { background: #f8fafc; font-size: 13px; color: #6b7280; text-transform: uppercase; }
				.badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: 600; }
				.badge-healthy { background: #dcfce7; color: #16a34a; }
				.badge-needs_attention { background: #fef3c7; color: #d97706; }
				.badge-critical { background: #fee2e2; color: #dc2626; }
				.footer { text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #e2e8f0; color: #9ca3af; font-size: 12px; }
				@media print { body { padding: 0; } .header { break-after: avoid; } }
			</style>
		</head>
		<body>
			<div class="header">
				<?php if ( $agency_logo ) : ?>
					<img src="<?php echo esc_url( $agency_logo ); ?>" alt="<?php echo esc_attr( $agency_name ); ?>" style="max-height:60px;margin-bottom:16px;" />
				<?php endif; ?>
				<h1><?php echo esc_html( $agency_name ); ?></h1>
				<p style="font-size:16px;color:#475569;margin:8px 0 4px;">
					<?php esc_html_e( 'Site Health Report', 'sitevitals-health-monitor-pro' ); ?>
				</p>
				<p><?php echo esc_html( $date ); ?></p>
			</div>

			<!-- Site / Client Info -->
			<div class="site-info">
				<div class="site-info-row">
					<span class="site-info-label"><?php esc_html_e( 'Site', 'sitevitals-health-monitor-pro' ); ?></span>
					<span class="site-info-value"><?php echo esc_html( $site_name ); ?></span>
				</div>
				<div class="site-info-row">
					<span class="site-info-label"><?php esc_html_e( 'URL', 'sitevitals-health-monitor-pro' ); ?></span>
					<span class="site-info-value"><a href="<?php echo esc_url( $site_url ); ?>"><?php echo esc_html( $site_url ); ?></a></span>
				</div>
				<div class="site-info-row">
					<span class="site-info-label"><?php esc_html_e( 'Report Date', 'sitevitals-health-monitor-pro' ); ?></span>
					<span class="site-info-value"><?php echo esc_html( $date ); ?></span>
				</div>
				<div class="site-info-row">
					<span class="site-info-label"><?php esc_html_e( 'Plugins Scanned', 'sitevitals-health-monitor-pro' ); ?></span>
					<span class="site-info-value"><?php echo esc_html( count( $report['plugins'] ) ); ?></span>
				</div>
				<?php if ( $agency_name !== 'SiteVitals' ) : ?>
					<div class="site-info-row">
						<span class="site-info-label"><?php esc_html_e( 'Prepared By', 'sitevitals-health-monitor-pro' ); ?></span>
						<span class="site-info-value"><?php echo esc_html( $agency_name ); ?></span>
					</div>
				<?php endif; ?>
			</div>

			<div class="score-section">
				<div class="score-circle"><span><?php echo esc_html( $summary['grade'] ); ?></span></div>
				<p style="font-size:24px;font-weight:bold;margin:12px 0 4px;"><?php echo esc_html( $summary['score'] ); ?>/100</p>
				<p style="color:#6b7280;font-size:14px;margin:0;"><?php esc_html_e( 'Overall Health Score', 'sitevitals-health-monitor-pro' ); ?></p>
			</div>

			<div class="stats">
				<div class="stat critical">
					<div class="stat-number"><?php echo esc_html( $summary['critical'] ); ?></div>
					<div class="stat-label"><?php esc_html_e( 'Critical', 'sitevitals-health-monitor-pro' ); ?></div>
				</div>
				<div class="stat warning">
					<div class="stat-number"><?php echo esc_html( $summary['warnings'] ); ?></div>
					<div class="stat-label"><?php esc_html_e( 'Warnings', 'sitevitals-health-monitor-pro' ); ?></div>
				</div>
				<div class="stat healthy">
					<div class="stat-number"><?php echo esc_html( $summary['healthy'] ); ?></div>
					<div class="stat-label"><?php esc_html_e( 'Healthy', 'sitevitals-health-monitor-pro' ); ?></div>
				</div>
			</div>

			<?php if ( ! empty( $report['recommendations'] ) ) : ?>
				<div class="section">
					<h2><?php esc_html_e( 'Recommendations', 'sitevitals-health-monitor-pro' ); ?></h2>
					<?php foreach ( $report['recommendations'] as $rec ) :
						$rec_color = 'high' === $rec['priority'] ? '#ef4444' : ( 'medium' === $rec['priority'] ? '#f59e0b' : '#6b7280' );
						?>
						<div style="padding:12px;margin-bottom:8px;background:#f8fafc;border-left:3px solid <?php echo esc_attr( $rec_color ); ?>;border-radius:0 4px 4px 0;">
							<strong style="color:#1e293b;font-size:14px;"><?php echo esc_html( $rec['title'] ); ?></strong>
							<p style="color:#6b7280;font-size:13px;margin:4px 0 0;"><?php echo esc_html( $rec['message'] ); ?></p>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<div class="section">
				<h2><?php esc_html_e( 'Plugin Details', 'sitevitals-health-monitor-pro' ); ?></h2>
				<table>
					<thead>
						<tr>
							<th><?php esc_html_e( 'Plugin', 'sitevitals-health-monitor-pro' ); ?></th>
							<th><?php esc_html_e( 'Version', 'sitevitals-health-monitor-pro' ); ?></th>
							<th><?php esc_html_e( 'Score', 'sitevitals-health-monitor-pro' ); ?></th>
							<th><?php esc_html_e( 'Status', 'sitevitals-health-monitor-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $report['plugins'] as $plugin ) : ?>
							<tr>
								<td><?php echo esc_html( $plugin['name'] ); ?></td>
								<td><?php echo esc_html( $plugin['version'] ); ?></td>
								<td><?php echo esc_html( $plugin['health_score'] ); ?></td>
								<td>
									<span class="badge badge-<?php echo esc_attr( $plugin['status'] ); ?>">
										<?php echo esc_html( ucfirst( str_replace( '_', ' ', $plugin['status'] ) ) ); ?>
									</span>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<div class="footer">
				<p><?php echo esc_html( $agency_name ); ?> | <?php echo esc_html( $site_url ); ?> | <?php echo esc_html( $date ); ?></p>
			</div>
		</body>
		</html>
		<?php
		return ob_get_clean();
	}
}
