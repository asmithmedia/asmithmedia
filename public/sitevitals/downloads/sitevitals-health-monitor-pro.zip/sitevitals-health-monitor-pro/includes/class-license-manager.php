<?php
/**
 * License Manager - Ed25519 cryptographic license key validation.
 *
 * Zero server calls. License keys are self-validating using public key cryptography.
 *
 * License format: base64(json_payload).base64(signature)
 * Payload: {"email":"user@example.com","plan":"single|unlimited","domain":"*|example.com","created":"2025-01-01","expires":"2026-01-01"}
 *
 * @package SiteVitals_Health_Monitor_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_License_Manager {

	private static $instance = null;

	/**
	 * Ed25519 public key for license verification.
	 * This is safe to distribute — only the private key (kept on your server) can create valid signatures.
	 *
	 * IMPORTANT: Replace this with your actual public key from generate-keypair.php.
	 *
	 * @var string
	 */
	const PUBLIC_KEY = 'cc1165e9097ea151326cb564b142eac789cf0978c0a8a6042fec08326b0a872c';

	/**
	 * Option key for stored license.
	 *
	 * @var string
	 */
	const OPTION_KEY = 'sitevitals_pro_license';

	/**
	 * Transient key for cached validation.
	 *
	 * @var string
	 */
	const CACHE_KEY = 'sitevitals_pro_license_valid';

	/**
	 * Grace period in days after expiry.
	 *
	 * @var int
	 */
	const GRACE_DAYS = 7;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_sitevitals_activate_license', array( $this, 'ajax_activate' ) );
		add_action( 'wp_ajax_sitevitals_deactivate_license', array( $this, 'ajax_deactivate' ) );
	}

	/**
	 * Check if the current license is valid.
	 *
	 * @return bool
	 */
	public function is_valid() {
		$cached = get_transient( self::CACHE_KEY );
		if ( false !== $cached ) {
			return (bool) $cached;
		}

		$license_key = get_option( self::OPTION_KEY, '' );
		if ( empty( $license_key ) ) {
			return false;
		}

		$result = $this->validate_key( $license_key );
		$is_valid = ( true === $result );

		// Cache for 24 hours.
		set_transient( self::CACHE_KEY, $is_valid ? 1 : 0, DAY_IN_SECONDS );

		return $is_valid;
	}

	/**
	 * Validate a license key cryptographically.
	 *
	 * @param string $license_key The full license key string.
	 * @return true|string True if valid, error message string if invalid.
	 */
	public function validate_key( $license_key ) {
		// Check sodium is available.
		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			return __( 'PHP sodium extension is required for license validation.', 'sitevitals-health-monitor-pro' );
		}

		// Split key into payload and signature.
		$parts = explode( '.', $license_key, 2 );
		if ( count( $parts ) !== 2 ) {
			return __( 'Invalid license key format.', 'sitevitals-health-monitor-pro' );
		}

		$payload_b64   = $parts[0];
		$signature_b64 = $parts[1];

		// Decode.
		$payload_json = base64_decode( $payload_b64, true );
		$signature    = base64_decode( $signature_b64, true );

		if ( false === $payload_json || false === $signature ) {
			return __( 'Invalid license key encoding.', 'sitevitals-health-monitor-pro' );
		}

		// Verify signature.
		$public_key = sodium_hex2bin( self::PUBLIC_KEY );

		try {
			$valid = sodium_crypto_sign_verify_detached( $signature, $payload_json, $public_key );
		} catch ( \SodiumException $e ) {
			return __( 'License signature verification failed.', 'sitevitals-health-monitor-pro' );
		}

		if ( ! $valid ) {
			return __( 'Invalid license key signature.', 'sitevitals-health-monitor-pro' );
		}

		// Parse payload.
		$payload = json_decode( $payload_json, true );
		if ( ! $payload ) {
			return __( 'Invalid license payload.', 'sitevitals-health-monitor-pro' );
		}

		// Check expiry (with grace period).
		if ( ! empty( $payload['expires'] ) ) {
			$expires    = strtotime( $payload['expires'] );
			$grace_end  = $expires + ( self::GRACE_DAYS * DAY_IN_SECONDS );

			if ( time() > $grace_end ) {
				return __( 'License key has expired.', 'sitevitals-health-monitor-pro' );
			}
		}

		// Check domain (if not wildcard).
		if ( ! empty( $payload['domain'] ) && '*' !== $payload['domain'] ) {
			$site_domain = wp_parse_url( home_url(), PHP_URL_HOST );
			// Strip www. for comparison.
			$site_domain    = preg_replace( '/^www\./', '', $site_domain );
			$license_domain = preg_replace( '/^www\./', '', $payload['domain'] );

			if ( strtolower( $site_domain ) !== strtolower( $license_domain ) ) {
				return sprintf(
					/* translators: 1: licensed domain, 2: current domain */
					__( 'License is for %1$s, but this site is %2$s.', 'sitevitals-health-monitor-pro' ),
					$license_domain,
					$site_domain
				);
			}
		}

		return true;
	}

	/**
	 * Get the decoded license payload.
	 *
	 * @return array|null
	 */
	public function get_license_data() {
		$license_key = get_option( self::OPTION_KEY, '' );
		if ( empty( $license_key ) ) {
			return null;
		}

		$parts = explode( '.', $license_key, 2 );
		if ( count( $parts ) !== 2 ) {
			return null;
		}

		$payload_json = base64_decode( $parts[0], true );
		if ( false === $payload_json ) {
			return null;
		}

		return json_decode( $payload_json, true );
	}

	/**
	 * AJAX: Activate license.
	 */
	public function ajax_activate() {
		check_ajax_referer( 'sitevitals_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Unauthorized.', 'sitevitals-health-monitor-pro' ) );
		}

		$key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
		if ( empty( $key ) ) {
			wp_send_json_error( __( 'Please enter a license key.', 'sitevitals-health-monitor-pro' ) );
		}

		$result = $this->validate_key( $key );
		if ( true !== $result ) {
			wp_send_json_error( $result );
		}

		update_option( self::OPTION_KEY, $key );
		delete_transient( self::CACHE_KEY );

		wp_send_json_success( __( 'License activated successfully!', 'sitevitals-health-monitor-pro' ) );
	}

	/**
	 * AJAX: Deactivate license.
	 */
	public function ajax_deactivate() {
		check_ajax_referer( 'sitevitals_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Unauthorized.', 'sitevitals-health-monitor-pro' ) );
		}

		delete_option( self::OPTION_KEY );
		delete_transient( self::CACHE_KEY );

		wp_send_json_success( __( 'License deactivated.', 'sitevitals-health-monitor-pro' ) );
	}

	/**
	 * Render the license settings form on the free plugin's settings page.
	 */
	public function render_license_settings() {
		$license_data = $this->get_license_data();
		$is_valid     = $this->is_valid();
		?>
		<div class="sitevitals-settings-grid">
			<div class="sitevitals-setting-row">
				<div class="sitevitals-setting-label">
					<label><?php esc_html_e( 'License Key', 'sitevitals-health-monitor-pro' ); ?></label>
					<span class="sitevitals-setting-desc"><?php esc_html_e( 'Your Pro license key from purchase email.', 'sitevitals-health-monitor-pro' ); ?></span>
				</div>
				<div class="sitevitals-setting-input">
					<?php if ( $is_valid && $license_data ) : ?>
						<div>
							<span class="dashicons dashicons-yes-alt" style="color:#4ade80;vertical-align:middle;"></span>
							<strong style="color:#4ade80;"><?php esc_html_e( 'Active', 'sitevitals-health-monitor-pro' ); ?></strong>
							<span style="color:#94a3b8;font-size:13px;margin-left:8px;">
								<?php
								printf(
									/* translators: 1: plan name, 2: expiry date */
									esc_html__( '%1$s plan — expires %2$s', 'sitevitals-health-monitor-pro' ),
									esc_html( ucfirst( $license_data['plan'] ?? 'unknown' ) ),
									esc_html( $license_data['expires'] ?? 'never' )
								);
								?>
							</span>
							<br /><br />
							<button type="button" class="sitevitals-btn sitevitals-btn-secondary" id="sitevitals-deactivate-license">
								<?php esc_html_e( 'Deactivate', 'sitevitals-health-monitor-pro' ); ?>
							</button>
						</div>
					<?php else : ?>
						<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
							<input type="text"
								id="sitevitals_license_key"
								placeholder="<?php esc_attr_e( 'Paste license key...', 'sitevitals-health-monitor-pro' ); ?>"
								style="min-width:300px;font-family:'SF Mono','Cascadia Code',monospace;" />
							<button type="button" class="sitevitals-btn sitevitals-btn-pro" id="sitevitals-activate-license">
								<?php esc_html_e( 'Activate', 'sitevitals-health-monitor-pro' ); ?>
							</button>
							<span id="sitevitals-license-status" class="sitevitals-inline-status"></span>
						</div>
						<p style="color:#64748b;font-size:12px;margin-top:8px;">
							<a href="https://asmith.media/sitevitals/" target="_blank" rel="noopener" style="color:#f59e0b;">
								<?php esc_html_e( "Don't have a license?", 'sitevitals-health-monitor-pro' ); ?>
							</a>
						</p>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<script>
		jQuery(function($) {
			$('#sitevitals-activate-license').on('click', function() {
				var key = $('#sitevitals_license_key').val();
				var $status = $('#sitevitals-license-status');
				$status.text('Activating...').css('color', '#94a3b8');
				$.post(sitevitals.ajax_url, {
					action: 'sitevitals_activate_license',
					nonce: sitevitals.nonce,
					license_key: key
				}).done(function(r) {
					if (r.success) {
						$status.text(r.data).css('color', '#4ade80');
						setTimeout(function() { location.reload(); }, 500);
					} else {
						$status.text(r.data).css('color', '#f87171');
					}
				});
			});
			$('#sitevitals-deactivate-license').on('click', function() {
				$.post(sitevitals.ajax_url, {
					action: 'sitevitals_deactivate_license',
					nonce: sitevitals.nonce
				}).done(function(r) {
					if (r.success) location.reload();
				});
			});
		});
		</script>
		<?php
	}
}
