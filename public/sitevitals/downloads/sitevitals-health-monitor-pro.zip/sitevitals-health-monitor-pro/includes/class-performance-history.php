<?php
/**
 * Performance History - stores and charts plugin performance trends over time.
 *
 * @package SiteVitals_Health_Monitor_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_Performance_History {

	private static $instance = null;

	const TABLE_NAME = 'sitevitals_perf_history';
	const RETENTION_DAYS = 90;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		register_activation_hook( SITEVITALS_PRO_FILE, array( $this, 'create_table' ) );

		// Store daily snapshot after profiling.
		add_action( 'sitevitals_after_profile', array( $this, 'store_snapshot' ) );

		// Cleanup old data.
		add_action( 'sitevitals_daily_scan', array( $this, 'cleanup' ) );

		// AJAX for chart data.
		add_action( 'wp_ajax_sitevitals_perf_history', array( $this, 'ajax_get_history' ) );

		// Add history tab.
		add_filter( 'sitevitals_dashboard_tabs', array( $this, 'add_history_tab' ) );
	}

	/**
	 * Create the history table.
	 */
	public function create_table() {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE_NAME;
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			plugin_file varchar(255) NOT NULL,
			plugin_name varchar(255) NOT NULL,
			health_score int(3) NOT NULL DEFAULT 0,
			impact_score int(3) NOT NULL DEFAULT 0,
			file_count int(10) NOT NULL DEFAULT 0,
			total_size bigint(20) NOT NULL DEFAULT 0,
			hook_count int(10) NOT NULL DEFAULT 0,
			options_count int(10) NOT NULL DEFAULT 0,
			memory_estimate bigint(20) NOT NULL DEFAULT 0,
			recorded_at date NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY plugin_date (plugin_file(191), recorded_at),
			KEY recorded_at (recorded_at)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/**
	 * Store a daily performance snapshot.
	 *
	 * @param array $results Performance profiling results.
	 */
	public function store_snapshot( $results ) {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE_NAME;
		$today = current_time( 'Y-m-d' );

		$scanner = SiteVitals_Plugin_Scanner::instance();
		$scan_results = $scanner->get_results();

		foreach ( $results as $plugin_file => $perf ) {
			$health_score = 0;
			if ( isset( $scan_results[ $plugin_file ] ) ) {
				$health_score = $scan_results[ $plugin_file ]['health_score'];
			}

			$wpdb->replace( $table, array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				'plugin_file'    => $plugin_file,
				'plugin_name'    => $perf['name'],
				'health_score'   => $health_score,
				'impact_score'   => $perf['impact_score'] ?? 0,
				'file_count'     => $perf['file_count'] ?? 0,
				'total_size'     => $perf['total_size'] ?? 0,
				'hook_count'     => $perf['hook_count'] ?? 0,
				'options_count'  => $perf['options_count'] ?? 0,
				'memory_estimate' => $perf['memory_estimate'] ?? 0,
				'recorded_at'    => $today,
			), array( '%s', '%s', '%d', '%d', '%d', '%d', '%d', '%d', '%d', '%s' ) );
		}
	}

	/**
	 * Get historical data for a plugin or all plugins.
	 *
	 * @param string|null $plugin_file Specific plugin or null for all.
	 * @param int         $days        Number of days to look back.
	 * @return array
	 */
	public function get_history( $plugin_file = null, $days = 30 ) {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE_NAME;
		$since = gmdate( 'Y-m-d', time() - $days * DAY_IN_SECONDS );

		if ( $plugin_file ) {
			$results = $wpdb->get_results( $wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				"SELECT * FROM {$table} WHERE plugin_file = %s AND recorded_at >= %s ORDER BY recorded_at ASC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$plugin_file,
				$since
			), ARRAY_A );
		} else {
			$results = $wpdb->get_results( $wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				"SELECT * FROM {$table} WHERE recorded_at >= %s ORDER BY recorded_at ASC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$since
			), ARRAY_A );
		}

		return $results;
	}

	/**
	 * AJAX: Get chart data.
	 */
	public function ajax_get_history() {
		check_ajax_referer( 'sitevitals_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}

		$plugin = isset( $_POST['plugin'] ) ? sanitize_text_field( wp_unslash( $_POST['plugin'] ) ) : null;
		$days   = isset( $_POST['days'] ) ? absint( $_POST['days'] ) : 30;
		$days   = min( $days, self::RETENTION_DAYS );

		$history = $this->get_history( $plugin, $days );

		// Format for Chart.js.
		$chart_data = $this->format_for_chart( $history );

		wp_send_json_success( $chart_data );
	}

	/**
	 * Format history data for Chart.js consumption.
	 *
	 * @param array $history Raw history rows.
	 * @return array
	 */
	private function format_for_chart( $history ) {
		$by_plugin = array();
		$dates     = array();

		foreach ( $history as $row ) {
			$name = $row['plugin_name'];
			$date = $row['recorded_at'];

			if ( ! isset( $by_plugin[ $name ] ) ) {
				$by_plugin[ $name ] = array();
			}

			$by_plugin[ $name ][ $date ] = array(
				'health_score' => (int) $row['health_score'],
				'impact_score' => (int) $row['impact_score'],
				'memory'       => (int) $row['memory_estimate'],
			);

			$dates[ $date ] = true;
		}

		ksort( $dates );

		// Generate colors for each plugin.
		$colors = array(
			'#3b82f6', '#ef4444', '#22c55e', '#f59e0b', '#8b5cf6',
			'#ec4899', '#06b6d4', '#84cc16', '#f97316', '#6366f1',
		);

		$datasets = array();
		$i = 0;
		foreach ( $by_plugin as $name => $data ) {
			$color = $colors[ $i % count( $colors ) ];
			$values = array();
			foreach ( array_keys( $dates ) as $date ) {
				$values[] = isset( $data[ $date ] ) ? $data[ $date ]['health_score'] : null;
			}

			$datasets[] = array(
				'label'           => $name,
				'data'            => $values,
				'borderColor'     => $color,
				'backgroundColor' => $color . '20',
				'fill'            => false,
				'tension'         => 0.3,
			);
			$i++;
		}

		return array(
			'labels'   => array_keys( $dates ),
			'datasets' => $datasets,
		);
	}

	/**
	 * Clean up old history data.
	 */
	public function cleanup() {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE_NAME;
		$cutoff = gmdate( 'Y-m-d', time() - self::RETENTION_DAYS * DAY_IN_SECONDS );

		$wpdb->query( $wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			"DELETE FROM {$table} WHERE recorded_at < %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$cutoff
		) );
	}

	/**
	 * Add history tab to dashboard.
	 *
	 * @param array $tabs Existing tabs.
	 * @return array
	 */
	public function add_history_tab( $tabs ) {
		unset( $tabs['history'] );
		$tabs['history'] = array(
			'label'    => __( 'Performance History', 'sitevitals-health-monitor-pro' ),
			'icon'     => 'dashicons-chart-line',
			'pro_only' => false,
		);
		return $tabs;
	}
}
