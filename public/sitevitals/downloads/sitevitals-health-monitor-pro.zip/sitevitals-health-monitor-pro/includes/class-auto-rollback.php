<?php
/**
 * Auto Rollback - automatically restores plugins when conflicts are detected after update.
 *
 * @package SiteVitals_Health_Monitor_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SiteVitals_Auto_Rollback {

	private static $instance = null;

	const BACKUP_DIR = WP_CONTENT_DIR . '/sitevitals-backups/';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'upgrader_pre_install', array( $this, 'backup_before_update' ), 10, 2 );
		add_action( 'upgrader_process_complete', array( $this, 'check_after_update' ), 10, 2 );
		add_action( 'wp_ajax_sitevitals_manual_rollback', array( $this, 'ajax_manual_rollback' ) );
	}

	/**
	 * Backup a plugin before it gets updated.
	 *
	 * @param bool  $response Install response.
	 * @param array $hook_extra Extra arguments.
	 * @return bool|WP_Error
	 */
	public function backup_before_update( $response, $hook_extra ) {
		if ( empty( $hook_extra['plugin'] ) ) {
			return $response;
		}

		$plugin_file = $hook_extra['plugin'];
		$plugin_dir  = WP_PLUGIN_DIR . '/' . dirname( $plugin_file );

		if ( ! is_dir( $plugin_dir ) ) {
			return $response;
		}

		$backup_path = self::BACKUP_DIR . dirname( $plugin_file ) . '_' . time();

		if ( ! wp_mkdir_p( self::BACKUP_DIR ) ) {
			return $response;
		}

		$this->copy_directory( $plugin_dir, $backup_path );

		// Store backup reference.
		$backups = get_option( 'sitevitals_pro_backups', array() );
		$backups[ $plugin_file ] = array(
			'path'    => $backup_path,
			'version' => $this->get_plugin_version( $plugin_file ),
			'time'    => time(),
		);

		// Keep only last 3 backups per plugin.
		$plugin_backups = array_filter( $backups, function ( $b ) use ( $plugin_file ) {
			return isset( $b['path'] );
		} );

		update_option( 'sitevitals_pro_backups', $backups );

		return $response;
	}

	/**
	 * After an update completes, run conflict detection and rollback if needed.
	 *
	 * @param WP_Upgrader $upgrader Upgrader instance.
	 * @param array       $options  Update options.
	 */
	public function check_after_update( $upgrader, $options ) {
		if ( 'update' !== $options['action'] || 'plugin' !== $options['type'] ) {
			return;
		}

		$plugins = array();
		if ( ! empty( $options['plugins'] ) ) {
			$plugins = $options['plugins'];
		} elseif ( ! empty( $options['plugin'] ) ) {
			$plugins = array( $options['plugin'] );
		}

		foreach ( $plugins as $plugin_file ) {
			$this->check_plugin_after_update( $plugin_file );
		}
	}

	/**
	 * Check a single plugin for conflicts after update and rollback if needed.
	 *
	 * @param string $plugin_file Plugin file path.
	 */
	private function check_plugin_after_update( $plugin_file ) {
		// Run quick conflict detection.
		$detector    = SiteVitals_Conflict_Detector::instance();
		delete_transient( 'sitevitals_conflicts' );
		$conflicts   = $detector->detect_all();

		$has_new_conflicts = false;

		// Check for new critical issues involving this plugin.
		foreach ( $conflicts['category_conflicts'] as $conflict ) {
			$slug = dirname( $plugin_file );
			if ( in_array( $slug, $conflict['plugins'], true ) ) {
				$has_new_conflicts = true;
				break;
			}
		}

		// Also check for PHP errors from this plugin.
		foreach ( $conflicts['php_errors'] as $error ) {
			if ( $error['plugin'] === dirname( $plugin_file ) && $error['type'] === E_ERROR ) {
				$has_new_conflicts = true;
				break;
			}
		}

		if ( $has_new_conflicts ) {
			$rollback_result = $this->rollback_plugin( $plugin_file );

			if ( $rollback_result ) {
				// Store notification for admin.
				$notices = get_option( 'sitevitals_pro_rollback_notices', array() );
				$notices[] = array(
					'plugin'  => $plugin_file,
					'time'    => time(),
					'reason'  => __( 'Conflicts detected after update. Automatically rolled back to previous version.', 'sitevitals-health-monitor-pro' ),
				);
				update_option( 'sitevitals_pro_rollback_notices', $notices );

				/**
				 * Fires when a plugin is automatically rolled back.
				 *
				 * @param string $plugin_file The plugin that was rolled back.
				 * @param array  $conflicts   The conflicts that triggered the rollback.
				 */
				do_action( 'sitevitals_plugin_rolled_back', $plugin_file, $conflicts );
			}
		}
	}

	/**
	 * Rollback a plugin to its backup.
	 *
	 * @param string $plugin_file Plugin file path.
	 * @return bool
	 */
	public function rollback_plugin( $plugin_file ) {
		$backups = get_option( 'sitevitals_pro_backups', array() );

		if ( ! isset( $backups[ $plugin_file ] ) ) {
			return false;
		}

		$backup = $backups[ $plugin_file ];
		if ( ! is_dir( $backup['path'] ) ) {
			return false;
		}

		$plugin_dir = WP_PLUGIN_DIR . '/' . dirname( $plugin_file );

		// Deactivate temporarily.
		deactivate_plugins( $plugin_file );

		// Remove current version.
		$this->delete_directory( $plugin_dir );

		// Restore backup.
		$this->copy_directory( $backup['path'], $plugin_dir );

		// Reactivate.
		activate_plugin( $plugin_file );

		// Clean up backup.
		$this->delete_directory( $backup['path'] );
		unset( $backups[ $plugin_file ] );
		update_option( 'sitevitals_pro_backups', $backups );

		return true;
	}

	/**
	 * AJAX: Manual rollback.
	 */
	public function ajax_manual_rollback() {
		check_ajax_referer( 'sitevitals_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Unauthorized.', 'sitevitals-health-monitor-pro' ) );
		}

		$plugin = isset( $_POST['plugin'] ) ? sanitize_text_field( wp_unslash( $_POST['plugin'] ) ) : '';
		if ( empty( $plugin ) ) {
			wp_send_json_error( __( 'No plugin specified.', 'sitevitals-health-monitor-pro' ) );
		}

		$result = $this->rollback_plugin( $plugin );
		if ( $result ) {
			wp_send_json_success( __( 'Plugin rolled back successfully.', 'sitevitals-health-monitor-pro' ) );
		} else {
			wp_send_json_error( __( 'No backup found for this plugin.', 'sitevitals-health-monitor-pro' ) );
		}
	}

	/**
	 * Get plugin version from its headers.
	 *
	 * @param string $plugin_file Plugin file path.
	 * @return string
	 */
	private function get_plugin_version( $plugin_file ) {
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$data = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin_file, false, false );
		return $data['Version'] ?? '0.0.0';
	}

	/**
	 * Copy a directory recursively.
	 *
	 * @param string $src Source path.
	 * @param string $dst Destination path.
	 */
	private function copy_directory( $src, $dst ) {
		$dir = opendir( $src );
		wp_mkdir_p( $dst );

		while ( false !== ( $file = readdir( $dir ) ) ) {
			if ( '.' === $file || '..' === $file ) {
				continue;
			}
			if ( is_dir( $src . '/' . $file ) ) {
				$this->copy_directory( $src . '/' . $file, $dst . '/' . $file );
			} else {
				copy( $src . '/' . $file, $dst . '/' . $file );
			}
		}
		closedir( $dir );
	}

	/**
	 * Delete a directory recursively.
	 *
	 * @param string $dir Directory path.
	 */
	private function delete_directory( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}

		global $wp_filesystem;
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		$files = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $files as $file ) {
			if ( $file->isDir() ) {
				$wp_filesystem->rmdir( $file->getRealPath() );
			} else {
				wp_delete_file( $file->getRealPath() );
			}
		}
		$wp_filesystem->rmdir( $dir );
	}
}
