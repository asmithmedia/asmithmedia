=== SiteVitals Health Monitor Pro ===
Contributors: asmithmedia
Tags: plugin health, auto-rollback, performance monitoring, slack alerts, white-label
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Premium add-on for SiteVitals Health Monitor. Adds auto-rollback, real-time monitoring, performance history, Slack alerts, and white-label reports.

== Description ==

SiteVitals Health Monitor Pro extends the free SiteVitals Health Monitor plugin with advanced features for agencies and professionals:

* **Auto-Rollback** - Automatically restores plugins when conflicts are detected after an update.
* **Real-Time Monitor** - Live conflict and error monitoring dashboard.
* **Performance History** - Charts plugin performance trends over time.
* **Slack Notifications** - Instant alerts via Slack webhook integration.
* **White-Label Reports** - Branded HTML and PDF exports for client reporting.

This plugin requires the free SiteVitals Health Monitor plugin to be installed and active.

== Installation ==

1. Install and activate the free SiteVitals Health Monitor plugin.
2. Upload the `sitevitals-health-monitor-pro` folder to `/wp-content/plugins/`.
3. Activate the plugin through the Plugins menu.
4. Enter your license key when prompted.

== Changelog ==

= 1.0.0 =
* Initial release.
