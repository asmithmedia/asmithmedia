<?php
/**
 * Plugin Name: SiteVitals Health Monitor Pro
 * Plugin URI:  https://asmith.media/sitevitals/
 * Description: Premium add-on for SiteVitals Health Monitor. Adds auto-rollback, real-time monitoring, performance history, Slack alerts, and white-label reports.
 * Version:     1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author:      A. Smith Media
 * Author URI:  https://asmith.media
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: sitevitals-health-monitor-pro
 *
 * @package SiteVitals_Health_Monitor_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SITEVITALS_PRO_VERSION', '1.0.0' );
define( 'SITEVITALS_PRO_FILE', __FILE__ );
define( 'SITEVITALS_PRO_DIR', plugin_dir_path( __FILE__ ) );
define( 'SITEVITALS_PRO_URL', plugin_dir_url( __FILE__ ) );
define( 'SITEVITALS_PRO_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Main Pro plugin class.
 */
final class SiteVitals_Health_Monitor_Pro {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'check_dependencies' ), 5 );
		add_action( 'activated_plugin', array( $this, 'redirect_after_activation' ) );
	}

	/**
	 * Redirect to license activation screen after Pro is activated.
	 *
	 * @param string $plugin The plugin that was activated.
	 */
	public function redirect_after_activation( $plugin ) {
		if ( $plugin !== SITEVITALS_PRO_BASENAME ) {
			return;
		}

		if ( isset( $_GET['activate-multi'] ) || wp_doing_ajax() || ( defined( 'WP_CLI' ) && WP_CLI ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- WP core activation redirect pattern, no form data processed.
			return;
		}

		// Mark that we need to show onboarding.
		update_option( 'sitevitals_pro_needs_onboarding', true );

		wp_safe_redirect( admin_url( 'admin.php?page=sitevitals-pro-activate' ) );
		exit;
	}

	/**
	 * Verify the free plugin is active before loading Pro.
	 */
	public function check_dependencies() {
		if ( ! defined( 'SITEVITALS_VERSION' ) ) {
			add_action( 'admin_notices', array( $this, 'missing_free_plugin_notice' ) );
			return;
		}

		$this->load_includes();
		$this->init();
	}

	/**
	 * Load Pro class files.
	 */
	private function load_includes() {
		$includes = array(
			'class-license-manager',
			'class-auto-rollback',
			'class-realtime-monitor',
			'class-performance-history',
			'class-notifications',
			'class-white-label',
		);

		foreach ( $includes as $file ) {
			require_once SITEVITALS_PRO_DIR . 'includes/' . $file . '.php';
		}
	}

	/**
	 * Initialize Pro features.
	 */
	private function init() {
		$license = SiteVitals_License_Manager::instance();

		// Register the Pro activation/onboarding page.
		add_action( 'admin_menu', array( $this, 'register_pro_pages' ) );

		// Only load premium features if licensed.
		if ( $license->is_valid() ) {
			SiteVitals_Auto_Rollback::instance();
			SiteVitals_Realtime_Monitor::instance();
			SiteVitals_Performance_History::instance();
			SiteVitals_Notifications::instance();
			SiteVitals_White_Label::instance();

			// Hook Pro UI sections into the free plugin's dashboard and settings.
			add_action( 'sitevitals_pro_dashboard_sections', array( $this, 'render_pro_dashboard' ) );
			add_action( 'sitevitals_pro_after_plugins', array( $this, 'render_pro_after_plugins' ) );
			add_action( 'sitevitals_pro_settings_sections', array( $this, 'render_pro_settings' ) );
		}

		// License settings on free plugin's settings page.
		add_action( 'sitevitals_pro_license_settings', array( $license, 'render_license_settings' ) );

		// Tell the free plugin that Pro is licensed.
		add_filter( 'sitevitals_pro_is_licensed', array( $license, 'is_valid' ) );

		// Enqueue Pro assets on our pages.
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_pro_assets' ) );
	}

	/**
	 * Register the hidden Pro activation page.
	 */
	public function register_pro_pages() {
		add_submenu_page(
			null, // Hidden page — no menu link.
			__( 'Activate Pro', 'sitevitals-health-monitor-pro' ),
			__( 'Activate Pro', 'sitevitals-health-monitor-pro' ),
			'manage_options',
			'sitevitals-pro-activate',
			array( $this, 'render_pro_activation' )
		);
	}

	/**
	 * Enqueue Pro scripts on our activation page.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 */
	public function enqueue_pro_assets( $hook_suffix ) {
		$pro_pages = array( 'admin_page_sitevitals-pro-activate' );
		if ( ! in_array( $hook_suffix, $pro_pages, true ) ) {
			return;
		}

		// We need the free plugin's CSS and JS for dark theme and AJAX.
		wp_enqueue_style(
			'sitevitals-admin',
			SITEVITALS_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			SITEVITALS_PRO_VERSION
		);

		wp_enqueue_script(
			'sitevitals-admin',
			SITEVITALS_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			SITEVITALS_PRO_VERSION,
			true
		);

		wp_localize_script( 'sitevitals-admin', 'sitevitals', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'sitevitals_nonce' ),
		) );
	}

	/**
	 * Render the Pro activation / onboarding page.
	 */
	public function render_pro_activation() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'sitevitals-health-monitor-pro' ) );
		}

		$license = SiteVitals_License_Manager::instance();

		// If already licensed, redirect to dashboard.
		if ( $license->is_valid() ) {
			delete_option( 'sitevitals_pro_needs_onboarding' );
			wp_safe_redirect( admin_url( 'admin.php?page=sitevitals' ) );
			exit;
		}

		include SITEVITALS_PRO_DIR . 'templates/pro-activate.php';
	}

	/**
	 * Render Pro dashboard sections (history chart, real-time, auto-rollback, export).
	 *
	 * @param array $report Health report data.
	 */
	public function render_pro_dashboard( $report ) {
		include SITEVITALS_PRO_DIR . 'templates/pro-dashboard-sections.php';
	}

	/**
	 * Render Pro export buttons after plugin cards.
	 *
	 * @param array $report Health report data.
	 */
	public function render_pro_after_plugins( $report ) {
		// Export buttons already in dashboard sections — this hook available for future use.
	}

	/**
	 * Render Pro settings sections (Slack, alerts, white-label).
	 */
	public function render_pro_settings() {
		include SITEVITALS_PRO_DIR . 'templates/pro-settings-sections.php';
	}

	/**
	 * Admin notice when free plugin is missing.
	 */
	public function missing_free_plugin_notice() {
		?>
		<div class="notice notice-error">
			<p>
				<strong><?php esc_html_e( 'SiteVitals Health Monitor Pro', 'sitevitals-health-monitor-pro' ); ?></strong>:
				<?php esc_html_e( 'This add-on requires the free SiteVitals Health Monitor plugin to be installed and active.', 'sitevitals-health-monitor-pro' ); ?>
			</p>
		</div>
		<?php
	}
}

function sitevitals_pro() {
	return SiteVitals_Health_Monitor_Pro::instance();
}

sitevitals_pro();
